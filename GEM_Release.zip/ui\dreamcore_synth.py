"""
Синтез процедурных дримкор-звуков и воспроизведение кастомных семплов из assets/sounds/.
"""
import os
import wave
import math
import ctypes
import threading

winmm = ctypes.windll.winmm
SND_FILENAME = 0x00020000
SND_ASYNC = 0x0001
SND_NODEFAULT = 0x0002

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOUNDS_DIR = os.path.join(BASE_DIR, "assets", "sounds")

class CustomSoundEngine:
    def __init__(self):
        os.makedirs(SOUNDS_DIR, exist_ok=True)
        self._ensure_default_sounds()

    def _ensure_default_sounds(self):
        talk_path = os.path.join(SOUNDS_DIR, "talk.wav")
        wake_path = os.path.join(SOUNDS_DIR, "wake.wav")

        if not os.path.exists(talk_path):
            self._generate_sine_wav(talk_path, freq=180, duration=0.045, fade=True)
        if not os.path.exists(wake_path):
            self._generate_sine_wav(wake_path, freq=120, duration=0.25, fade=True)

    def _generate_sine_wav(self, path, freq=200, duration=0.05, fade=True):
        sample_rate = 22050
        n_samples = int(sample_rate * duration)
        raw = bytearray()

        for i in range(n_samples):
            t = i / sample_rate
            env = math.sin(math.pi * (i / n_samples)) if fade else 1.0
            val = int(math.sin(2 * math.pi * freq * t) * env * 24000)
            val = max(-32767, min(32767, val))
            raw += int(val).to_bytes(2, byteorder='little', signed=True)

        with wave.open(path, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(raw)

    def play(self, sound_name: str):
        path = os.path.join(SOUNDS_DIR, f"{sound_name}.wav")
        if os.path.exists(path):
            def _play():
                winmm.PlaySoundW(path, None, SND_FILENAME | SND_ASYNC | SND_NODEFAULT)
            threading.Thread(target=_play, daemon=True).start()

sound_engine = CustomSoundEngine()

def dream_say_char(char: str):
    if char in [" ", "\n", "\t"]:
        return
    sound_engine.play("talk")

def play_sound(name: str):
    sound_engine.play(name)