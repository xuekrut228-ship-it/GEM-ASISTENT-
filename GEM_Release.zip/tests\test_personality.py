import unittest
import json
from unittest.mock import Mock, patch

from config import DEFAULT_CONFIG
from core.emotions import detect_emotion
from core.brain import Brain
from core.sanitizer import clean_llm_output
from ui.mascot import DreamMascot


class PersonalityTests(unittest.TestCase):
    def test_unsolicited_comments_are_disabled_by_default(self):
        self.assertTrue(DEFAULT_CONFIG["proactive_enabled"])
        self.assertFalse(DEFAULT_CONFIG["game_coach"])

    def test_generic_assistant_greeting_is_filtered(self):
        reply = clean_llm_output(
            "Я здесь. Как я могу помочь вам сегодня?",
            "привет",
        )

        self.assertNotIn("как я могу помочь", reply.lower())
        self.assertNotIn("я здесь", reply.lower())

    def test_unasked_self_description_is_removed(self):
        reply = clean_llm_output(
            "Я глаз в мониторе, парящий и погружённый в мир кода. "
            "Я помогу, если спросишь.",
            "что думаешь?",
        )

        self.assertNotIn("я глаз", reply.lower())
        self.assertIn("я помогу", reply.lower())

    def test_reply_containing_only_unasked_self_description_gets_fallback(self):
        reply = clean_llm_output(
            "Я глаз в мониторе, парящий и погружённый в мир кода.",
            "как дела?",
        )

        self.assertEqual(reply, "Эй, я сбился. Скажи ещё раз, только попроще.")

    def test_emotion_is_selected_from_conversation_and_attitude(self):
        self.assertEqual(detect_emotion(reply="Класс, получилось!"), "happy")
        self.assertEqual(detect_emotion(user_text="Ты меня бесишь"), "angry")
        self.assertEqual(detect_emotion(user_text="Ты криворукий"), "angry")
        self.assertEqual(detect_emotion(reply="Жаль, не получилось"), "sad")
        self.assertEqual(detect_emotion(reply="Ого, ничего себе!"), "surprised")
        self.assertEqual(detect_emotion(reply="Запустил Steam."), "happy")
        self.assertEqual(detect_emotion(reply="Не нашёл приложение."), "sad")
        self.assertEqual(detect_emotion(attitude_score=20), "angry")
        self.assertEqual(detect_emotion(), "neutral")

    def test_iris_color_stays_constant_across_expressions(self):
        target = (181, 131, 141)
        for emotion in ("neutral", "happy", "angry", "sad", "surprised"):
            r, g, b, _ = DreamMascot._draw_dream_eye(emotion).getpixel((117, 110))
            self.assertLessEqual(abs(r - target[0]), 3, emotion)
            self.assertLessEqual(abs(g - target[1]), 3, emotion)
            self.assertLessEqual(abs(b - target[2]), 3, emotion)

    def test_neutral_eye_keeps_a_visible_single_eyebrow(self):
        image = DreamMascot._draw_dream_eye("neutral")

        self.assertNotEqual(image.getpixel((111, 54)), (0, 0, 0, 0))
        r, g, b, _ = image.getpixel((117, 110))
        self.assertLessEqual(abs(r - 181), 3)
        self.assertLessEqual(abs(g - 131), 3)
        self.assertLessEqual(abs(b - 141), 3)

    def test_speech_bubble_wraps_long_words_to_width(self):
        class FakeFont:
            @staticmethod
            def measure(text):
                return len(text) * 6

        mascot = object.__new__(DreamMascot)
        mascot._bubble_font = FakeFont()
        lines = mascot._wrap_bubble_text("Коротко " + "X" * 100, 30)

        self.assertTrue(lines)
        self.assertTrue(all(mascot._bubble_font.measure(line) <= 30 for line in lines))

    def test_speech_bubble_keeps_all_wrapped_text(self):
        class FakeFont:
            @staticmethod
            def measure(text):
                return len(text) * 6

        mascot = object.__new__(DreamMascot)
        mascot._bubble_font = FakeFont()
        text = "Вот длинное сообщение, " * 20
        lines = mascot._wrap_bubble_text(text, 60)

        self.assertEqual(" ".join(lines), text.strip())

    def test_quick_reaction_matches_question_punctuation(self):
        brain = object.__new__(Brain)
        brain.mode = "ollama"
        brain._ask_ollama = unittest.mock.Mock(
            side_effect=AssertionError("short self-introduction should be local")
        )

        reply = brain.ask("Кто ты?")

        self.assertTrue(any(term in reply.lower() for term in ("гем", "глаз", "криптид")))

    def test_local_prompt_is_short_and_does_not_force_self_description(self):
        brain = object.__new__(Brain)
        brain.user_name = "Захар"
        brain.config = {"safe_mode": False}

        prompt = brain._ollama_system_prompt(50)

        self.assertIn("Отвечай именно на последнее сообщение", prompt)
        self.assertIn("О себе рассказывай только если тебя об этом спросили", prompt)
        self.assertLess(len(prompt), 700)

    def test_local_formal_fallback_is_replaced_with_character_reply(self):
        brain = object.__new__(Brain)
        brain.ollama_model = "gem-qwen2.5-1.5b:latest"
        brain.user_name = "Захар"
        brain.config = {"safe_mode": False}
        brain.memory = None
        brain._ollama_models = Mock(return_value=["gem-qwen2.5-1.5b:latest"])
        response = {"message": {"content": "Извините, но не удалось понять ваш вопрос. Пожалуйста, повторите его."}}
        mocked_response = unittest.mock.MagicMock()
        mocked_response.__enter__.return_value = mocked_response
        mocked_response.read.return_value = json.dumps(response).encode("utf-8")

        with patch("core.brain.urllib.request.urlopen", return_value=mocked_response):
            reply = brain._ask_ollama("Что думаешь?", 50, None, record=False)

        self.assertIn("локальная голова", reply)
        self.assertNotIn("Извините", reply)

    def test_speech_bubble_renders_long_message_without_dropping_text(self):
        import tkinter as tk
        import tkinter.font as tkfont

        root = tk.Tk()
        root.withdraw()
        mascot = object.__new__(DreamMascot)
        mascot.root = root
        mascot.w = 320
        mascot.c_paper = "#f4ebd0"
        mascot.bubble_bg_item = None
        mascot.bubble_text_item = None
        mascot._bubble_img_tk = None
        mascot._bubble_font = tkfont.Font(root, family="Courier New", size=8)
        mascot.canvas = tk.Canvas(root, width=320, height=535)
        mascot.canvas.pack()
        text = "Гем отвечает коротко и по делу. " * 8

        try:
            mascot._render_dream_bubble(text, cursor=False)
            root.update_idletasks()
            rendered = mascot.canvas.itemcget(mascot.bubble_text_item, "text")
        finally:
            root.destroy()

        self.assertEqual(" ".join(rendered.split()), " ".join(text.split()))


if __name__ == "__main__":
    unittest.main()
