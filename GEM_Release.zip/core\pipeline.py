"""
Модуль пошагового выполнения цепочек действий (Action Pipeline) для Гема.
Гарантирует строгую последовательность: запуск -> ожидание фокуса -> действие.
"""
import re
import time
from core import actions
from modules import tools

# Разделители шагов в голосовой речи
CHAIN_SPLITTERS = re.compile(
    r"\s*(?:,\s*|\s+(?:потом|затем|после этого|и потом|а потом|следом|далее|и)\s+)"
    r"(?=(?:открой|запусти|вруби|включи|напиши|напечатай|введи|вбей|"
    r"закрой|выруби|убей|погаси|перейди|зайди|сделай)\b)",
    re.IGNORECASE
)

SAFE_MODE_BLOCKED_STEPS = {"WRITE", "KILL"}


class ActionStep:
    def __init__(self, action_type: str, payload: str):
        self.action_type = action_type  # 'RUN', 'WRITE', 'SCREEN', 'WEB', 'KILL', 'WAIT'
        self.payload = payload

    def __repr__(self):
        return f"Step({self.action_type}: {self.payload})"

class TaskPipeline:
    @staticmethod
    def parse_sequence(user_text: str) -> list:
        """Парсит естественную речь в упорядоченный список действий."""
        raw_parts = [p.strip() for p in CHAIN_SPLITTERS.split(user_text) if p.strip()]
        steps = []

        for original_part in raw_parts:
            normalized_part = original_part.strip().rstrip(".,!?;:")
            p_l = normalized_part.lower()

            # 1. Печать / набор текста в активное окно
            write_match = re.search(
                r"\b(?:напиши|напечатай|введи|вбей)\s+(.+)",
                original_part,
                re.IGNORECASE,
            )
            if write_match:
                steps.append(ActionStep("WRITE", write_match.group(1).strip()))
                continue

            # 2. Скриншот
            if any(w in p_l for w in ["скрин", "скриншот", "снимок экрана"]):
                steps.append(ActionStep("SCREEN", ""))
                continue

            # 3. Закрытие софта
            if any(w in p_l for w in ["закрой", "выруби", "убей", "погаси"]):
                target = re.sub(r"\b(закрой|выруби|убей|погаси|процесс|программу|окно)\b", "", p_l).strip()
                steps.append(ActionStep("KILL", target))
                continue

            # 4. Веб-переход
            clean_web = re.sub(r"\b(открой|запусти|перейди|зайди|на|в|сайт|страницу)\b", "", p_l).strip()
            if clean_web in actions.COMMON_SITES or "." in clean_web:
                steps.append(ActionStep("WEB", clean_web))
                continue

            # 5. Запуск софта / YouTube
            if any(w in p_l for w in ["открой", "запусти", "вруби", "включи"]):
                target = re.sub(r"\b(открой|запусти|вруби|включи|приложение|игру|программу)\b", "", p_l).strip()
                if any(w in target for w in ["ютуб", "youtube", "видос"]):
                    steps.append(ActionStep("YOUTUBE", target))
                else:
                    steps.append(ActionStep("RUN", target))
                continue

        return steps

    @staticmethod
    def execute_chain(steps: list, safe_mode: bool = False) -> str:
        """Выполняет шаги строго друг за другом с необходимыми паузами для Windows."""
        log = []

        for i, step in enumerate(steps):
            if safe_mode and step.action_type in SAFE_MODE_BLOCKED_STEPS:
                log.append(f"пропустил {step.action_type.lower()} из-за безопасного режима")
                continue

            if step.action_type == "RUN":
                ok = tools.run_app(step.payload)
                if ok:
                    log.append(f"открыл {step.payload}")
                    # Даем Windows 1.2 секунды на инициализацию процесса и отрисовку окна
                    time.sleep(1.2)
                else:
                    log.append(f"не нашел {step.payload}")

            elif step.action_type == "WRITE":
                # Вставляем текст в то окно, которое сейчас на переднем плане
                tools.paste_text(step.payload)
                log.append(f"напечатал «{step.payload}»")
                time.sleep(0.3)

            elif step.action_type == "SCREEN":
                time.sleep(0.5)
                tools.take_screenshot()
                log.append("сделал скриншот")

            elif step.action_type == "WEB":
                actions.handle_web_navigation(step.payload)
                log.append(f"открыл вкладку {step.payload}")
                time.sleep(1.0)

            elif step.action_type == "KILL":
                tools.kill_target(step.payload)
                log.append(f"закрыл {step.payload}")

            elif step.action_type == "YOUTUBE":
                actions.handle_youtube_search(step.payload)
                log.append(f"врубил на YouTube {step.payload}")
                time.sleep(1.0)

        if not log:
            return ""

        return "Пошагово выполнил: " + ", затем ".join(log) + "."