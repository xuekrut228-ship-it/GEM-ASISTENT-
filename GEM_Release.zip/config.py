import os
import json

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "gem_config.json")

DEFAULT_CONFIG = {
    "user_name": "Захар",
    "api_key": "",
    "model_name": "gemini-3.8-flash",
    "ollama_model": "gem-qwen2.5-1.5b:latest",
    "cruelty_level": 2,       # 1 - добрый, 2 - саркастичный/дерзкий, 3 - токсичный
    "safe_mode": False,       # True - без мата, закрытия процессов, ввода текста и отправки в Telegram
    "sound_enabled": True,    # Дримкор-бормотание
    "mic_index": None,
    "telegram_api_id": None,  # с https://my.telegram.org
    "telegram_api_hash": "",  # с https://my.telegram.org
    "proactive_enabled": True,   # Комментарии без команды включены
    "proactive_cooldown": 240,   # пауза между репликами, сек
    "explore_enabled": True,     # Гем может уходить исследовать файлы/телеграм
    "explore_cooldown": 600,     # пауза между исследованиями, сек
    "random_chat_enabled": True,  # Гем сам рассказывает факты/истории
    "random_chat_cooldown": 300,  # пауза между случайными репликами, сек
    "vision_proactive": True,    # смотрит скриншот, не только имя окна
    "game_coach": False,         # игровые подсказки без команды отключены по умолчанию
    "game_coach_cooldown": 90,   # пауза между игровыми подсказками, сек
    "learn_from_activity": True, # учится по окнам и командам
    "voice_enabled": False,          # озвучка голосом (нужен edge-tts)
    "voice_name": "ru-RU-DmitryNeural",
    "voice_rate": "+0%",
    "voice_volume": "+0%",
}

def load_config() -> dict:
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {**DEFAULT_CONFIG, **data}
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()

def save_config(cfg: dict):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"[CONFIG SAVE ERROR] {e}")