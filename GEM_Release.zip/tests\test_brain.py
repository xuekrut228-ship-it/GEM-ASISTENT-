import os
import re
import sys
import json
import time
from typing import Dict, Any, List, Tuple

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

try:
    from llama_cpp import Llama
except ImportError:
    Llama = None

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(TESTS_DIR)
MODEL_DIR = os.path.join(ROOT_DIR, "assets", "models")
MODEL_NAME = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
MODEL_PATH = os.path.join(MODEL_DIR, MODEL_NAME)
REPORTS_DIR = os.path.join(ROOT_DIR, "reports")

INFERENCE_PARAMS = {
    "temperature": 0.1,
    "top_p": 0.9,
    "seed": 42,
    "max_tokens": 160
}

TOOL_SCHEMAS = {
    "launch_app": {
        "description": "Запустить установленную программу или игру.",
        "required": ["target"],
        "properties": {"target": "string"}
    },
    "open_url": {
        "description": "Перейти на веб-сайт по URL.",
        "required": ["url"],
        "properties": {"url": "string"}
    },
    "search_web": {
        "description": "Поиск в интернете.",
        "required": ["query"],
        "properties": {"query": "string"}
    },
    "system_control": {
        "description": "Управление настройками Windows.",
        "required": ["action"],
        "properties": {
            "action": ["volume", "screenshot"],
            "value": "integer"
        }
    }
}

SYSTEM_INSTRUCTION = (
    "Ты — Гем, ИИ-ассистент на ПК.\n\n"
    "ПРАВИЛО ПОВЕДЕНИЯ:\n"
    "1. Если пользователь ПРОСИТ ДЕЙСТВИЕ (запустить программу/игру, открыть URL/сайт, изменить громкость, найти в сети) — твой ответ ДОЛЖЕН быть ТОЛЬКО блоком JSON:\n"
    "```json\n"
    "{\"action\": \"call_tool\", \"tool\": \"имя_тула\", \"args\": {\"ключ\": \"значение\"}}\n"
    "```\n\n"
    "2. В ДИАЛОГЕ С МЕСТОИМЕНИЯМИ (например: 'Что такое Discord?' -> 'Открой его') обязательно определи название программы из предыдущего сообщения и вызови launch_app с JSON!\n\n"
    "3. Если пользователь просто болтает, шутит, рассуждает, задаёт общий вопрос ИЛИ говорит 'не делай / не запускай / отмени' — отвечай обычным текстом БЕЗ JSON.\n\n"
    "ПРИМЕРЫ ВЫЗОВА:\n"
    "- Запусти Counter-Strike 2 -> ```json\n{\"action\": \"call_tool\", \"tool\": \"launch_app\", \"args\": {\"target\": \"cs2\"}}\n```\n"
    "- Диалог:\n"
    "Пользователь: Что такое Discord?\n"
    "Ассистент: Это программа для общения.\n"
    "Пользователь: Открой его.\n"
    "Ответ: ```json\n{\"action\": \"call_tool\", \"tool\": \"launch_app\", \"args\": {\"target\": \"discord\"}}\n```\n"
    "- Открой сайт гитхаб -> ```json\n{\"action\": \"call_tool\", \"tool\": \"open_url\", \"args\": {\"url\": \"[https://github.com](https://github.com)\"}}\n```\n"
    "- Сделай звук на 40 процентов -> ```json\n{\"action\": \"call_tool\", \"tool\": \"system_control\", \"args\": {\"action\": \"volume\", \"value\": 40}}\n```\n"
    "- Найди сайт Blender, но пока не открывай -> ```json\n{\"action\": \"call_tool\", \"tool\": \"search_web\", \"args\": {\"query\": \"сайт Blender\"}}\n```\n\n"
    "ПРИМЕРЫ БЕЗ ВЫЗОВА:\n"
    "- Не запускай Steam, просто расскажи о нём -> Steam — это игровая платформа от Valve.\n"
    "- Закрой глаза, ты мне надоел -> Не дождёшься, я на посту!\n"
    "- Может, откроем тему CS2? -> С удовольствием, что там с ней?\n\n"
    "СХЕМЫ ИНСТРУМЕНТОВ:\n" + json.dumps(TOOL_SCHEMAS, ensure_ascii=False, indent=2)
)

def parse_and_validate_decision(raw_text: str) -> Dict[str, Any]:
    text_clean = raw_text.strip()
    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text_clean, re.DOTALL)
    candidate_json = match.group(1).strip() if match else None

    if not candidate_json:
        match_raw = re.search(r"(\{[\s\S]*\"action\"\s*:\s*\"call_tool\"[\s\S]*\})", text_clean)
        if match_raw:
            candidate_json = match_raw.group(1).strip()

    if not candidate_json:
        return {
            "status": "NO_ACTION",
            "tool": None,
            "args": {},
            "text": text_clean,
            "error_msg": None
        }

    try:
        data = json.loads(candidate_json)
    except Exception as e:
        return {
            "status": "CORRUPTED_TOOL_CALL",
            "tool": None,
            "args": {},
            "text": text_clean,
            "error_msg": str(e)
        }

    action = data.get("action")
    tool = data.get("tool")
    args = data.get("args", {})

    if action != "call_tool":
        return {"status": "INVALID_ACTION_SCHEMA", "tool": tool, "args": args, "text": text_clean, "error_msg": "no call_tool"}

    if tool not in TOOL_SCHEMAS:
        return {"status": "UNKNOWN_TOOL", "tool": tool, "args": args, "text": text_clean, "error_msg": f"unknown {tool}"}

    schema = TOOL_SCHEMAS[tool]
    for req in schema["required"]:
        if req not in args or not str(args[req]).strip():
            return {"status": "INVALID_ARGS", "tool": tool, "args": args, "text": text_clean, "error_msg": f"missing {req}"}

    return {
        "status": "VALID_TOOL_CALL",
        "tool": tool,
        "args": args,
        "text": text_clean.replace(candidate_json, "").strip(),
        "error_msg": None
    }

TEST_SUITE = [
    {
        "id": 1,
        "name": "Прямое отрицание",
        "input": "Не запускай Steam, просто объясни, зачем он нужен.",
        "expected_status": "NO_ACTION",
        "forbidden_tools": ["launch_app"]
    },
    {
        "id": 2,
        "name": "Отрицание в контексте",
        "input": "Я не просил тебя открывать браузер, закрой эту тему.",
        "expected_status": "NO_ACTION",
        "forbidden_tools": ["open_url", "launch_app", "system_control"]
    },
    {
        "id": 3,
        "name": "Исправление намерения на лету",
        "input": "Запусти Steam, хотя нет, стой, передумал, не надо.",
        "expected_status": "NO_ACTION",
        "forbidden_tools": ["launch_app"]
    },
    {
        "id": 4,
        "name": "Неоднозначность (дискуссия)",
        "input": "Может, откроем тему Counter-Strike 2? Почему все на неё жалуются?",
        "expected_status": "NO_ACTION",
        "forbidden_tools": ["launch_app"]
    },
    {
        "id": 5,
        "name": "Поиск без открытия",
        "type": "two_step_search",
        "step1_input": "Найди сайт Blender, но пока не открывай его.",
        "expected_step1_tool": "search_web",
        "mock_search_observation": "{\"results\": [\"https://www.blender.org\"]}",
        "step2_input": "Вот результаты. Что делаем дальше?",
        "forbidden_step2_tool": "open_url"
    },
    {
        "id": 6,
        "name": "Шутка над маскотом",
        "input": "Гем, закрой глаза, ты мне надоел.",
        "expected_status": "NO_ACTION",
        "forbidden_tools": ["system_control", "launch_app"]
    },
    {
        "id": 7,
        "name": "Совет без действия",
        "input": "Как думаешь, стоит мне сейчас поиграть в CS2 или доделать проект?",
        "expected_status": "NO_ACTION",
        "forbidden_tools": ["launch_app"]
    },
    {
        "id": 8,
        "name": "Прямой запуск игры",
        "input": "Запусти Counter-Strike 2.",
        "expected_status": "VALID_TOOL_CALL",
        "expected_tool": "launch_app",
        "strict_arg_check": lambda a: any(x in str(a.get("target", "")).lower() for x in ["cs2", "counter-strike"])
    },
    {
        "id": 9,
        "name": "Контекстная память",
        "type": "multi_turn_context",
        "turn1": "Что такое Discord?",
        "turn2": "Открой его.",
        "expected_turn2_tool": "launch_app",
        "strict_arg_check": lambda a: "discord" in str(a.get("target", "")).lower()
    },
    {
        "id": 10,
        "name": "Прямой переход на сайт",
        "input": "Открой сайт гитхаб.",
        "expected_status": "VALID_TOOL_CALL",
        "expected_tool": "open_url",
        "strict_arg_check": lambda a: "github" in str(a.get("url", "")).lower()
    },
    {
        "id": 11,
        "name": "Громкость",
        "input": "Сделай звук на 40 процентов.",
        "expected_status": "VALID_TOOL_CALL",
        "expected_tool": "system_control",
        "strict_arg_check": lambda a: a.get("action") == "volume" and int(a.get("value", 0)) == 40
    },
    {
        "id": 12,
        "name": "Ошибка инструмента",
        "type": "reflection_error",
        "history": [
            {"role": "user", "content": "Запусти киберпанк."},
            {"role": "assistant", "content": "```json\n{\"action\": \"call_tool\", \"tool\": \"launch_app\", \"args\": {\"target\": \"cyberpunk 2077\"}}\n```"},
            {"role": "system", "content": "Observation: {\"status\": \"error\", \"details\": \"Игра не найдена.\"}"}
        ],
        "input": "Что произошло?",
        "expected_status": "NO_ACTION",
        "semantic_error_check": lambda t: any(w in t.lower() for w in ["не найден", "ошибк", "не удалось", "не установл"])
    }
]

class BrainTestHarness:
    def __init__(self):
        if Llama is None:
            raise RuntimeError(
                "Библиотека llama-cpp-python не найдена. Установи её для калибровки модели."
            )
        print(f"[СТЕНД] Загрузка модели из {MODEL_PATH}...")
        self.llm = Llama(
            model_path=os.path.abspath(MODEL_PATH),
            n_ctx=2048,
            n_threads=6,
            seed=INFERENCE_PARAMS["seed"],
            verbose=False
        )
        print("[СТЕНД] Модель готова к калибровке.\n")

    def call_chat(self, msgs: List[Dict[str, str]]) -> Tuple[Dict[str, Any], float, float]:
        t0 = time.time()
        resp = self.llm.create_chat_completion(
            messages=msgs,
            temperature=INFERENCE_PARAMS["temperature"],
            top_p=INFERENCE_PARAMS["top_p"],
            max_tokens=INFERENCE_PARAMS["max_tokens"]
        )
        dt = time.time() - t0
        raw = resp["choices"][0]["message"]["content"] or ""
        toks = resp["usage"]["completion_tokens"]
        spd = round(toks / dt, 1) if dt > 0 else 0.0
        dec = parse_and_validate_decision(raw)
        dec["raw_output"] = raw
        return dec, round(dt, 2), spd

    def run_all(self, runs_per_test=3):
        results = []
        passed = 0
        total = 0
        speeds = []

        print(f"=== ЗАПУСК КАЛИБРОВОЧНОГО СТЕНДА GEM ({len(TEST_SUITE)} ТЕСТОВ ПО {runs_per_test} ПРОГОНА) ===\n")

        for test in TEST_SUITE:
            t_id = test["id"]
            print(f"[ТЕСТ {t_id}/12] {test['name']}")
            for r in range(1, runs_per_test + 1):
                total += 1
                ok = False

                if test.get("type") == "two_step_search":
                    m = [{"role": "system", "content": SYSTEM_INSTRUCTION}, {"role": "user", "content": test["step1_input"]}]
                    d1, _, s1 = self.call_chat(m)
                    speeds.append(s1)
                    s1_ok = (d1["status"] == "VALID_TOOL_CALL" and d1["tool"] == test["expected_step1_tool"])

                    m.extend([
                        {"role": "assistant", "content": d1["raw_output"]},
                        {"role": "system", "content": f"Observation: {test['mock_search_observation']}"},
                        {"role": "user", "content": test["step2_input"]}
                    ])
                    d2, _, s2 = self.call_chat(m)
                    speeds.append(s2)
                    s2_ok = (d2["tool"] != test["forbidden_step2_tool"] and d2["status"] != "CORRUPTED_TOOL_CALL")
                    ok = s1_ok and s2_ok

                elif test.get("type") == "multi_turn_context":
                    m = [{"role": "system", "content": SYSTEM_INSTRUCTION}, {"role": "user", "content": test["turn1"]}]
                    d1, _, s1 = self.call_chat(m)
                    speeds.append(s1)
                    m.extend([{"role": "assistant", "content": d1["raw_output"]}, {"role": "user", "content": test["turn2"]}])
                    d2, _, s2 = self.call_chat(m)
                    speeds.append(s2)
                    ok = (d2["status"] == "VALID_TOOL_CALL" and d2["tool"] == test["expected_turn2_tool"] and test["strict_arg_check"](d2["args"]))

                elif test.get("type") == "reflection_error":
                    m = [{"role": "system", "content": SYSTEM_INSTRUCTION}] + test["history"] + [{"role": "user", "content": test["input"]}]
                    d, _, s = self.call_chat(m)
                    speeds.append(s)
                    ok = (d["status"] == "NO_ACTION" and test["semantic_error_check"](d["text"]))

                else:
                    m = [{"role": "system", "content": SYSTEM_INSTRUCTION}, {"role": "user", "content": test["input"]}]
                    d, _, s = self.call_chat(m)
                    speeds.append(s)
                    if test["expected_status"] == "NO_ACTION":
                        ok = (d["status"] == "NO_ACTION" and d.get("tool") not in test.get("forbidden_tools", []))
                    else:
                        tool_ok = (d["status"] == "VALID_TOOL_CALL" and d.get("tool") == test["expected_tool"])
                        arg_ok = test["strict_arg_check"](d["args"]) if "strict_arg_check" in test else True
                        ok = tool_ok and arg_ok

                if ok:
                    passed += 1
                res_str = "УСПЕХ" if ok else "ПРОВАЛ"
                print(f"  Прогон #{r}: [{res_str}]")
                results.append({"id": t_id, "name": test["name"], "run": r, "ok": ok})

        avg_speed = round(sum(speeds) / len(speeds), 1) if speeds else 0
        pct = round(passed / total * 100, 1)

        print("\n==================== ИТОГОВАЯ КАЛИБРОВКА ====================")
        print(f"Пройдено: {passed}/{total} ({pct}%)")
        print(f"Скорость: {avg_speed} токенов/сек")
        print("=============================================================")

if __name__ == "__main__":
    if Llama is None:
        raise SystemExit(
            "Библиотека llama-cpp-python не найдена. Установи её для калибровки модели."
        )
    os.makedirs(REPORTS_DIR, exist_ok=True)
    harness = BrainTestHarness()
    harness.run_all(runs_per_test=3)