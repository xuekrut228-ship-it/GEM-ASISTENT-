"""
Планировщик напоминаний Гема.
Задачи хранятся в data/reminders.json, проверяются каждые 10 секунд.
"""
import json
import os
import re
import threading
import time
import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
REMINDERS_PATH = os.path.join(DATA_DIR, "reminders.json")

UNIT_TO_SECONDS = {
    "секунд": 1, "секунду": 1, "сек": 1,
    "минут": 60, "минуту": 60, "мин": 60,
    "час": 3600, "часа": 3600, "часов": 3600,
}

_REL_RE = re.compile(r"\bнапомни\s+через\s+(\d+)\s*([а-яё]+)\s*(.*)", re.IGNORECASE)
_ABS_RE = re.compile(r"\bнапомни\s+в\s+(\d{1,2})[:\.,](\d{2})\s*(.*)", re.IGNORECASE)


def parse_reminder(text: str):
    """
    Возвращает (due_timestamp, payload) или None.
    Примеры: 'напомни через 20 минут купить хлеб', 'напомни в 18:30 чай'.
    """
    text = (text or "").strip()
    if not text:
        return None

    m = _REL_RE.search(text)
    if m:
        n = int(m.group(1))
        unit = m.group(2).lower()
        unit_key = next((k for k in UNIT_TO_SECONDS if unit.startswith(k)), None)
        if unit_key:
            due = time.time() + n * UNIT_TO_SECONDS[unit_key]
            payload = (m.group(3) or "").strip(" ,.!?")
            return due, (payload or "время вышло")

    m = _ABS_RE.search(text)
    if m:
        hh, mm = int(m.group(1)), int(m.group(2))
        if 0 <= hh < 24 and 0 <= mm < 60:
            now = datetime.datetime.now()
            target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if target <= now:
                target += datetime.timedelta(days=1)
            payload = (m.group(3) or "").strip(" ,.!?")
            return target.timestamp(), (payload or "время вышло")

    return None


class ReminderScheduler:
    def __init__(self, path: str = None):
        self.path = path or REMINDERS_PATH
        self._lock = threading.Lock()
        self._running = False
        self._on_fire = None
        self._items = self._load()

    def _load(self):
        try:
            if os.path.exists(self.path):
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return [it for it in data if isinstance(it, dict)]
        except Exception:
            pass
        return []

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self._items, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def add(self, due_ts: float, text: str) -> dict:
        with self._lock:
            item = {
                "id": int(time.time() * 1000),
                "due": float(due_ts),
                "text": (text or "").strip() or "время вышло",
                "fired": False,
            }
            self._items.append(item)
            self._save()
            return item

    def start(self, on_fire):
        if self._running:
            return
        self._on_fire = on_fire
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            time.sleep(10)
            now = time.time()
            due_items = []
            with self._lock:
                for it in self._items:
                    if not it.get("fired") and it.get("due", 0) <= now:
                        it["fired"] = True
                        due_items.append(it)
                if due_items:
                    fired = [it for it in self._items if it.get("fired")]
                    if len(fired) > 50:
                        keep_ids = {it.get("id") for it in fired[-50:]}
                        self._items = [
                            it for it in self._items
                            if not it.get("fired") or it.get("id") in keep_ids
                        ]
                    self._save()
            for it in due_items:
                try:
                    if self._on_fire:
                        self._on_fire(it.get("text", ""))
                except Exception:
                    pass
