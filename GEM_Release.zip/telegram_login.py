"""
Одноразовый вход в Telegram (создаёт сессию для Гема).

Запуск:  python telegram_login.py
Нужно: вписать telegram_api_id и telegram_api_hash в gem_config.json
(берутся на https://my.telegram.org — «API development tools»).
"""
import asyncio
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from config import load_config


async def main():
    try:
        from telethon import TelegramClient
    except ImportError:
        print("Telethon не установлен. Выполни: pip install telethon")
        return

    cfg = load_config()
    try:
        api_id = int(cfg.get("telegram_api_id") or 0)
    except (TypeError, ValueError):
        api_id = 0
    api_hash = (cfg.get("telegram_api_hash") or "").strip()

    if not api_id or not api_hash:
        print("Сначала впиши telegram_api_id и telegram_api_hash в gem_config.json")
        print("Взять их можно на https://my.telegram.org (создай приложение).")
        return

    session = os.path.join(ROOT, "data", "telegram_session")
    client = TelegramClient(session, api_id, api_hash)
    await client.start()
    me = await client.get_me()
    print(f"\nГотово. Вошёл как {me.first_name} (@{me.username}). Сессия сохранена.")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
