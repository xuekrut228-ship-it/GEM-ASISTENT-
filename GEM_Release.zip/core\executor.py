"""
Разбор плана Гема (JSON-блок) и выполнение действий на ПК.
Проактивные комментарии сюда не ходят — только явные просьбы пользователя.
"""
import json
import re
import time

from core import actions
from modules import tools

GEM_MARK = re.compile(r"###GEM###(.*?)###END###", re.DOTALL | re.IGNORECASE)

MAX_ACTIONS = 6
SAFE_BLOCKED = {"kill", "telegram", "type", "hotkey"}


def _first_json_object(src: str):
    start = src.find("{")
    if start < 0:
        return None, None
    depth = 0
    in_str = False
    esc = False
    for i, ch in enumerate(src[start:], start):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                blob = src[start : i + 1]
                return blob, (start, i + 1)
    return None, None


def extract_plan(raw: str) -> tuple:
    """Возвращает (речь, список действий)."""
    text = (raw or "").strip()
    if not text:
        return "", []

    blob = None
    m = GEM_MARK.search(text)
    if m:
        blob, _ = _first_json_object(m.group(1))
        text = (text[: m.start()] + text[m.end() :]).strip()
    if not blob:
        found, inner = _first_json_object(text)
        if found and '"actions"' in found:
            blob = found
            text = (text[: inner[0]] + text[inner[1] :]).strip()

    payload = {}
    if blob:
        try:
            payload = json.loads(blob)
        except json.JSONDecodeError:
            payload = {}

    if isinstance(payload, dict):
        say = (payload.get("say") or text or "").strip()
        acts = payload.get("actions") or []
        if not isinstance(acts, list):
            acts = []
        return say, acts[:MAX_ACTIONS]

    return text, []


def execute_actions(agent, acts: list) -> str:
    if not acts:
        return ""
    safe = bool(agent.config.get("safe_mode"))
    notes = []
    for raw in acts[:MAX_ACTIONS]:
        if not isinstance(raw, dict):
            continue
        kind = str(raw.get("type") or raw.get("action") or "").lower().strip()
        if safe and kind in SAFE_BLOCKED:
            notes.append(f"safe-mode: пропустил {kind}")
            continue
        note = _one(agent, kind, raw)
        if note:
            notes.append(note)
        time.sleep(0.12)
    return "; ".join(notes)


def _one(agent, kind: str, raw: dict) -> str:
    if kind in ("click", "click_norm"):
        ok = tools.click_norm(raw.get("x", 0.5), raw.get("y", 0.5), raw.get("button", "left"))
        return "кликнул" if ok else "клик не вышел"
    if kind == "double_click":
        sw, sh = tools._screen_size()
        nx, ny = float(raw.get("x", 0.5)), float(raw.get("y", 0.5))
        x = int(nx if nx > 1 else nx * (sw - 1))
        y = int(ny if ny > 1 else ny * (sh - 1))
        tools.mouse_double_click(x, y)
        return "двойной клик"
    if kind == "scroll":
        down = str(raw.get("dir") or raw.get("direction") or "down").lower() in ("down", "вниз")
        tools.mouse_scroll(-3 if down else 3)
        return "прокрутил"
    if kind in ("key", "press"):
        key = str(raw.get("key") or raw.get("name") or "").strip()
        if key and tools.press_key(key):
            return f"клавиша {key}"
        return ""
    if kind == "hotkey":
        keys = raw.get("keys") or []
        if isinstance(keys, str):
            keys = [k.strip() for k in keys.replace("+", " ").split() if k.strip()]
        if keys and tools.hotkey(*keys):
            return "хоткей"
        return ""
    if kind in ("type", "write"):
        payload = str(raw.get("text") or raw.get("payload") or "")
        if payload:
            tools.paste_text(payload)
            return "напечатал"
        return ""
    if kind in ("launch", "run", "open"):
        target = str(raw.get("target") or raw.get("app") or "").strip()
        if not target:
            return ""
        alias = ""
        if getattr(agent, "learner", None):
            alias = agent.learner.resolve_alias(target)
        ok = tools.run_app(target, alias=alias or None)
        if ok and getattr(agent, "learner", None):
            agent.learner.note_launch(target, tools.LAST_LAUNCH.get("matched") or "")
        return f"запустил {target}" if ok else f"не нашёл {target}"
    if kind == "kill":
        target = str(raw.get("target") or "").strip()
        if target:
            ok = tools.kill_target(target)
            return f"закрыл {target}" if ok else f"не закрыл {target}"
        return ""
    if kind in ("web", "url"):
        url = str(raw.get("url") or raw.get("target") or "").strip()
        if url:
            return actions.handle_web_navigation(url)
        return ""
    if kind == "youtube":
        q = str(raw.get("query") or raw.get("target") or "")
        return actions.handle_youtube_search(q)
    if kind == "volume":
        try:
            return tools.set_system_volume(int(raw.get("value", 50)))
        except (TypeError, ValueError):
            return ""
    if kind == "screenshot":
        return tools.take_screenshot()
    if kind == "minimize":
        tools.minimize_window()
        return "свернул"
    if kind == "maximize":
        tools.maximize_window()
        return "развернул"
    if kind == "wait":
        try:
            time.sleep(min(3.0, float(raw.get("seconds", 0.4))))
        except (TypeError, ValueError):
            time.sleep(0.4)
        return ""
    if kind == "telegram":
        to = str(raw.get("to") or raw.get("chat") or "").strip()
        msg = str(raw.get("text") or raw.get("message") or "").strip()
        if to and msg:
            resolved = _resolve_contact(agent, to)
            ok, err = agent.telegram.send_message(resolved, msg)
            return "написал в телегу" if ok else f"телега: {err}"
        return ""
    if kind in ("remember", "fact"):
        key = str(raw.get("key") or "заметка").strip()
        val = str(raw.get("value") or raw.get("text") or "").strip()
        if val:
            agent.memory.set_fact(key, val)
            return "запомнил"
        return ""
    return ""


def _resolve_contact(agent, name: str) -> str:
    fact = agent.memory.get_fact(name) if agent.memory else ""
    if fact:
        return fact
    return name
