"""
Telegram от имени пользователя (Telethon).

Настройка (один раз):
1. Возьми api_id и api_hash на https://my.telegram.org (создай приложение).
2. Впиши их в gem_config.json: telegram_api_id, telegram_api_hash.
3. Запусти `python telegram_login.py` и войди по номеру + коду.

После этого сессия хранится в data/telegram_session.session,
и Гем может писать сообщения сам.
"""
import os
import asyncio
import threading

try:
    from telethon import TelegramClient
except ImportError:
    TelegramClient = None

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SESSION_PATH = os.path.join(BASE_DIR, "data", "telegram_session")


class TelegramSender:
    def __init__(self, config):
        self.config = config
        try:
            self.api_id = int(config.get("telegram_api_id") or 0)
        except (TypeError, ValueError):
            self.api_id = 0
        self.api_hash = (config.get("telegram_api_hash") or "").strip()

    @property
    def ready(self) -> bool:
        return TelegramClient is not None and bool(self.api_id and self.api_hash)

    def _new_client(self):
        if TelegramClient is None or not self.ready:
            return None
        return TelegramClient(SESSION_PATH, self.api_id, self.api_hash)

    async def _send(self, chat: str, text: str):
        client = self._new_client()
        if client is None:
            return False, "Telegram не настроен: нужны telegram_api_id и telegram_api_hash."
        await client.connect()
        try:
            if not await client.is_user_authorized():
                return False, "Telegram не авторизован. Запусти один раз `python telegram_login.py`."
            entity = await client.get_entity(chat)
            await client.send_message(entity, text)
            return True, ""
        finally:
            await client.disconnect()

    def read_dialogs(self, limit=3):
        if not self.ready:
            return ""
        async def _read():
            client = self._new_client()
            await client.connect()
            if not await client.is_user_authorized():
                return "Не авторизован."
            dialogs = await client.get_dialogs(limit=limit)
            out = []
            for d in dialogs:
                msgs = await client.get_messages(d, limit=3)
                for m in msgs:
                    if m.text:
                        out.append(f"{d.name}: {m.text}")
            await client.disconnect()
            return "\n".join(out)
        try:
            return asyncio.run(_read())
        except Exception as e:
            return f"Ошибка: {e}"

    def send_message(self, chat: str, text: str):
        """Синхронная обёртка (агент у нас синхронный, а Telethon — асинхронный)."""
        if not self.ready:
            return False, "Telegram не настроен: впиши api_id/api_hash в gem_config.json и запусти telegram_login.py."
        result = {}

        def _run():
            try:
                result["ok"], result["err"] = asyncio.run(self._send(chat, text))
            except Exception as e:
                result["ok"], result["err"] = False, f"{e.__class__.__name__}: {e}"

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        t.join(timeout=60)
        if "ok" not in result:
            return False, "Telegram не ответил (таймаут)."
        return result["ok"], result["err"]
