import unittest
import urllib.error
from unittest.mock import Mock, patch
from io import BytesIO

from core.brain import Brain
from core.agent import GemAgent
from core.actions import normalize_app_name
from core.pipeline import ActionStep, TaskPipeline
from modules import tools


class _Personality:
    is_sulking = False

    def analyze_tone_and_adjust(self, _text):
        pass

    def format_reply(self, text):
        return text


class TaskPipelineTests(unittest.TestCase):
    def test_write_preserves_case_and_message_punctuation(self):
        steps = TaskPipeline.parse_sequence("Напиши Привет, Мир! И до встречи.")

        self.assertEqual(len(steps), 1)
        self.assertEqual(steps[0].action_type, "WRITE")
        self.assertEqual(steps[0].payload, "Привет, Мир! И до встречи.")

    def test_chain_splits_only_before_another_command(self):
        steps = TaskPipeline.parse_sequence(
            "Открой браузер и напиши Привет, Мир! Затем открой Steam."
        )

        self.assertEqual(
            [(step.action_type, step.payload) for step in steps],
            [
                ("RUN", "браузер"),
                ("WRITE", "Привет, Мир!"),
                ("RUN", "steam"),
            ],
        )

    def test_safe_mode_skips_typing_and_process_termination(self):
        steps = [
            ActionStep("WRITE", "Do not type"),
            ActionStep("KILL", "notepad"),
        ]

        with (
            patch("core.pipeline.tools.paste_text") as paste_text,
            patch("core.pipeline.tools.kill_target") as kill_target,
        ):
            result = TaskPipeline.execute_chain(steps, safe_mode=True)

        paste_text.assert_not_called()
        kill_target.assert_not_called()
        self.assertIn("пропустил write", result)
        self.assertIn("пропустил kill", result)

    def test_safe_mode_blocks_direct_telegram_send(self):
        agent = object.__new__(GemAgent)
        agent.config = {"safe_mode": True}
        agent.memory = Mock()
        agent.telegram = Mock()
        agent.personality = _Personality()

        reply = agent._try_telegram("Напиши маме в телеграм: Привет!")

        agent.telegram.send_message.assert_not_called()
        self.assertIn("отправка сообщений", reply)

    def test_safe_mode_blocks_direct_process_termination(self):
        agent = object.__new__(GemAgent)
        agent.config = {"safe_mode": True}
        agent.memory = Mock()
        agent.telegram = Mock()
        agent.personality = _Personality()

        with patch("core.agent.tools.kill_target") as kill_target:
            reply = agent.execute_plan("Закрой notepad")

        kill_target.assert_not_called()
        self.assertIn("закрытие процессов", reply)

    def test_single_write_keeps_case(self):
        agent = object.__new__(GemAgent)
        agent.config = {"safe_mode": False}
        agent.memory = Mock()
        agent.telegram = Mock()
        agent.personality = _Personality()

        with patch("core.agent.tools.paste_text") as paste_text:
            agent.execute_plan("Напиши Привет, Мир!")

        paste_text.assert_called_once_with("Привет, Мир!")

    def test_safe_mode_blocks_single_write(self):
        agent = object.__new__(GemAgent)
        agent.config = {"safe_mode": True}
        agent.memory = Mock()
        agent.telegram = Mock()
        agent.personality = _Personality()

        with patch("core.agent.tools.paste_text") as paste_text:
            reply = agent.execute_plan("Напиши Привет!")

        paste_text.assert_not_called()
        self.assertIn("ввод текста", reply)

    def test_app_launch_prefers_exact_match_over_partial_match(self):
        with (
            patch(
                "modules.tools.get_system_apps",
                return_value={
                    "chrome remote desktop": "remote.exe",
                    "chrome": "chrome.exe",
                },
            ),
            patch("modules.tools.shell32.ShellExecuteW", return_value=33) as shell_execute,
        ):
            self.assertTrue(tools.run_app("chrome"))

        self.assertEqual(shell_execute.call_args.args[2], "chrome.exe")

    def test_edge_voice_transcription_variants_resolve_to_installed_app(self):
        app_target = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
        for spoken_name in ("майкрасофт эдж", "майкрософт эдс", "эдж"):
            with self.subTest(spoken_name=spoken_name):
                self.assertEqual(normalize_app_name(spoken_name), "microsoft edge")

        with (
            patch("modules.tools.get_system_apps", return_value={"microsoft edge": app_target}),
            patch("modules.tools.shell32.ShellExecuteW", return_value=33) as shell_execute,
        ):
            self.assertTrue(tools.run_app("майкрасофт эдж"))

        self.assertEqual(shell_execute.call_args.args[2], app_target)

    def test_windows_start_apps_are_indexed_for_packaged_apps(self):
        db = {}
        result = Mock(
            returncode=0,
            stdout='{"Name":"Microsoft Edge","AppID":"MSEdge"}',
        )
        with patch("modules.tools.os.name", "nt"), patch(
            "modules.tools.subprocess.run", return_value=result
        ) as run:
            tools._scan_windows_start_apps(db)

        run.assert_called_once()
        self.assertEqual(db["microsoft edge"], r"shell:AppsFolder\MSEdge")

    def test_gemini_http_error_shows_google_detail_without_leaking_key(self):
        brain = object.__new__(Brain)
        brain.api_key = "private-test-key"
        brain.cloud_model = "gemini-test"
        brain._system_prompt = Mock(return_value="system")
        brain._gemini_contents = Mock(return_value=[])
        error_body = (
            b'{"error":{"message":"Model not found for key private-test-key"}}'
        )
        http_error = urllib.error.HTTPError(
            "https://example.invalid",
            404,
            "Not Found",
            {},
            BytesIO(error_body),
        )

        with patch("core.brain.urllib.request.urlopen", side_effect=http_error):
            reply = brain._ask_gemini("test", 50, None)

        self.assertIn("HTTP 404", reply)
        self.assertIn("Model not found", reply)
        self.assertNotIn("private-test-key", reply)
        self.assertIn("[ключ скрыт]", reply)


if __name__ == "__main__":
    unittest.main()
