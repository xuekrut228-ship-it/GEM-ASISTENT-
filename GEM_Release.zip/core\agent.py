"""
Главный диспетчер агента Гем.
Оркестрация действий, последовательные цепочки (Pipeline) и характер.
"""
import re
import time
import random
import datetime
from modules import tools
from modules.telegram import TelegramSender
from modules.scheduler import parse_reminder
from core import actions
from core.pipeline import TaskPipeline
from core.memory import MultiLevelMemory
from core.brain import Brain
from core.learner import Learner
from core.executor import execute_actions

class DynamicPersonality:
    def __init__(self, memory: MultiLevelMemory):
        self.memory = memory
        try:
            self.attitude_score = int(self.memory.get_fact("attitude_score") or 50)
        except Exception:
            self.attitude_score = 50
        self.sulk_until = 0.0

    @property
    def is_sulking(self) -> bool:
        return time.time() < self.sulk_until

    def trigger_sulk(self, minutes: int = None):
        if minutes is None:
            minutes = random.randint(10, 30)
        self.sulk_until = time.time() + (minutes * 60)

    def forgive(self):
        self.sulk_until = 0.0

    def analyze_tone_and_adjust(self, user_text: str):
        text_l = user_text.lower()
        if any(w in text_l for w in ["прости", "извини", "сорян", "был не прав"]):
            self.forgive()
            self.attitude_score = min(100, self.attitude_score + 10)
            self.memory.set_fact("attitude_score", str(self.attitude_score), category="personality")
            return

        heavy_insults = ["пошел нахуй", "иди нахуй", "соси", "уебок", "мразь", "гандон", "завали ебало"]
        harsh_triggers = ["заткнись", "быстро", "бля", "нахуй", "дебил", "тупой", "урод", "хули", "еблан", "сука", "рот закрой"]
        gentle_triggers = ["спасибо", "пожалуйста", "друг", "молодец", "красава", "как ты", "приятно", "родной"]

        delta = 0
        if any(w in text_l for w in heavy_insults):
            delta -= 22
            self.trigger_sulk(random.randint(15, 40))
        elif any(w in text_l for w in harsh_triggers):
            delta -= 8

        if any(w in text_l for w in gentle_triggers):
            delta += 4

        if delta != 0:
            self.attitude_score = max(0, min(100, self.attitude_score + delta))
            self.memory.set_fact("attitude_score", str(self.attitude_score), category="personality")

    def format_reply(self, base_text: str) -> str:
        if self.attitude_score < 25:
            prefixes = ["Сам бы не справился? ", "Сделал, но ты бесишь. ", "Подавись: ", "Только чтобы ты замолчал: "]
            return random.choice(prefixes) + base_text
        elif self.attitude_score > 75:
            prefixes = ["Без проблем. ", "Сделано: ", "Держи: "]
            return random.choice(prefixes) + base_text
        return base_text

# ---------- Реестр интентов execute_plan ----------
# Проверка смотрит на cmd_l и решает, «наша» ли это команда. Обработчик либо
# возвращает готовую реплику (уже записанную в память), либо None — тогда
# реестр идёт дальше, как раньше шла следующая ветка if/else.

KILL_WORDS = ("закрой", "выруби", "убей", "останови", "выключи")
KILL_STRIP_RE = re.compile(
    r"\b(закрой|выруби|убей|останови|выключи|приложение|программу|процесс|гем|пожалуйста)\b"
)
WEB_HINTS = ("сайт", "страниц", ".com", ".ru", ".org", "http")
WEB_STRIP_RE = re.compile(
    r"\b(открой|запусти|перейди|зайди|на|в|сайт|страницу|вкладку|гем|пожалуйста)\b"
)
YOUTUBE_WORDS = (
    "ютуб", "youtube", "видос", "видео", "ролик", "видеоролик",
    "клип", "песн", "трек", "музык", "плейлист", "стрим",
)
MEDIA_HINTS = (
    "ютуб", "youtube", "видос", "видео", "ролик", "клип",
    "музык", "песн", "трек", "стрим", "плейлист",
)
LAUNCH_WORDS = ("открой", "запусти", "вруби", "включи")
LAUNCH_STRIP_RE = re.compile(
    r"\b(открой|запусти|вруби|включи|приложение|игру|программу|файл|гем|пожалуйста)\b"
)
VOLUME_GUARD_RE = re.compile(r"громкост|звук\s*\d")
VOLUME_RE = re.compile(r"\b(?:громкост[ья]|звук)\s*(\d+)")
SCREENSHOT_WORDS = ("скрин", "скриншот", "снимок")
MINIMIZE_WORDS = ("сверни", "свернуть", "минимизируй")
MAXIMIZE_WORDS = ("разверни", "развернуть", "максимизируй", "распахни")
CLICK_WORDS = ("кликни", "щёлкни", "щелкни")
CLICK_VISION_HINTS = (" на ", "кноп", "экран", "сюда", "туда", "икон")
PRESS_WORDS = ("нажми", "жми")
PRESS_STRIP_RE = re.compile(r"\b(нажми|жми|клавишу|кнопку|гем|пожалуйста)\b")
GAME_HINT_WORDS = ("в игре", "по игре", "застрял")
VISION_KEYS = (
    "на экране", "что видишь", "что происходит", "опиши экран",
    "посмотри на экран", "глянь на экран",
)
HIDE_WORDS = ("уйди", "спрячься", "исчезни", "отвали")
SHOW_WORDS = ("вернись", "выйди", "появись", "покажись")
REMEMBER_RE = re.compile(r"\bзапомни(?:,\s*что|\s+что|\s+)?\s+(.+)")
REMEMBER_SPLIT_RE = re.compile(r"\s+(?:это|—|-)\s+")


def _is_web(low: str) -> bool:
    return any(word in low for word in WEB_HINTS)


def _match_reminder(agent, raw, low):
    return parse_reminder(raw) is not None


def _match_pipeline(agent, raw, low):
    return bool(TaskPipeline.parse_sequence(raw))


def _match_remember(agent, raw, low):
    return bool(REMEMBER_RE.search(low))


def _match_kill(agent, raw, low):
    return any(word in low for word in KILL_WORDS)


def _match_web(agent, raw, low):
    target = WEB_STRIP_RE.sub("", low).strip()
    return target in actions.COMMON_SITES or (_is_web(low) and "." in target)


def _match_youtube(agent, raw, low):
    return any(word in low for word in YOUTUBE_WORDS) or ("видео" in low and not _is_web(low))


def _match_launch(agent, raw, low):
    return any(word in low for word in LAUNCH_WORDS) and not VOLUME_GUARD_RE.search(low)


def _match_volume(agent, raw, low):
    return bool(VOLUME_RE.search(low))


def _match_screenshot(agent, raw, low):
    return any(word in low for word in SCREENSHOT_WORDS)


def _match_minimize(agent, raw, low):
    return any(word in low for word in MINIMIZE_WORDS)


def _match_maximize(agent, raw, low):
    return any(word in low for word in MAXIMIZE_WORDS)


def _match_scroll(agent, raw, low):
    return "скролл" in low or "прокрут" in low


def _match_click(agent, raw, low):
    if not any(word in low for word in CLICK_WORDS):
        return False
    return not any(hint in low for hint in CLICK_VISION_HINTS)


def _match_press_key(agent, raw, low):
    return any(word in low for word in PRESS_WORDS) and " на " not in low


def _match_game_hint(agent, raw, low):
    return any(word in low for word in GAME_HINT_WORDS)


def _match_vision(agent, raw, low):
    return any(key in low for key in VISION_KEYS)


def _match_brain_plan(agent, raw, low):
    return agent._wants_screen(low) or agent._wants_control(low)

def _match_hide(agent, raw, low):
    return any(w in low for w in HIDE_WORDS) and len(low) <= 20

def _match_show(agent, raw, low):
    return any(w in low for w in SHOW_WORDS) and len(low) <= 20


# Порядок важен: он повторяет прежнюю цепочку if/else.
INTENT_REGISTRY = (
    ("reminder", _match_reminder, "_intent_reminder"),
    ("pipeline", _match_pipeline, "_intent_pipeline"),
    ("remember", _match_remember, "_intent_remember"),
    ("kill", _match_kill, "_intent_kill"),
    ("web", _match_web, "_intent_web"),
    ("youtube", _match_youtube, "_intent_youtube"),
    ("launch", _match_launch, "_intent_launch"),
    ("volume", _match_volume, "_intent_volume"),
    ("screenshot", _match_screenshot, "_intent_screenshot"),
    ("minimize", _match_minimize, "_intent_minimize"),
    ("maximize", _match_maximize, "_intent_maximize"),
    ("scroll", _match_scroll, "_intent_scroll"),
    ("click", _match_click, "_intent_click"),
    ("press_key", _match_press_key, "_intent_press_key"),
    ("game_hint", _match_game_hint, "_intent_game_hint"),
    ("vision", _match_vision, "_intent_vision"),
    ("hide", _match_hide, "_intent_hide"),
    ("show", _match_show, "_intent_show"),
    ("brain_plan", _match_brain_plan, "_intent_brain_plan"),
)


class GemAgent:
    def __init__(self, config: dict, memory: MultiLevelMemory, mascot_controller=None):
        self.config = config
        self.memory = memory
        self.mascot = mascot_controller
        self.personality = DynamicPersonality(self.memory)
        self.brain = Brain(self.memory, self.config)
        self.telegram = TelegramSender(self.config)
        self.learner = Learner(self.memory, self.config)

    def execute_plan(self, user_text: str) -> str:
        clean_raw = user_text.strip()
        if not clean_raw:
            return "..."

        cmd_l = clean_raw.lower()
        self.memory.log_episode("user", clean_raw)

        # 0. DEV-команды
        if cmd_l.startswith("//") or cmd_l.startswith("dev:"):
            return self._handle_dev(cmd_l)

        # Настроение и обида
        self.personality.analyze_tone_and_adjust(clean_raw)
        if self.personality.is_sulking:
            reply = random.choice([
                "Даже не проси. Я с тобой не разговариваю.",
                "Отвали. Вспомни, что ты только что сказал.",
                "Игнорирую. Посиди и подумай над своим поведением."
            ])
            self.memory.log_episode("gem", reply)
            return reply

        tg_reply = self._try_telegram(clean_raw)
        if tg_reply is not None:
            self.memory.log_episode("gem", tg_reply)
            return tg_reply

        # Дальше — реестр интентов: первая совпавшая проверка обрабатывает команду.
        handled = self._dispatch_intents(clean_raw, cmd_l)
        if handled is not None:
            return handled

        reply = self.brain.ask(clean_raw, attitude_score=self.personality.attitude_score)
        self.memory.log_episode("gem", reply)
        return reply

    # ---------- обработчики интентов ----------
    def _finish(self, message: str) -> str:
        """Оформить реплику характером и записать эпизод."""
        reply = self.personality.format_reply(message)
        self.memory.log_episode("gem", reply)
        return reply

    def _dispatch_intents(self, clean_raw: str, cmd_l: str):
        """Первый подходящий интент забирает команду; None — ни один не подошёл."""
        for _name, matcher, handler_name in INTENT_REGISTRY:
            if not matcher(self, clean_raw, cmd_l):
                continue
            reply = getattr(self, handler_name)(clean_raw, cmd_l)
            if reply is not None:
                return reply
        return None

    def _intent_reminder(self, clean_raw, cmd_l):
        parsed = parse_reminder(clean_raw)
        if not parsed:
            return None
        due_ts, payload = parsed
        scheduler = getattr(self, "scheduler", None)
        if scheduler is None:
            return self._finish("Планировщик сейчас не подключён.")
        scheduler.add(due_ts, payload)
        if "через" in cmd_l:
            delta = max(0, int(due_ts - time.time()))
            if delta < 60:
                eta = f"{delta} сек."
            elif delta < 3600:
                eta = f"{max(1, delta // 60)} мин."
            else:
                eta = f"{max(1, delta // 3600)} ч."
            return self._finish(f"Запомнил. Напомню через {eta}: «{payload}».")
        target = datetime.datetime.fromtimestamp(due_ts)
        return self._finish(f"Запомнил. Напомню в {target.strftime('%H:%M')}: «{payload}».")

    def _intent_pipeline(self, clean_raw, cmd_l):
        steps = TaskPipeline.parse_sequence(clean_raw)
        if len(steps) > 1:
            result_msg = TaskPipeline.execute_chain(
                steps,
                safe_mode=bool(self.config.get("safe_mode")),
            )
            return self._finish(result_msg) if result_msg else None
        if len(steps) == 1 and steps[0].action_type == "WRITE":
            if self.config.get("safe_mode"):
                return self._finish("Безопасный режим: ввод текста отключён.")
            tools.paste_text(steps[0].payload)
            return self._finish(f"Напечатал: «{steps[0].payload}».")
        return None

    def _intent_remember(self, clean_raw, cmd_l):
        rem = REMEMBER_RE.search(cmd_l)
        if not rem:
            return None
        payload = rem.group(1).strip()
        parts = REMEMBER_SPLIT_RE.split(payload, maxsplit=1)
        key, value = (parts[0].strip(), parts[1].strip()) if len(parts) == 2 else ("заметка", payload)
        self.memory.set_fact(key, value)
        return self._finish(f"Вплёл в память: {key} — {value}.")

    def _intent_kill(self, clean_raw, cmd_l):
        target = KILL_STRIP_RE.sub("", cmd_l).strip()
        if not target:
            return None
        if self.config.get("safe_mode"):
            return self._finish("Безопасный режим: закрытие процессов отключено.")
        ok = tools.kill_target(target)
        self.memory.track_habit("закрывает", target)
        return self._finish(f"Процесс «{target}» усыплен." if ok else f"Не нашел активный «{target}».")

    def _intent_web(self, clean_raw, cmd_l):
        target = WEB_STRIP_RE.sub("", cmd_l).strip()
        return self._finish(actions.handle_web_navigation(target))

    def _intent_youtube(self, clean_raw, cmd_l):
        return self._finish(actions.handle_youtube_search(cmd_l))

    def _intent_launch(self, clean_raw, cmd_l):
        target = LAUNCH_STRIP_RE.sub("", cmd_l).strip()
        if not target:
            return None

        # Словарь популярных игр (русское название -> английское)
        GAME_ALIASES = {
            "вар тандер": "war thunder",
            "вартандер": "war thunder",
            "кс": "counter-strike",
            "кс 2": "counter-strike 2",
            "кс2": "counter-strike 2",
            "дота": "dota 2",
            "дота 2": "dota 2",
            "майнкрафт": "minecraft",
            "майн": "minecraft",
            "робикс": "roblox",
            "роблокс": "roblox",
            "танки": "world of tanks",
            "гта": "gta",
            "гта 5": "gta 5",
            "фортнайт": "fortnite",
        }
        for ru_name, en_name in GAME_ALIASES.items():
            if ru_name in target:
                target = target.replace(ru_name, en_name)

        # Если пользователь наговорил целое предложение, вытаскиваем из него
        # название установленной игры/программы (самое длинное совпадение).
        try:
            apps = tools.get_system_apps()
            best_match = ""
            for app in apps:
                if app in target and len(app) > len(best_match):
                    best_match = app
            if best_match:
                target = best_match
        except Exception:
            pass

        # Медиа-запрос — всегда в YouTube, а не в поиск файлов на дисках
        if any(hint in target for hint in MEDIA_HINTS):
            return self._finish(actions.handle_youtube_search(cmd_l))
        alias = self.learner.resolve_alias(target)
        ok = False
        if alias:
            ok = tools.run_app(target, alias=alias)
            msg = f"Запустил: {target}." if ok else actions.handle_run_chain(target)
        else:
            msg = actions.handle_run_chain(target)
            
        # Если не нашли на диске, а игра похожа на Steam-игру — пробуем запустить через Steam
        STEAM_IDS = {
            "war thunder": "236390",
            "вар тандер": "236390",
            "cs2": "730",
            "cs 2": "730",
            "counter-strike 2": "730",
            "counter-strike": "730",
            "dota 2": "570",
            "dota": "570",
            "gta 5": "271590",
            "gta v": "271590",
            "rust": "252490",
            "apex legends": "1172470",
            "apex": "1172470",
            "pubg": "578080",
        }
        if not ok:
            target_low = target.lower()
            for game_name, app_id in STEAM_IDS.items():
                if game_name in target_low:
                    try:
                        import os
                        os.startfile(f"steam://rungameid/{app_id}")
                        ok = True
                        msg = f"Запустил {target} через Steam."
                    except Exception:
                        pass
                    break

        self.learner.note_launch(target, tools.LAST_LAUNCH.get("matched") or "")

        # После успешного запуска — короткий взгляд на экран и комментарий
        if ok and getattr(self, "mascot", None):
            if not getattr(self, "_commenting_launch", False):
                self._commenting_launch = True
                import threading
                def _comment_launch():
                    time.sleep(1.8)
                    try:
                        img = tools.grab_screenshot_image()
                        reply = self.brain.comment(
                            f"{self.brain.user_name} только что открыл «{target}». "
                            "Посмотри на экран и одной короткой фразой (не больше 2 предложений) "
                            "прокомментируй в своём стиле — что видишь и что думаешь.",
                            attitude_score=self.personality.attitude_score,
                            image=img,
                        )
                        if reply and self.mascot:
                            self.mascot.say(reply)
                    except Exception:
                        pass
                    finally:
                        self._commenting_launch = False
                threading.Thread(target=_comment_launch, daemon=True).start()

        return self._finish(msg)

    def _intent_hide(self, clean_raw, cmd_l):
        if getattr(self, "mascot", None):
            self.mascot.hide_at_edge()
            return self._finish("Ухожу в тень. Зови, если понадоблюсь.")
        return None

    def _intent_show(self, clean_raw, cmd_l):
        if getattr(self, "mascot", None):
            self.mascot.show_from_edge()
            return self._finish("Я здесь. Чего хотел?")
        return None

    def _intent_volume(self, clean_raw, cmd_l):
        vol = VOLUME_RE.search(cmd_l)
        if not vol:
            return None
        return self._finish(tools.set_system_volume(int(vol.group(1))))

    def _intent_screenshot(self, clean_raw, cmd_l):
        return self._finish(tools.take_screenshot())

    def _intent_minimize(self, clean_raw, cmd_l):
        tools.minimize_window()
        return self._finish("Свернул окно.")

    def _intent_maximize(self, clean_raw, cmd_l):
        tools.maximize_window()
        return self._finish("Развернул на весь экран.")

    def _intent_scroll(self, clean_raw, cmd_l):
        down = any(word in cmd_l for word in ("вниз", "ниже"))
        tools.mouse_scroll(-3 if down else 3)
        return self._finish("Прокрутил " + ("вниз." if down else "вверх."))

    def _intent_click(self, clean_raw, cmd_l):
        tools.mouse_click()
        return self._finish("Кликнул.")

    def _intent_press_key(self, clean_raw, cmd_l):
        key = PRESS_STRIP_RE.sub("", cmd_l).strip()
        if not key:
            return None
        ok = tools.press_key(key)
        return self._finish(f"Нажал «{key}»." if ok else f"Не знаю клавишу «{key}».")

    def _intent_game_hint(self, clean_raw, cmd_l):
        prompt = (
            "Глянь на скриншот. Если это игра — дай одну короткую игровую подсказку: "
            "что происходит и что стоит сделать. Если не игра — коротко скажи, что видишь."
        )
        img = tools.grab_screenshot_image()
        reply = self.brain.ask(prompt, attitude_score=self.personality.attitude_score, image=img)
        self.memory.log_episode("gem", reply)
        return reply

    def _intent_vision(self, clean_raw, cmd_l):
        img = tools.grab_screenshot_image()
        reply = self.brain.ask(clean_raw, attitude_score=self.personality.attitude_score, image=img)
        self.memory.log_episode("gem", reply)
        return reply

    def _intent_brain_plan(self, clean_raw, cmd_l):
        need_eyes = self._wants_screen(cmd_l)
        need_hands = self._wants_control(cmd_l)
        img = tools.grab_screenshot_image() if need_eyes else None
        plan = self.brain.plan(clean_raw, attitude_score=self.personality.attitude_score, image=img)
        extra = execute_actions(self, plan.get("actions") or [])
        reply = plan.get("say") or ""
        if extra and extra not in reply:
            reply = (reply + " " + extra).strip() if reply else extra
        return self._finish(reply or "...")

    def _wants_screen(self, cmd_l: str) -> bool:
        keys = (
            "на экране", "что видишь", "что происходит", "глянь", "посмотри",
            "в игре", "по игре", "застрял", "подскажи", "что делать",
            "кнопк", "кликни на", "нажми на", "ткни", "наведи", "найди на экране",
        )
        return any(k in cmd_l for k in keys)

    def _wants_control(self, cmd_l: str) -> bool:
        keys = (
            "кликни", "нажми на", "ткни", "наведи", "сделай за меня",
            "сам нажми", "пройди", "выбери", "поставь курсор", "двойной клик",
            "напиши в", "отправь", "запусти сам",
        )
        return any(k in cmd_l for k in keys)

    def _try_telegram(self, original: str):
        patterns = [
            r"(?i)\b(?:напиши|отправь|кинь|скинь|пошли)\s+(.+?)\s+в\s+(?:телеграм|телегу|телеге|telegram)\s*:?\s*(.+)",
            r"(?i)\b(?:напиши|отправь|кинь)\s+в\s+(?:телеграм|телегу|телеге|telegram)\s+(?:диалог\s+|чат\s+)?(.+?)\s*[:—\-]\s*(.+)",
            r"(?i)\b(?:телеграм|телега|telegram)\s+(?:напиши\s+)?(.+?)\s*[:—\-]\s*(.+)",
        ]
        for pat in patterns:
            tg = re.search(pat, original.strip())
            if not tg:
                continue
            recipient, message = tg.group(1).strip(), tg.group(2).strip()
            if not recipient or not message:
                continue
            if self.config.get("safe_mode"):
                return self.personality.format_reply(
                    "Безопасный режим: отправка сообщений в Telegram отключена."
                )
            resolved = self.memory.get_fact(recipient) or recipient
            ok, err = self.telegram.send_message(resolved, message)
            return self.personality.format_reply(
                f"Отправил «{recipient}» в телегу." if ok else f"Телега не вышла: {err}"
            )
        return None

    def _handle_dev(self, cmd_l: str) -> str:
        if "//forgive" in cmd_l:
            self.personality.forgive()
            return "[DEV] Обида снята."
        score_match = re.search(r"//score\s*([+-]?\d+)", cmd_l)
        if score_match:
            val = int(score_match.group(1))
            if "+" in score_match.group(0) or "-" in score_match.group(0):
                self.personality.attitude_score = max(0, min(100, self.personality.attitude_score + val))
            else:
                self.personality.attitude_score = max(0, min(100, val))
            self.memory.set_fact("attitude_score", str(self.personality.attitude_score), category="personality")
            return f"[DEV] Отношение: {self.personality.attitude_score}/100"
        if "//tone" in cmd_l:
            if any(w in cmd_l for w in ["friend", "frand", "добр"]):
                mode, val = "FRIENDLY", 90
            elif any(w in cmd_l for w in ["tox", "зл", "токс"]):
                mode, val = "TOXIC", 10
            else:
                mode, val = "NEUTRAL", 50
            self.personality.attitude_score = val
            self.memory.set_fact("attitude_score", str(val), category="personality")
            return f"[DEV] Режим: {mode} ({val}/100)"
        if "//clear" in cmd_l:
            self.brain.chat_history.clear()
            self.memory.clear_episodes()
            return "[DEV] Память сброшена."
        if "//stat" in cmd_l or "//debug" in cmd_l:
            sulk_str = "ДА" if self.personality.is_sulking else "НЕТ"
            return (
                f"[DEV] Очки: {self.personality.attitude_score}/100 | Обида: {sulk_str} | "
                f"Модель: {self.brain.active_model_name} | Тон: {self.config.get('cruelty_level')}"
            )
        if "//reindex" in cmd_l:
            tools.refresh_apps()
            return f"[DEV] Индекс приложений: {len(tools.get_system_apps())}."
        return "[DEV] //score, //tone, //stat, //forgive, //clear, //reindex"