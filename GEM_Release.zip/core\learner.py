"""
Обучение Гема по действиям пользователя: окна, игры, команды, псевдонимы.
Не нейросеть с нуля — живой портрет, который меняет тон и подсказки.
"""
import time


class Learner:
    def __init__(self, memory, config):
        self.memory = memory
        self.config = config
        self._switches = 0

    @property
    def enabled(self) -> bool:
        return bool(self.config.get("learn_from_activity", True))

    def note_app(self, app: str, title: str = "", is_game: bool = False):
        if not self.enabled or not app:
            return
        self.memory.add_observation(app, title, is_game)
        self.memory.track_habit("смотрит", app)
        if is_game:
            self.memory.track_habit("играет", app)
        self._switches += 1
        if self._switches % 12 == 0:
            self._refresh_portrait()

    def note_launch(self, query: str, matched: str = ""):
        if not self.enabled:
            return
        q = (query or "").strip().lower()
        if not q:
            return
        self.memory.track_habit("открывает", q)
        if matched and matched != q:
            self.memory.set_alias(q, matched)

    def resolve_alias(self, name: str) -> str:
        return self.memory.get_alias(name) or ""

    def context(self) -> str:
        if not self.memory:
            return ""
        return self.memory.get_profile_context()

    def _refresh_portrait(self):
        portrait = self.memory.get_profile_context()
        if portrait:
            self.memory.set_fact("портрет", portrait, category="personality", source="observer")
        hour = time.localtime().tm_hour
        if 0 <= hour < 6:
            style = "ночью говорит короче и тише"
        elif hour < 12:
            style = "утром можно чуть бодрее"
        elif hour < 18:
            style = "днём обычный ехидный тон"
        else:
            style = "вечером можно залипнуть в игры вместе"
        self.memory.set_fact("подход_по_времени", style, category="personality", source="observer")
