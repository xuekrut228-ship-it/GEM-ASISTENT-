"""
Модуль памяти Гема (SQLite).
"""
import os
import sqlite3
import datetime
from contextlib import closing

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DEFAULT_DB_PATH = os.path.join(DATA_DIR, "memory.db")

class MultiLevelMemory:
    def __init__(self, db_path: str = None):
        if db_path is None:
            os.makedirs(DATA_DIR, exist_ok=True)
            self.db_path = os.path.abspath(DEFAULT_DB_PATH)
        else:
            self.db_path = os.path.abspath(db_path)
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_schema()

    def _conn(self):
        return sqlite3.connect(self.db_path, timeout=10.0)

    def _init_schema(self):
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT DEFAULT 'general',
                    key TEXT UNIQUE,
                    value TEXT,
                    confidence REAL DEFAULT 1.0,
                    source TEXT DEFAULT 'user_dialog',
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS episodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    role TEXT,
                    content TEXT,
                    timestamp TIMESTAMP
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS habits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action_type TEXT,
                    target TEXT,
                    frequency INTEGER DEFAULT 1,
                    last_used TIMESTAMP
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS custom_skills (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    skill_name TEXT UNIQUE,
                    description TEXT,
                    steps_json TEXT,
                    created_at TIMESTAMP
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app TEXT,
                    title TEXT,
                    is_game INTEGER DEFAULT 0,
                    hour INTEGER,
                    weekday INTEGER,
                    timestamp TIMESTAMP
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS aliases (
                    name TEXT PRIMARY KEY,
                    target TEXT
                )
            """)
            conn.commit()

    def set_fact(self, key: str, value: str, category: str = "general", confidence: float = 1.0, source: str = "user"):
        now = datetime.datetime.now().isoformat()
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO facts (category, key, value, confidence, source, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    confidence = excluded.confidence,
                    updated_at = excluded.updated_at
            """, (category, key.strip().lower(), value.strip(), confidence, source, now, now))
            conn.commit()

    def get_fact(self, key: str) -> str:
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("SELECT value FROM facts WHERE key = ?", (key.strip().lower(),))
            row = cur.fetchone()
            return row[0] if row else ""

    def get_all_facts_context(self) -> str:
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("SELECT category, key, value FROM facts ORDER BY category, key")
            rows = cur.fetchall()
            if not rows:
                return "Память чиста."
            return "\n".join(f"[{cat}] {k}: {v}" for cat, k, v in rows)

    def log_episode(self, role: str, content: str):
        now = datetime.datetime.now().isoformat()
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("INSERT INTO episodes (role, content, timestamp) VALUES (?, ?, ?)", (role, content, now))
            conn.commit()

    def clear_episodes(self):
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM episodes")
            conn.commit()

    def track_habit(self, action_type: str, target: str):
        now = datetime.datetime.now().isoformat()
        target_clean = target.strip().lower()
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT id, frequency FROM habits WHERE action_type = ? AND target = ?
            """, (action_type, target_clean))
            row = cur.fetchone()
            if row:
                cur.execute("UPDATE habits SET frequency = frequency + 1, last_used = ? WHERE id = ?", (now, row[0]))
            else:
                cur.execute("INSERT INTO habits (action_type, target, frequency, last_used) VALUES (?, ?, 1, ?)", 
                            (action_type, target_clean, now))
            conn.commit()

    def get_habits_context(self, limit: int = 5) -> str:
        """Топ привычек пользователя — что он делает чаще всего."""
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT action_type, target, frequency FROM habits "
                "ORDER BY frequency DESC, last_used DESC LIMIT ?",
                (limit,)
            )
            rows = cur.fetchall()
            if not rows:
                return ""
            return "\n".join(f"- {action_type} «{target}» (×{frequency})" for action_type, target, frequency in rows)

    def get_habit_frequency(self, action_type: str, target: str) -> int:
        """Сколько раз пользователь совершал действие с конкретной целью."""
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT frequency FROM habits WHERE action_type = ? AND target = ?",
                (action_type, target.strip().lower())
            )
            row = cur.fetchone()
            return row[0] if row else 0

    def add_observation(self, app: str, title: str = "", is_game: bool = False):
        now = datetime.datetime.now()
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO observations (app, title, is_game, hour, weekday, timestamp) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    (app or "").strip().lower(),
                    (title or "")[:180],
                    1 if is_game else 0,
                    now.hour,
                    now.weekday(),
                    now.isoformat(),
                ),
            )
            cur.execute(
                "DELETE FROM observations WHERE id NOT IN ("
                "SELECT id FROM observations ORDER BY id DESC LIMIT 400)"
            )
            conn.commit()

    def set_alias(self, name: str, target: str):
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO aliases (name, target) VALUES (?, ?) "
                "ON CONFLICT(name) DO UPDATE SET target = excluded.target",
                (name.strip().lower(), target.strip().lower()),
            )
            conn.commit()

    def get_alias(self, name: str) -> str:
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute("SELECT target FROM aliases WHERE name = ?", (name.strip().lower(),))
            row = cur.fetchone()
            return row[0] if row else ""

    def get_profile_context(self) -> str:
        """Сжатый портрет пользователя из привычек и наблюдений."""
        lines = []
        with closing(self._conn()) as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT app, COUNT(*) as n FROM observations "
                "GROUP BY app ORDER BY n DESC LIMIT 6"
            )
            apps = cur.fetchall()
            if apps:
                lines.append("Часто сидит в: " + ", ".join(f"{a} (×{n})" for a, n in apps))
            cur.execute(
                "SELECT hour, COUNT(*) as n FROM observations GROUP BY hour ORDER BY n DESC LIMIT 3"
            )
            hours = cur.fetchall()
            if hours:
                lines.append("Активные часы: " + ", ".join(f"{h}:00" for h, _ in hours))
            cur.execute("SELECT COUNT(*) FROM observations WHERE is_game = 1")
            games = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM observations")
            total = cur.fetchone()[0]
            if total:
                if games / max(total, 1) > 0.35:
                    lines.append("Склонность: играет чаще, чем работает. Подход — короткий, игровой, без лекций.")
                elif games / max(total, 1) < 0.1:
                    lines.append("Склонность: почти не в играх. Подход — спокойнее, меньше подколок про геймплей.")
            cur.execute(
                "SELECT app, COUNT(*) as n FROM observations WHERE is_game = 1 "
                "GROUP BY app ORDER BY n DESC LIMIT 3"
            )
            fav = cur.fetchall()
            if fav:
                lines.append("Игры: " + ", ".join(a for a, _ in fav))
        return "\n".join(lines)