"""
Исполнитель системных действий и навигации (по образцу Capri actions.py).
Поддержка цепочек выполнения (split_chain), нормализация игр и сайтов.
"""
import re
import webbrowser
import urllib.parse
from modules import tools

COMMON_SITES = {
    "гитхаб": "https://github.com",
    "github": "https://github.com",
    "вк": "https://vk.com",
    "вконтакте": "https://vk.com",
    "твич": "https://twitch.tv",
    "twitch": "https://twitch.tv",
    "гугл": "https://google.com",
    "google": "https://google.com",
    "яндекс": "https://ya.ru",
    "дискорд веб": "https://discord.com/app",
    "рутрекер": "https://rutracker.org",
    "аниме": "https://shikimori.one"
}

def split_chain(query: str) -> list:
    """Разбивает составные команды вроде 'открой ютуб и запусти стим'."""
    parts = re.split(r"\s+(?:и|затем|потом)\s+|,\s*", query.strip())
    return [p.strip() for p in parts if len(p.strip()) > 1]

def normalize_app_name(raw_name: str) -> str:
    """Схлопывает синонимы игр и лаунчеров в конкретные цели."""
    name = re.sub(r"[\s.,!?;:]+$", "", raw_name.lower().strip())
    if any(w in name for w in ["майн", "майнкрафт", "призм", "prism"]):
        return "prismlauncher"
    if any(w in name for w in ["тундр", "вар тандер", "war thunder"]):
        return "aces"
    if any(w in name for w in ["стим", "steam"]):
        return "steam"
    if any(w in name for w in ["дискорд", "discord"]):
        return "discord"
    return tools.normalize_app_query(name)

def handle_run_chain(payload: str) -> str:
    """Запуск приложений с поддержкой нескольких целей в одной фразе."""
    raw_targets = split_chain(payload)
    unique_apps = []
    seen = set()

    for item in raw_targets:
        norm = normalize_app_name(item)
        if norm not in seen:
            seen.add(norm)
            unique_apps.append((norm, item))

    launched = []
    failed = []

    for norm, original in unique_apps:
        if tools.run_app(norm):
            launched.append(original)
        else:
            failed.append(original)

    if launched and not failed:
        return f"Запустил: {', '.join(launched)}."
    elif launched and failed:
        return f"Запустил {', '.join(launched)}, но не нашел: {', '.join(failed)}."
    return f"Не нашел «{payload}» на дисках."

def handle_youtube_search(cmd_l: str) -> str:
    """Вычленение чистого запроса для видеохостинга."""
    q = re.sub(
        r"\b(открой|запусти|включи|вруби|поставь|найди|поищи|покажи|"
        r"на ютубе|в ютубе|на youtube|в youtube|ютуб\w*|youtube\w*|"
        r"видос\w*|видео\w*|ролик\w*|клип\w*|песн\w*|трек\w*|"
        r"стрим\w*|музык\w*|плейлист\w*|"
        r"мне|нам|какое-нибудь|какой-нибудь|какую-нибудь|какие-нибудь|"
        r"что-нибудь|что-то|какой-то|какую-то|"
        r"пожалуйста|плиз|пж|давай|ну|вот|это|сейчас|быстро|побыстрее|"
        r"и там|там|на тему|про|по|с|для|и|а|в|на)\b",
        " ", cmd_l
    )
    clean_q = re.sub(r"\s+", " ", q).strip()
    if not clean_q or len(clean_q) < 2:
        webbrowser.open("https://www.youtube.com")
        return "Открыл YouTube."
    
    encoded = urllib.parse.quote(clean_q)
    webbrowser.open(f"https://www.youtube.com/results?search_query={encoded}")
    return f"Ищу на YouTube: {clean_q}."

def handle_web_navigation(payload: str) -> str:
    """Переход на сайты и порталы."""
    target_url = COMMON_SITES.get(payload, None)
    if not target_url:
        target_url = payload if payload.startswith("http") else f"https://{payload}"
    webbrowser.open(target_url)
    return f"Открыл в эфире: {payload}."