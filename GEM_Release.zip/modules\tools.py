"""
Системные инструменты Windows для Гема.
Универсальный сканер приложений, Steam-библиотек, меню Пуск и поддержка нативных протоколов.
"""
import os
import re
import time
import json
import ctypes
import difflib
import threading
import subprocess
from ctypes import wintypes
import psutil
from PIL import ImageGrab
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

u = ctypes.windll.user32
k = ctypes.windll.kernel32
shell32 = ctypes.windll.shell32

ULONG_PTR = ctypes.c_size_t

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR)
    ]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR)
    ]

class _INPUTUNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004

# --- Мышь ---
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_ABSOLUTE = 0x8000

MOUSE_BUTTONS = {
    "left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
    "right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
    "middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
}

# --- Клавиши (виртуальные коды Windows) ---
VK = {
    "ctrl": 0x11, "control": 0x11,
    "alt": 0x12,
    "shift": 0x10,
    "win": 0x5B,
    "enter": 0x0D, "return": 0x0D,
    "esc": 0x1B, "escape": 0x1B,
    "tab": 0x09,
    "space": 0x20,
    "backspace": 0x08,
    "delete": 0x2E, "del": 0x2E,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "home": 0x24, "end": 0x23,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74,
    "f6": 0x75, "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79,
    "f11": 0x7A, "f12": 0x7B,
}

RU_EN_MAP = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
    'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
    'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
    'ф': 'f', 'х': 'h', 'ц': 'c', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '',
    'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya'
}

# Словарь распознавания сленга, аббревиатур и народных названий
COMMON_GAME_ALIASES = {
    "кс": "counter-strike",
    "кс2": "counter-strike",
    "cs": "counter-strike",
    "cs2": "counter-strike",
    "кска": "counter-strike",
    "контра": "counter-strike",
    "роблокс": "roblox",
    "дота": "dota",
    "дотка": "dota",
    "тундра": "war thunder",
    "вар тандер": "war thunder",
    "вартандер": "war thunder",
    "майн": "prism",
    "майнкрафт": "prism",
    "minecraft": "prism",
    "призма": "prismlauncher",
    "телега": "telegram",
    "телег": "telegram",
    "стим": "steam",
    "дискорд": "discord",
    "дс": "discord",
    "блокнот": "notepad",
    "калькулятор": "calc"
}

APP_NAME_ALIASES = {
    "эдж": "microsoft edge",
    "эдс": "microsoft edge",
    "edge": "microsoft edge",
    "microsoft edge": "microsoft edge",
    "микрософт эдж": "microsoft edge",
    "микрософт эдс": "microsoft edge",
    "майкрософт эдж": "microsoft edge",
    "майкрософт эдс": "microsoft edge",
    "майкрасофт эдж": "microsoft edge",
    "майкрасофт эдс": "microsoft edge",
    "хром": "chrome",
    "гугл хром": "chrome",
    "google chrome": "chrome",
    "файрфокс": "firefox",
}


def normalize_app_query(query: str) -> str:
    """Normalize common spoken app names and transcription variants."""
    normalized = re.sub(r"[\s.,!?;:]+$", "", (query or "").lower().strip())
    padded = f" {normalized} "
    for alias, canonical in sorted(APP_NAME_ALIASES.items(), key=lambda item: -len(item[0])):
        if f" {alias} " in padded:
            return canonical
    return normalized


def to_en(text: str) -> str:
    return "".join(RU_EN_MAP.get(c, c) for c in text.lower())

def window_title(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(512)
    u.GetWindowTextW(hwnd, buf, 512)
    return buf.value

def foreground_window_rect():
    """(left, top, right, bottom) активного окна в экранных координатах, либо None."""
    try:
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return None
        rect = wintypes.RECT()
        u.GetWindowRect(hwnd, ctypes.byref(rect))
        return (rect.left, rect.top, rect.right, rect.bottom)
    except Exception:
        return None

def foreground_process() -> str:
    hwnd = u.GetForegroundWindow()
    if not hwnd:
        return ""
    pid = wintypes.DWORD()
    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        return psutil.Process(pid.value).name().lower()
    except Exception:
        return ""

def focus_window(hwnd: int) -> bool:
    if not hwnd:
        return False
    for attempt in range(3):
        if u.IsIconic(hwnd):
            u.ShowWindow(hwnd, 9)
        fg = u.GetForegroundWindow()
        me = k.GetCurrentThreadId()
        fg_tid = u.GetWindowThreadProcessId(fg, None)
        attached = bool(fg_tid and fg_tid != me and u.AttachThreadInput(me, fg_tid, True))
        
        u.keybd_event(0x12, 0, 0, 0)
        u.keybd_event(0x12, 0, 2, 0)
        u.BringWindowToTop(hwnd)
        u.SetForegroundWindow(hwnd)
        if attached:
            u.AttachThreadInput(me, fg_tid, False)
        time.sleep(0.2)
        if u.GetForegroundWindow() == hwnd:
            return True
        if attempt == 0:
            u.SwitchToThisWindow(hwnd, True)
            time.sleep(0.2)
            if u.GetForegroundWindow() == hwnd:
                return True
    return False

def paste_text(text: str):
    time.sleep(0.1)
    for ch in text:
        if ch == "\n":
            ch = "\r"
        for unit in ch.encode("utf-16-le").decode("utf-16-le"):
            code = ord(unit)
            down = INPUT(type=1, u=_INPUTUNION(ki=KEYBDINPUT(0, code, KEYEVENTF_UNICODE, 0, 0)))
            up = INPUT(type=1, u=_INPUTUNION(ki=KEYBDINPUT(0, code, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, 0, 0)))
            arr = (INPUT * 2)(down, up)
            u.SendInput(2, arr, ctypes.sizeof(INPUT))
        time.sleep(0.015)

# ===== Мышь =====
def _screen_size():
    return u.GetSystemMetrics(0), u.GetSystemMetrics(1)

def _send_mouse(flags, data=0, x=0, y=0, absolute=False):
    if absolute:
        flags |= MOUSEEVENTF_ABSOLUTE
        sw, sh = _screen_size()
        x = int(x * 65535 // max(sw, 1))
        y = int(y * 65535 // max(sh, 1))
    inp = INPUT(type=0, u=_INPUTUNION(mi=MOUSEINPUT(int(x), int(y), data, flags, 0, 0)))
    u.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

def mouse_move(x, y):
    """Переместить курсор в абсолютные координаты экрана (пиксели)."""
    _send_mouse(MOUSEEVENTF_MOVE, x=x, y=y, absolute=True)

def mouse_click(x=None, y=None, button="left"):
    """Клик. Если x/y заданы — сначала переводит курсор туда."""
    if x is not None and y is not None:
        mouse_move(x, y)
        time.sleep(0.05)
    down, up = MOUSE_BUTTONS.get(button, MOUSE_BUTTONS["left"])
    _send_mouse(down)
    _send_mouse(up)

def mouse_double_click(x=None, y=None):
    mouse_click(x, y)
    time.sleep(0.05)
    mouse_click()

def mouse_scroll(clicks, x=None, y=None):
    """Прокрутка: clicks > 0 — вверх, clicks < 0 — вниз."""
    if x is not None and y is not None:
        mouse_move(x, y)
        time.sleep(0.05)
    _send_mouse(MOUSEEVENTF_WHEEL, data=int(clicks) * 120)

# ===== Окна =====
def list_windows():
    """Возвращает список (hwnd, title) видимых окон."""
    wins = []
    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, lparam):
        if u.IsWindowVisible(hwnd):
            title = window_title(hwnd)
            if title:
                wins.append((hwnd, title))
        return True
    u.EnumWindows(_cb, 0)
    return wins

def foreground_window_title() -> str:
    return window_title(u.GetForegroundWindow())

def minimize_window(hwnd=None):
    u.ShowWindow(hwnd or u.GetForegroundWindow(), 6)  # SW_MINIMIZE

def maximize_window(hwnd=None):
    u.ShowWindow(hwnd or u.GetForegroundWindow(), 3)  # SW_MAXIMIZE

# ===== Клавиатура =====
def _resolve_vk(key: str):
    kl = key.lower()
    if kl in VK:
        return VK[kl]
    if len(key) == 1:
        return ord(key.upper())
    return None

def press_key(name):
    """Нажать и отпустить клавишу по имени (например, 'enter', 'f5', 'w')."""
    vk = _resolve_vk(name)
    if not vk:
        return False
    u.keybd_event(vk, 0, 0, 0)
    u.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
    return True

def hotkey(*keys):
    """Сочетание клавиш, например hotkey('ctrl', 'c')."""
    vks = [_resolve_vk(k) for k in keys]
    if any(v is None for v in vks):
        return False
    for vk in vks:
        u.keybd_event(vk, 0, 0, 0)
    for vk in reversed(vks):
        u.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
    return True

def scan_steam_library() -> dict:
    """Ищет установленные Steam игры на всех дисках и возвращает словарь {название: steam://run/ID}."""
    steam_games = {}
    import winreg
    steam_path = None

    for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        try:
            with winreg.OpenKey(root, r"Software\Valve\Steam") as key:
                val, _ = winreg.QueryValueEx(key, "SteamPath")
                if val and os.path.exists(val):
                    steam_path = val
                    break
        except Exception:
            continue

    if not steam_path:
        default_paths = [r"C:\Program Files (x86)\Steam", r"C:\Steam", r"D:\Steam", r"E:\Steam"]
        for dp in default_paths:
            if os.path.exists(dp):
                steam_path = dp
                break

    if not steam_path:
        return steam_games

    library_folders = [steam_path]
    vdf = os.path.join(steam_path, "steamapps", "libraryfolders.vdf")
    if os.path.exists(vdf):
        try:
            with open(vdf, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    m = re.search(r'"path"\s+"([^"]+)"', line)
                    if m:
                        p = m.group(1).replace(r"\\", "\\")
                        if os.path.exists(p) and p not in library_folders:
                            library_folders.append(p)
        except Exception:
            pass

    for folder in library_folders:
        steamapps = os.path.join(folder, "steamapps")
        if not os.path.exists(steamapps):
            continue
        try:
            for item in os.listdir(steamapps):
                if item.startswith("appmanifest_") and item.endswith(".acf"):
                    appid_m = re.search(r"appmanifest_(\d+)\.acf", item)
                    if not appid_m:
                        continue
                    appid = appid_m.group(1)
                    full_p = os.path.join(steamapps, item)
                    with open(full_p, "r", encoding="utf-8", errors="ignore") as f:
                        data = f.read()
                        name_m = re.search(r'"name"\s+"([^"]+)"', data)
                        if name_m:
                            g_name = name_m.group(1).strip().lower()
                            steam_games[g_name] = f"steam://run/{appid}"
        except Exception:
            continue

    return steam_games

_system_apps_cache = None
LAST_LAUNCH = {"query": "", "matched": "", "ok": False}

_SKIP_EXE_BITS = (
    "uninstall", "unins000", "setup", "installer", "update", "crash",
    "vcredist", "redist", "helper", "crashpad",
)

GAME_PROCESSES = {
    "cs2", "csgo", "dota2", "hl2", "robloxplayerbeta", "robloxplayer",
    "aces", "aces.exe", "javaw", "minecraft", "valorant-win64-shipping",
    "fortniteclient-win64-shipping", "gta5", "eldenring", "witcher3",
    "r5apex", "overwatch", "league of legends", "riotclientservices",
    "rocketleague", "destiny2", "wow", "wowclassic", "starrail",
    "genshinimpact", "deadbydaylight", "sekiro", "darksoulsiii",
    "thefinals",
}

_GAME_TITLE_HINTS = (
    "unity", "unreal", "direct3d", "steam", "game", "игра",
)


def _apps_cache_path():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, "data", "apps_index.json")


def _scan_program_files(db: dict):
    """Добирает .exe из Program Files без ручного списка приложений."""
    roots = [
        os.environ.get("ProgramFiles"),
        os.environ.get("ProgramFiles(x86)"),
    ]
    skip_dir = ("windowsapps", "winsxs", "system32", "syswow64", "installer", "temp", "cache", "node_modules")
    for root in filter(None, roots):
        if not os.path.isdir(root):
            continue
        try:
            for dirpath, dirnames, files in os.walk(root):
                low = dirpath.lower()
                if any(s in low for s in skip_dir):
                    dirnames[:] = []
                    continue
                depth = low[len(root.lower()):].count(os.sep)
                if depth > 3:
                    dirnames[:] = []
                    continue
                for fname in files:
                    if not fname.lower().endswith(".exe"):
                        continue
                    base = os.path.splitext(fname)[0].lower()
                    if any(bit in base for bit in _SKIP_EXE_BITS):
                        continue
                    if base not in db:
                        db[base] = os.path.join(dirpath, fname)
        except Exception:
            continue


def _scan_windows_start_apps(db: dict):
    """Index registered Start menu apps, including packaged Windows apps."""
    if os.name != "nt":
        return
    command = (
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
        "$ErrorActionPreference = 'Stop'; "
        "Get-StartApps | Select-Object Name, AppID | ConvertTo-Json -Compress"
    )
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        print(f"[GEM] Не удалось получить список приложений Windows: {exc.__class__.__name__}.")
        return
    if result.returncode:
        print(
            "[GEM] Windows не вернула список приложений Пуска "
            f"(код {result.returncode})."
        )
        return

    try:
        entries = json.loads(result.stdout) if result.stdout.strip() else []
    except json.JSONDecodeError:
        print("[GEM] Windows вернула некорректный список приложений Пуска.")
        return
    if isinstance(entries, dict):
        entries = [entries]
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("Name") or "").strip().lower()
        app_id = str(entry.get("AppID") or "").strip()
        if name and app_id:
            db[name] = f"shell:AppsFolder\\{app_id}"


def scan_all_system_apps() -> dict:
    """Глубокий сбор ярлыков, Steam, меню Пуск и Program Files. Без ручного реестра Гема."""
    db = {}
    steam_items = scan_steam_library()
    db.update(steam_items)

    user_home = os.path.expanduser("~")
    search_dirs = [
        os.path.join(user_home, "Desktop"),
        os.path.join(user_home, "OneDrive", "Desktop"),
        os.path.join(os.environ.get("PUBLIC", r"C:\Users\Public"), "Desktop"),
        os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs"),
        os.path.join(os.environ.get("PROGRAMDATA", ""), r"Microsoft\Windows\Start Menu\Programs"),
        os.path.join(user_home, "AppData", "Local", "Programs"),
        os.path.join(user_home, "AppData", "Local", "Roblox"),
    ]

    for d in filter(os.path.exists, search_dirs):
        try:
            for root, _, files in os.walk(d):
                for f in files:
                    ext = os.path.splitext(f)[1].lower()
                    if ext in (".lnk", ".url", ".exe"):
                        base = os.path.splitext(f)[0].lower()
                        full_f = os.path.join(root, f)
                        if ext == ".url":
                            try:
                                with open(full_f, "r", encoding="utf-8", errors="ignore") as uf:
                                    for line in uf:
                                        if line.lower().startswith("url="):
                                            url_val = line.split("=", 1)[1].strip()
                                            db[base] = url_val
                                            break
                            except Exception:
                                db[base] = full_f
                        else:
                            db[base] = full_f
        except Exception:
            continue

    _scan_program_files(db)
    _scan_windows_start_apps(db)
    return db


def _load_apps_disk_cache() -> dict:
    path = _apps_cache_path()
    try:
        if not os.path.exists(path):
            return {}
        if time.time() - os.path.getmtime(path) > 86400:
            return {}
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_apps_disk_cache(db: dict):
    try:
        path = _apps_cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False)
    except Exception:
        pass


def get_system_apps() -> dict:
    """Ленивый кэш: диск → память → полный скан."""
    global _system_apps_cache
    if _system_apps_cache is None:
        disk = _load_apps_disk_cache()
        if disk:
            _system_apps_cache = disk
        else:
            _system_apps_cache = scan_all_system_apps()
            _save_apps_disk_cache(_system_apps_cache)
    return _system_apps_cache


def refresh_apps():
    """Принудительно пересканировать приложения (например, поставил новую игру)."""
    global _system_apps_cache
    _system_apps_cache = None
    try:
        os.remove(_apps_cache_path())
    except Exception:
        pass
    db = get_system_apps()
    return db


def reindex_apps_background():
    """Полный перескан в фоне — не блокирует старт маскота."""
    def _job():
        global _system_apps_cache
        db = scan_all_system_apps()
        _system_apps_cache = db
        _save_apps_disk_cache(db)
        print(f"[GEM] Индекс приложений: {len(db)} записей.")
    threading.Thread(target=_job, daemon=True).start()


def _find_app_match(query: str, apps: dict):
    terms = tuple(dict.fromkeys(
        term.strip().lower()
        for term in (query, to_en(query))
        if term and term.strip()
    ))
    entries = [
        (str(name).strip().lower(), target)
        for name, target in apps.items()
        if str(name).strip()
    ]

    for term in terms:
        exact = next(((name, target) for name, target in entries if name == term), None)
        if exact:
            return exact

    prefix_matches = [
        (name, target) for name, target in entries
        if any(name.startswith(term) for term in terms)
    ]
    if prefix_matches:
        return min(prefix_matches, key=lambda match: (len(match[0]), match[0]))

    substring_matches = [
        (name, target) for name, target in entries
        if any(term in name for term in terms)
    ]
    if substring_matches:
        return min(substring_matches, key=lambda match: (len(match[0]), match[0]))

    best = None
    best_score = 0.0
    for name, target in entries:
        score = max(
            (difflib.SequenceMatcher(None, term, name).ratio() for term in terms),
            default=0.0,
        )
        if score > best_score or (
            score == best_score and best is not None and name < best[0]
        ):
            best = (name, target)
            best_score = score

    return best if best_score >= 0.62 else None


_NOT_GAMES = {
    "explorer", "searchhost", "applicationframehost", "shellexperiencehost",
    "chrome", "msedge", "firefox", "opera", "brave", "discord", "telegram",
    "code", "cursor", "notepad", "winword", "excel", "spotify", "obs64",
}


def is_probably_game(proc: str = None, title: str = None) -> bool:
    p = (proc or "").lower().replace(".exe", "").strip()
    t = (title or "").lower()
    if p in _NOT_GAMES:
        return False
    if p in GAME_PROCESSES or any(p.startswith(g) for g in GAME_PROCESSES):
        return True
    if any(h in t for h in _GAME_TITLE_HINTS) and is_foreground_fullscreen():
        return True
    return is_foreground_fullscreen()


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def is_foreground_fullscreen() -> bool:
    hwnd = u.GetForegroundWindow()
    if not hwnd:
        return False
    rc = RECT()
    u.GetWindowRect(hwnd, ctypes.byref(rc))
    sw, sh = _screen_size()
    return rc.left <= 2 and rc.top <= 2 and rc.right >= sw - 2 and rc.bottom >= sh - 2


def click_norm(nx, ny, button="left"):
    """Клик по нормализованным координатам 0..1 (или пикселям, если > 1)."""
    sw, sh = _screen_size()
    try:
        nx = float(nx)
        ny = float(ny)
    except (TypeError, ValueError):
        return False
    if nx > 1.0 or ny > 1.0:
        x, y = int(nx), int(ny)
    else:
        x = int(max(0.0, min(1.0, nx)) * (sw - 1))
        y = int(max(0.0, min(1.0, ny)) * (sh - 1))
    mouse_click(x, y, button=button)
    return True

def run_app(query: str, alias: str = None) -> bool:
    """Интеллектуальный запуск: сленг -> точный путь -> протокол -> Fuzzy Matching."""
    global _system_apps_cache
    raw = normalize_app_query(query)
    LAST_LAUNCH.update({"query": raw, "matched": "", "ok": False})

    resolved_query = APP_NAME_ALIASES.get(
        raw,
        COMMON_GAME_ALIASES.get(raw, raw),
    )
    if alias:
        resolved_query = normalize_app_query(alias)
    resolved_query = APP_NAME_ALIASES.get(
        resolved_query,
        COMMON_GAME_ALIASES.get(resolved_query, resolved_query),
    )

    if resolved_query in ("notepad", "calc", "cmd", "explorer"):
        try:
            os.system(f"start {resolved_query}")
            LAST_LAUNCH.update({"matched": resolved_query, "ok": True})
            return True
        except Exception:
            pass

    apps = get_system_apps()
    match = _find_app_match(resolved_query, apps)
    if not match:
        start_apps = {}
        _scan_windows_start_apps(start_apps)
        if start_apps:
            apps = {**apps, **start_apps}
            _system_apps_cache = apps
            _save_apps_disk_cache(apps)
            match = _find_app_match(resolved_query, apps)

    if match:
        best_name, best_target = match
        try:
            res = shell32.ShellExecuteW(None, "open", str(best_target), None, None, 1)
            if res > 32:
                LAST_LAUNCH.update({"matched": best_name, "ok": True})
                return True
        except Exception:
            pass

        try:
            os.startfile(best_target)
            LAST_LAUNCH.update({"matched": best_name, "ok": True})
            return True
        except Exception:
            pass

    return False

def kill_target(target_name: str) -> bool:
    """Закрытие процесса с учетом сленговых названий."""
    target_clean = target_name.lower().strip()
    target_resolved = COMMON_GAME_ALIASES.get(target_clean, target_clean)
    target_en = to_en(target_resolved)

    browser_names = {"chrome", "msedge", "browser", "firefox", "opera", "brave"}
    is_browser_req = "браузер" in target_clean or "browser" in target_clean

    killed = False
    for proc in psutil.process_iter(['name', 'pid']):
        try:
            p_name = proc.info['name'].lower()
            p_base = os.path.splitext(p_name)[0]

            if is_browser_req and p_base in browser_names:
                proc.kill()
                killed = True
                continue

            if target_resolved in p_base or target_en in p_base:
                proc.kill()
                killed = True
                continue

            if difflib.SequenceMatcher(None, target_en, p_base).ratio() > 0.65:
                proc.kill()
                killed = True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if not killed:
        t_exe = target_resolved if target_resolved.endswith(".exe") else f"{target_resolved}.exe"
        res = subprocess.run(["taskkill", "/F", "/T", "/IM", t_exe], capture_output=True, text=True)
        if res.returncode == 0:
            killed = True

    return killed

def set_system_volume(percent: int) -> str:
    try:
        val = max(0, min(100, int(percent)))
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        vol = interface.QueryInterface(IAudioEndpointVolume)
        vol.SetMasterVolumeLevelScalar(val / 100.0, None)
        return f"Громкость: {val}%."
    except Exception as e:
        return f"Сбой звука: {e}"

def take_screenshot() -> str:
    try:
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        out_dir = os.path.join(root_dir, "data", "screenshots")
        os.makedirs(out_dir, exist_ok=True)
        import datetime
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(out_dir, f"screen_{ts}.png")
        ImageGrab.grab().save(path)
        return f"Слепок сохранен: {path}"
    except Exception as e:
        return f"Ошибка снимка: {e}"

def grab_screenshot_image():
    """Снимок экрана как PIL.Image — для передачи в мозг (зрение), без сохранения на диск."""
    try:
        return ImageGrab.grab()
    except Exception as e:
        print(f"[ЗРЕНИЕ] Не удалось снять экран: {e}")
        return None