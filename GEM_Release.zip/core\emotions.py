EMOTION_MARKERS = {
    "angry": (
        "бесишь", "отвали", "игнорирую", "презираю", "злюсь", "раздраж",
        "иди нах", "пошел нах", "не буду с тобой",
    ),
    "sad": (
        "жаль", "груст", "сожале", "не получилось", "не удалось", "ошибка",
        "помехи", "не нашел", "не нашёл",
    ),
    "happy": (
        "ура", "рад", "класс", "здорово", "отлично", "спасибо", "красава",
        "молодец", "без проблем", "сделано",
    ),
    "surprised": (
        "ого", "ничего себе", "серьезно", "серьёзно", "неужели", "вот это",
    ),
}

INSULT_MARKERS = (
    "пошел нахуй", "пошёл нахуй", "иди нахуй", "соси", "уебок", "мразь",
    "гандон", "заткнись", "дебил", "тупой", "урод", "еблан", "сука",
    "рот закрой", "криворукий",
)

FAILURE_MARKERS = (
    "не получилось", "не удалось", "ошибка", "помехи", "не нашел",
    "не нашёл", "не запустил", "не открыл", "не закрыл", "не работает",
    "сбой", "не вышло",
)

SUCCESS_MARKERS = (
    "запустил", "открыл", "написал", "напечатал", "сделано", "готово",
    "кликнул", "нажал", "свернул", "развернул", "прокрутил",
)


def detect_emotion(user_text: str = "", reply: str = "", attitude_score: int = 50) -> str:
    user_text = (user_text or "").lower()
    reply = (reply or "").lower()
    text = f"{user_text} {reply}"
    if any(marker in user_text for marker in INSULT_MARKERS):
        return "angry"
    for emotion in ("angry", "sad", "happy", "surprised"):
        if any(marker in text for marker in EMOTION_MARKERS[emotion]):
            return emotion
    if any(marker in reply for marker in FAILURE_MARKERS):
        return "sad"
    if any(marker in reply for marker in SUCCESS_MARKERS):
        return "happy"
    if attitude_score < 25:
        return "angry"
    if attitude_score > 75:
        return "happy"
    return "neutral"
