import os
import sys
import re
import time
import socket
import threading

# Гарантируем, что корень проекта всегда в путях поиска модулей
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from config import load_config
from core.memory import MultiLevelMemory
from core.agent import GemAgent
from core.observer import ProactiveObserver
from modules.tools import reindex_apps_background
from modules.scheduler import ReminderScheduler
from ui.mascot import DreamMascot

WAKE_RE = re.compile(r"\b(гем|гам|гэм|гей|джем|гемчик|game|gam)[ауеыи]?\b", re.IGNORECASE)

def start_hotkey_microphone(agent, mascot, config=None):
    try:
        import speech_recognition as sr
        import keyboard
    except ImportError:
        print("[MIC INFO] Для микрофона установи: pip install pyaudio keyboard")
        return

    mic_index = None
    if config is not None:
        raw_idx = config.get("mic_index")
        if raw_idx is not None:
            try:
                parsed = int(raw_idx)
                if parsed > 0:
                    mic_index = parsed
            except (ValueError, TypeError):
                mic_index = None

    hotkey = "f8"
    if config is not None:
        hotkey = str(config.get("mic_hotkey", "f8")).lower()

    _recording = [False]

    def _record_and_process():
        if _recording[0]:
            return
        _recording[0] = True
        mascot.say("слушаю...")
        r = sr.Recognizer()
        # Используем точь-в-точь те же настройки, что и в кнопке "Тест", 
        # так как они доказали свою работоспособность.
        try:
            with sr.Microphone(device_index=mic_index) as source:
                r.adjust_for_ambient_noise(source, duration=0.5)
                print(f"[MIC] Запись (4 сек)... Говори!")
                # Записываем ровно 4 секунды, без таймаутов на тишину
                audio = r.record(source, duration=4)

            print("[MIC] Запись окончена, распознаю...")
            text = r.recognize_google(audio, language="ru-RU").strip()
            print(f"[MIC] Услышал: {text}")

            if not text:
                _recording[0] = False
                return

            # Так как нажали хоткей, отправляем текст как команду напрямую
            threading.Thread(target=mascot.process_command_async, args=(text,), daemon=True).start()

        except sr.UnknownValueError:
            print("[MIC] Не удалось распознать речь (тихо/невнятно)")
            mascot.say("не разобрал.")
        except Exception as e:
            print(f"[MIC] Ошибка: {e.__class__.__name__}: {e}")
            mascot.say("эфир помехи.")
        finally:
            _recording[0] = False

    def _on_hotkey():
        threading.Thread(target=_record_and_process, daemon=True).start()

    try:
        keyboard.add_hotkey(hotkey, _on_hotkey)
        print(f"[MIC SUCCESS] Хоткей микрофона: {hotkey.upper()}. Нажми, чтобы говорить.")
    except Exception as e:
        print(f"[MIC INFO] Ошибка хоткея: {e}")

def main():
    # Защита от второго запуска (один экземпляр на порт 65432)
    try:
        lock_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        lock_socket.bind(("127.0.0.1", 65432))
    except socket.error:
        print("\n[!] Гем уже запущен в другом окне!\n")
        sys.exit(0)

    print("--- [GEM REBORN: MODULAR DREAM ARCHITECTURE] ---")
    config = load_config()
    
    os.makedirs(os.path.join(ROOT_DIR, "data"), exist_ok=True)
    db_path = os.path.join(ROOT_DIR, "data", "memory.db")
    memory = MultiLevelMemory(db_path=db_path)
    
    agent = GemAgent(config, memory)
    mascot = DreamMascot(agent, config)
    agent.mascot = mascot

    reindex_apps_background()
    start_hotkey_microphone(agent, mascot, config)

    # Проактивность: Гем сам наблюдает за окнами и комментирует без команды
    observer = ProactiveObserver(agent, mascot, config)
    observer.start()
    mascot.observer = observer

    scheduler = ReminderScheduler()
    agent.scheduler = scheduler

    def _on_reminder(text):
        if getattr(mascot, "is_hiding", False) or getattr(mascot, "_exploring", False):
            scheduler.add(time.time() + 60, text)
            return
        mascot.say(f"напоминаю: {text}", priority=True)

    scheduler.start(on_fire=_on_reminder)

    mascot.run()

if __name__ == "__main__":
    main()