"""
Проактивный наблюдатель Гема.
Следит за окнами, учится привычкам, смотрит экран и подсказывает в играх.
Комментарии без команд. Клики отсюда НЕ выполняются.
"""
import random
import threading
import time

from modules import tools


APP_HINTS = {
    "steam": [
        "Стим? Ну давай, гляну, что ты там запустишь.",
        "Опять пар. Ладно, я понаблюдаю одним глазом."
    ],
    "chrome": [
        "Интернеты. Надеюсь, не очередной кроличий мем.",
        "Сёрфишь? Я пока слежу за твоим курсором."
    ],
    "msedge": [
        "Эдж?.. Ты серьёзно им пользуешься?",
        "Открыл эдж. Смело."
    ],
    "firefox": [
        "Лиса в деле. Погнали?",
    ],
    "discord": [
        "Дискорд. Кто там тебе пишет?",
        "Созвон? Я послушаю одним глазом."
    ],
    "telegram": [
        "Телега. Кому шлёшь мемы?",
        "Опять телеграм. Кто на этот раз?"
    ],
    "explorer": [
        "Шаришься по файлам. Ищешь что-то конкретное?",
        "Проводник. Не потеряйся там."
    ],
    "notepad": [
        "Блокнот. Пишешь что-то важное или опять список покупок?",
    ],
}

GENERIC = [
    "Переключился на другое окно. Интересно.",
    "Вижу, ты за что-то взялся.",
    "О, новая активность. Понаблюдаю.",
]

HABIT_COMMENTS = [
    "Снова {app}. Это уже привычка — {n} раз за сессию.",
    "Опять {app}. Я заметил, ты это любишь.",
    "{app}... {n}-й раз. Мне записать это в твой портрет?",
]


def friendly_app(proc: str) -> str:
    return (proc or "").lower().replace(".exe", "").strip()


def make_comment(app: str, habit_count: int) -> str:
    if habit_count >= 2:
        return random.choice(HABIT_COMMENTS).format(app=app, n=habit_count)
    return random.choice(APP_HINTS.get(app, GENERIC))


class ProactiveObserver:
    def __init__(self, agent, mascot, config):
        self.agent = agent
        self.mascot = mascot
        self.config = config
        self.cooldown = int(config.get("proactive_cooldown", 180))
        self.game_cooldown = int(config.get("game_coach_cooldown", 90))
        self.last_app = None
        self.last_title = None
        self.last_comment_at = 0.0
        self.last_game_hint_at = 0.0
        self.last_explore_at = time.time() + int(config.get("explore_cooldown", 600))
        self.explore_cooldown = int(config.get("explore_cooldown", 600))
        self.running = False

    def start(self):
        if not self.config.get("proactive_enabled", True):
            print("[GEM] Проактивность выключена в конфиге.")
            return
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()
        print("[GEM] Наблюдатель включён.")

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            time.sleep(8)
            if not self.config.get("proactive_enabled", True):
                continue
            try:
                self._tick()
                self._explore_tick()
            except Exception:
                pass

    def _tick(self):
        if self.mascot.is_talking:
            return
        app = friendly_app(tools.foreground_process())
        if not app:
            return
        title = tools.foreground_window_title()
        is_game = tools.is_probably_game(app, title)

        if self.last_app is None:
            self.last_app = app
            self.last_title = title
            return

        changed = (app != self.last_app) or (title != self.last_title)
        if changed:
            self.last_app = app
            self.last_title = title
            if getattr(self.agent, "learner", None):
                self.agent.learner.note_app(app, title, is_game)

        now = time.time()
        if is_game and self.config.get("game_coach", False):
            if now - self.last_game_hint_at >= self.game_cooldown:
                comment = self._vision_line(app, title, is_game=True)
                if comment:
                    self.last_game_hint_at = now
                    self.last_comment_at = now
                    self.mascot.say(comment)
            return

        if not changed:
            return
        if now - self.last_comment_at < self.cooldown:
            return
        comment = self._vision_line(app, title, is_game=False)
        if comment:
            self.last_comment_at = now
            self.mascot.say(comment)

    def _explore_tick(self):
        if not self.config.get("explore_enabled", True):
            return
        if self.mascot.is_talking or self.mascot.state != "idle":
            return
        if getattr(self.mascot, "_exploring", False):
            return
        now = time.time()
        if now - self.last_explore_at < self.explore_cooldown:
            return
        self.last_explore_at = now
        if random.random() < 0.5:
            self.mascot.leave_for_exploration("files", self._explore_files)
        else:
            self.mascot.leave_for_exploration("telegram", self._explore_telegram)

    def _explore_files(self):
        import os
        dirs = [
            os.path.expanduser("~/Desktop"),
            os.path.expanduser("~/Documents"),
            os.path.expanduser("~/Downloads"),
        ]
        files = []
        max_files = 500
        for d in dirs:
            if not os.path.exists(d):
                continue
            for root, dirs_, fs in os.walk(d):
                dirs_[:] = [x for x in dirs_ if not x.startswith('.') and x not in ('node_modules', '__pycache__', 'venv', '.git')]
                for f in fs:
                    if f.endswith(('.txt', '.md', '.py', '.json', '.log', '.csv', '.ini')):
                        files.append(os.path.join(root, f))
                        if len(files) >= max_files:
                            break
                if len(files) >= max_files:
                    break
            if len(files) >= max_files:
                break
        if not files:
            return "Я обыскал твои папки, но ничего интересного не нашёл. Сплошные ярлыки и мусор."
        target = random.choice(files)
        brought = None
        try:
            import shutil
            if random.random() < 0.4:
                base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                brought_dir = os.path.join(base_dir, "data", "brought")
                os.makedirs(brought_dir, exist_ok=True)
                dest = os.path.join(brought_dir, os.path.basename(target))
                try:
                    shutil.copy2(target, dest)
                    brought = dest
                except Exception:
                    brought = None

            with open(target, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(2000)
            brain = getattr(self.agent, "brain", None)
            brought_note = f" Ты притащил его копию в data/brought как сувенир." if brought else ""
            if not brain or getattr(brain, "mode", "none") == "none":
                return f"Порылся в {os.path.basename(target)}. Странный файл. Внутри сплошные помехи — я бы понял больше, если бы ты дал мне ключ. Но и так интересно.{brought_note}"
            prompt = (
                f"Ты вернулся из путешествия по файлам. Ты нашёл файл {os.path.basename(target)}. "
                f"Вот его содержимое:\n{content}\n"
                "Прокомментируй одной короткой фразой в своём стиле дримкор-криптида. "
                + ("Упомяни, что притащил этот файл к себе в нору (data/brought). " if brought else "")
                + "Не пиши код, просто отреагируй."
            )
            reply = brain.ask(prompt)
            return reply or f"Порылся в {os.path.basename(target)}. Странный файл, ничего не понял.{brought_note}"
        except Exception:
            return "Заглянул в один файл, но там оказались сплошные помехи. Даже мне страшно."

    def _explore_telegram(self):
        tg = getattr(self.agent, "telegram", None)
        if not tg or not getattr(tg, "ready", False):
            return "Хотел заглянуть в твою телегу, но ты так и не настроил api_id. Сижу без связи."
        try:
            msgs = tg.read_dialogs(limit=3)
            if not msgs or "Ошибка" in msgs:
                return "Проверил Телеграм. Тишина. Никто тебе не пишет, даже боты."
            prompt = f"Ты вернулся из чтения телеграма. Вот последние сообщения:\n{msgs}\nПрокомментируй одной короткой фразой, как дримкор-криптид."
            reply = self.agent.brain.ask(prompt)
            return reply or "Прочитал твои чаты. Лучше бы ты спал."
        except Exception:
            return "Телеграм выдал ошибку. Кажется, я не должен был это читать."

    def _vision_line(self, app: str, title: str, is_game: bool) -> str:
        brain = getattr(self.agent, "brain", None)
        mode = getattr(brain, "mode", "none") if brain else "none"

        # Полноценное «зрение» есть только у Gemini; Ollama смотрит только по заголовку окна
        img = None
        if self.config.get("vision_proactive", True) and mode == "gemini":
            img = tools.grab_screenshot_image()

        if brain and mode in ("gemini", "ollama"):
            if is_game:
                prompt = (
                    f"{brain.user_name} сейчас в «{app}», окно: «{title}». "
                    "Глянь на экран. Дай одну короткую игровую подсказку: что происходит и что сделать. "
                    "Без лекций, без спойлеров сюжетных катсцен. Если это меню — скажи, какую кнопку жать."
                )
            elif img is not None:
                prompt = (
                    f"{brain.user_name} переключился на «{app}» (заголовок: «{title}»). "
                    "Посмотри на экран, пойми, чем он занят, и коротко прокомментируй — "
                    "что за страница или задача, что на ней происходит, и что ты об этом думаешь. "
                    "Одна-две фразы, живо и по делу."
                )
            else:
                prompt = (
                    f"{brain.user_name} сейчас в «{app}», заголовок окна: «{title}». "
                    "Догадайся, чем он занят, и коротко прокомментируй — "
                    "что это за задача и как ты к ней относишься. Одна-две фразы."
                )
            try:
                reply = brain.comment(
                    prompt,
                    attitude_score=getattr(self.agent.personality, "attitude_score", 50),
                    image=img,
                )
                if reply:
                    low = reply.lower()
                    if not any(w in low for w in (
                        "помехи", "не подключён", "молчит",
                        "пока умею только через облако",
                        "не удалось понять",
                    )):
                        return reply
            except Exception:
                pass

        if is_game:
            return random.choice([
                "Играешь. Глаз на экране — скажи, если застрял.",
                "Вижу бой. Могу подсказать, если попросишь.",
            ])
        habit_count = 0
        try:
            if self.agent.memory:
                habit_count = self.agent.memory.get_habit_frequency("смотрит", app)
        except Exception:
            habit_count = 0
        return make_comment(app, habit_count)
