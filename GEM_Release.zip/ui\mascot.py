"""
Интерфейс маскота на Tkinter (без рамок, органический глаз, плавающий ввод).
"""
import os
import math
import random
import threading
import time
import subprocess
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk
from PIL import Image, ImageTk, ImageDraw

from ui.dreamcore_synth import dream_say_char
from config import save_config
from core.emotions import detect_emotion
from modules.voice import Voice

class DreamMascot:
    def __init__(self, agent, config):
        self.agent = agent
        self.config = config
        self.voice = Voice(self.config)

        self.root = tk.Tk()
        self.root.title("Gem Reborn // Liminal Dream")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)

        self.bg_trans = "#010101"
        self.root.configure(bg=self.bg_trans)
        self.root.wm_attributes("-transparentcolor", self.bg_trans)

        self.w, self.h = 320, 535
        self.screen_w = self.root.winfo_screenwidth()
        self.screen_h = self.root.winfo_screenheight()

        self.pos_x = float(self.screen_w - self.w - 60)
        self.pos_y = float(self.screen_h - self.h - 80)
        self.root.geometry(f"{self.w}x{self.h}+{int(self.pos_x)}+{int(self.pos_y)}")

        self.c_paper = "#f4ebd0"
        self.c_rose = "#e5989b"
        self.c_dust = "#b5838d"

        self.sprites = {}
        self.emotion_sprites = {}
        self.load_sprites()

        self.canvas = tk.Canvas(
            self.root, width=self.w, height=self.h,
            bg=self.bg_trans, bd=0, highlightthickness=0
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.mascot_item = self.canvas.create_image(self.w // 2, 305, image=self.sprites.get("idle"))

        self.bubble_bg_item = None
        self.bubble_text_item = None
        self._bubble_img_tk = None
        self._bubble_font = tkfont.Font(self.root, family="Courier New", size=8)

        self.in_entry = tk.Entry(
            self.root, bg=self.bg_trans, fg=self.c_paper, insertbackground=self.c_rose,
            font=("Courier New", 10, "bold"), relief=tk.FLAT, bd=0, justify=tk.CENTER
        )
        self.in_entry.bind("<Return>", self.on_text_submit)
        self.entry_window_item = None

        self.settings_btn_item = self.canvas.create_text(
            self.w - 25, 20, text="⚙", fill=self.c_rose, font=("Segoe UI Symbol", 16, "bold")
        )

        self.state = "idle"
        self.emotion = "neutral"
        self.is_talking = False
        self.is_walking = False
        self.walk_job = None
        self.talk_phase = 0.0

        self._typewriter_job = None
        self._typewriter_text = ""
        self._typewriter_idx = 0
        self.bubble_timer = None
        # Очередь речи: новая реплика ждёт, пока текущая доиграет
        self._speech_queue = []
        self._speech_busy = False

        self.gaze_x = 0.0
        self.gaze_y = 0.0
        self.blink = 0.0
        from collections import OrderedDict
        self._gaze_cache = OrderedDict()
        self._gaze_cache_max = 128
        self._err_log_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data", "gem_errors.log",
        )
        self._explore_watchdog = None

        # Периодические взгляды: изредка — на мышь или на активное окно, потом обратно в центр
        self._glance_target_x = 0.0
        self._glance_target_y = 0.0
        self._glance_until = 0.0
        self._next_glance_at = time.time() + random.uniform(2.0, 4.5)
        self._glancing = False

        self.drag_x = 0
        self.drag_y = 0
        self.is_hiding = False
        self.canvas.tag_bind(self.mascot_item, "<ButtonPress-1>", self._on_drag_start)
        self.canvas.tag_bind(self.mascot_item, "<B1-Motion>", self._on_drag_motion)
        self.canvas.tag_bind(self.mascot_item, "<Double-Button-1>", lambda e: self.show_from_edge() if self.is_hiding else None)
        self.canvas.bind("<Double-Button-1>", lambda e: self.show_from_edge() if self.is_hiding else None)
        self.canvas.tag_bind(self.mascot_item, "<Button-3>", lambda e: self.toggle_floating_input())
        self.canvas.tag_bind(self.settings_btn_item, "<Button-1>", lambda e: self.on_symbol_click())

        self.set_state("idle")
        self.blink_loop()
        self.schedule_roam()
        self.root.after(150, self._gaze_loop)

        # Живые парящие частицы вокруг — не привязаны к Гему
        self._particles = []
        self._exploring = False
        self._return_win = None
        self._return_entry = None
        self._spawn_particles(10)
        self.canvas.tag_raise(self.mascot_item)
        self.canvas.tag_raise(self.settings_btn_item)
        self._last_win_x = self.root.winfo_x()
        self._last_win_y = self.root.winfo_y()
        self._particle_loop()
        self._float_loop()
        self.root.after(30000, self._random_chat_loop)
        self.root.after(45000, self._random_animation_loop)

    def _random_chat_loop(self):
        if not self.config.get("random_chat_enabled", True):
            self.root.after(60000, self._random_chat_loop)
            return
        if getattr(self, "_exploring", False) or self.is_talking or self.is_hiding:
            self.root.after(60000, self._random_chat_loop)
            return
        threading.Thread(target=self._do_random_chat, daemon=True).start()
        cooldown = self.config.get("random_chat_cooldown", 300)
        self.root.after(cooldown * 1000, self._random_chat_loop)

    def _do_random_chat(self):
        if getattr(self, "_random_chat_running", False):
            return
        self._random_chat_running = True
        try:
            prompt = (
                "Ты просто висишь в эфире. Расскажи один короткий интересный факт, "
                "странную мысль или случай из жизни дримкор-криптида. "
                "Без приветствий, сразу по делу. 1-2 предложения."
            )
            reply = self.agent.brain.ask(
                prompt,
                attitude_score=getattr(self.agent.personality, "attitude_score", 50),
            )
            if reply:
                self.say(reply)
        finally:
            self._random_chat_running = False

    def _random_animation_loop(self):
        if not getattr(self, "_exploring", False) and not self.is_talking and not self.is_hiding:
            choice = random.choice(["blink", "look", "burst"])
            if choice == "blink":
                self._blink_sequence()
            elif choice == "look":
                self._glance_target_x = random.uniform(-1.0, 1.0)
                self._glance_target_y = random.uniform(-1.0, 1.0)
                self._glancing = True
                self._glance_until = time.time() + 2.0
            elif choice == "burst":
                self._spawn_burst()
        self.root.after(random.randint(120000, 240000), self._random_animation_loop)

    def hide_at_edge(self):
        # Всегда вызываем в главном потоке Tkinter
        self.root.after(0, self._do_hide_at_edge)

    def _do_hide_at_edge(self):
        if getattr(self, "is_hiding", False):
            return
        if getattr(self, "_exploring", False):
            return
        self.is_hiding = True
        self._hide_pending = True
        self.is_walking = False
        self._walk_token = getattr(self, "_walk_token", 0) + 1
        if self.walk_job:
            try:
                self.root.after_cancel(self.walk_job)
            except Exception:
                pass
            self.walk_job = None
        self._spawn_burst()
        self.set_emotion("sad")

        def _fade(a=1.0):
            if a <= 0.05:
                self.root.attributes("-alpha", 0.0)
                self.root.geometry(f"+{int(self.screen_w) + 500}+{int(self.screen_h) + 500}")
                self.root.update_idletasks()
                self._show_return_input()
                return
            self.root.attributes("-alpha", a)
            self.root.after(30, lambda: _fade(a - 0.1))
        _fade()

    def show_from_edge(self):
        if not getattr(self, "is_hiding", False):
            return
        self.is_hiding = False
        self._hide_pending = False
        self._hide_return_input()
        self.root.attributes("-alpha", 1.0)

        edge = random.choice(["top", "left", "right", "bottom"])
        margin = 30

        if edge == "top":
            sx = random.randint(margin, self.screen_w - self.w - margin)
            sy = -self.h + 40
            peek = (sx, 10)
            final = (sx, random.randint(50, max(60, self.screen_h // 3)))
            self._entrance_face = random.choice(["surprised", "happy"])
        elif edge == "bottom":
            sx = random.randint(margin, self.screen_w - self.w - margin)
            sy = self.screen_h - 40
            peek = (sx, self.screen_h - self.h - 10)
            final = (sx, random.randint(max(60, self.screen_h // 2), self.screen_h - self.h - 50))
            self._entrance_face = random.choice(["surprised", "happy"])
        elif edge == "left":
            sx = -self.w + 40
            sy = random.randint(margin, max(50, self.screen_h - self.h - margin))
            peek = (10, sy)
            final = (random.randint(50, max(60, self.screen_w // 3)), sy)
            self._entrance_face = random.choice(["surprised", "neutral"])
        else:  # right
            sx = self.screen_w - 40
            sy = random.randint(margin, max(50, self.screen_h - self.h - margin))
            peek = (self.screen_w - self.w - 10, sy)
            final = (random.randint(max(60, self.screen_w - self.screen_w // 3), self.screen_w - self.w - 50), sy)
            self._entrance_face = random.choice(["surprised", "neutral"])

        # Телепорт за край экрана (невидим)
        self.pos_x, self.pos_y = float(sx), float(sy)
        self.root.geometry(f"+{int(sx)}+{int(sy)}")
        self._sync_particles_to_window()
        self.set_emotion(self._entrance_face)

        def phase_peek():
            self.walk_to_point(peek[0], peek[1], min_steps=12, step_ms=14)
            self.root.after(280, phase_look)

        def phase_look():
            # Осматривается по сторонам
            dirs = [(-1.0, 0.0), (1.0, 0.0), (-0.7, 0.2), (0.7, -0.2), (0.0, 0.0)]
            for i, (gx, gy) in enumerate(dirs):
                self.root.after(i * 220, lambda a=gx, b=gy: self._force_gaze(a, b))
            self.root.after(len(dirs) * 220 + 250, phase_emerge)

        def phase_emerge():
            self.set_emotion("neutral")
            self.walk_to_point(final[0], final[1], min_steps=30, step_ms=16)
            self.root.after(900, self._spawn_burst)

        self.root.after(120, phase_peek)

    def _force_gaze(self, gx, gy):
        self.gaze_x = max(-1.0, min(1.0, gx))
        self.gaze_y = max(-1.0, min(1.0, gy))
        self._glance_target_x = self.gaze_x
        self._glance_target_y = self.gaze_y
        self._glancing = True
        self._glance_until = time.time() + 0.5
        self._next_glance_at = time.time() + 0.5
        self._show_current_face()

    def _show_return_input(self):
        if getattr(self, "_return_win", None) is not None:
            try:
                self._return_win.deiconify()
                self._return_win.lift()
                self._return_entry.focus_force()
            except Exception:
                pass
            return

        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.attributes("-alpha", 1.0)
        win.configure(bg="#1a1422")

        width, height = 420, 54
        x = (self.screen_w - width) // 2
        y = self.screen_h - height - 40
        win.geometry(f"{width}x{height}+{x}+{y}")

        # Рамка из Canvas с тонкой линией цвета розы
        frame = tk.Frame(win, bg=self.c_rose, bd=0, highlightthickness=0)
        frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        entry = tk.Entry(
            frame, bg="#1a1422", fg=self.c_paper, insertbackground=self.c_rose,
            font=("Courier New", 12, "bold"), relief=tk.FLAT, bd=0, justify=tk.CENTER,
        )
        entry.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)
        placeholder = "вернись…"
        placeholder_low = placeholder.lower()
        entry.insert(0, placeholder)
        entry.config(fg="#7a6878")

        def on_focus_in(_e):
            if entry.get() == placeholder:
                entry.delete(0, tk.END)
                entry.config(fg=self.c_paper)

        def on_focus_out(_e):
            if not entry.get().strip():
                entry.delete(0, tk.END)
                entry.insert(0, placeholder)
                entry.config(fg="#7a6878")

        def on_submit(_e=None):
            text = entry.get().strip().lower()
            self._hide_return_input()
            self.show_from_edge()
            if text and text != placeholder_low and text not in (
                "вернись", "выйди", "покажись", "появись", "гем",
            ):
                self.root.after(
                    2600,
                    lambda: threading.Thread(
                        target=self.process_command_async, args=(text,), daemon=True
                    ).start(),
                )

        entry.bind("<FocusIn>", on_focus_in)
        entry.bind("<FocusOut>", on_focus_out)
        entry.bind("<Return>", on_submit)
        entry.bind("<Escape>", on_submit)

        self._return_win = win
        self._return_entry = entry
        win.deiconify()
        win.lift()
        win.after(150, lambda: (win.focus_force(), entry.focus_force()))

    def _hide_return_input(self):
        if getattr(self, "_return_win", None) is not None:
            try:
                self._return_win.destroy()
            except Exception:
                pass
            self._return_win = None
            self._return_entry = None

    def toggle_floating_input(self):
        if self.entry_window_item is not None:
            self.canvas.delete(self.entry_window_item)
            self.entry_window_item = None
            self.in_entry.pack_forget()
        else:
            self.entry_window_item = self.canvas.create_window(
                self.w // 2, 400, window=self.in_entry, width=240, height=24
            )
            self.in_entry.delete(0, tk.END)
            self.in_entry.focus_force()

    def on_text_submit(self, event=None):
        txt = self.in_entry.get().strip()
        if txt:
            self.toggle_floating_input()
            threading.Thread(target=self.process_command_async, args=(txt,), daemon=True).start()

    def _log_error(self, where: str, exc: Exception = None):
        try:
            import datetime, traceback
            line = f"[{datetime.datetime.now().isoformat()}] {where}: {exc!r}\n"
            if exc is not None:
                line += traceback.format_exc() + "\n"
            with open(self._err_log_path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass

    def process_command_async(self, text: str):
        try:
            self._process_command_async_inner(text)
        except Exception as e:
            self._log_error("process_command_async", e)
            try:
                self.root.after(0, lambda: self.say("Эфир помехи. Скажи ещё раз."))
            except Exception:
                pass

    def _process_command_async_inner(self, text: str):
        if len(text) > 80 and not getattr(self, "_exploring", False):
            quick = random.choice([
                "Так, секунду...",
                "Хм. Дай гляну.",
                "Ого, целая история. Погоди.",
                "Серьёзный запрос. Думаю.",
            ])
            self.root.after(0, lambda: self.say(quick))
        reply = self.agent.execute_plan(text)
        self.say(
            reply,
            emotion=detect_emotion(
                text,
                reply,
                getattr(self.agent.personality, "attitude_score", 50),
            ),
            priority=True,
        )

    def say(self, text: str, emotion=None, priority: bool = False):
        self.root.after(0, lambda: self._enqueue_speech(text, emotion, priority))

    def _enqueue_speech(self, text, emotion, priority: bool):
        text = (text or "").strip()
        if not text:
            return
        if priority:
            # Пользовательский ответ вытесняет текущую фоновую реплику и очередь
            self._speech_queue = [(text, emotion)]
            if self._speech_busy:
                self._cancel_current_speech()
            self._process_speech_queue()
            return
        # Фоновая реплика: не дублируем хвост и ограничиваем очередь
        if self._speech_queue and self._speech_queue[-1][0] == text:
            return
        if self._speech_busy and self._typewriter_text == text:
            return
        self._speech_queue.append((text, emotion))
        if len(self._speech_queue) > 6:
            self._speech_queue = self._speech_queue[:6]
        self._process_speech_queue()

    def _process_speech_queue(self):
        if self._speech_busy:
            return
        if not self._speech_queue:
            return
        text, emotion = self._speech_queue.pop(0)
        self._speech_busy = True
        self._start_speech(text, emotion)

    def _cancel_current_speech(self):
        try:
            self.voice.stop()
        except Exception:
            pass
        if self._typewriter_job:
            try:
                self.root.after_cancel(self._typewriter_job)
            except Exception:
                pass
            self._typewriter_job = None
        if self.bubble_timer:
            try:
                self.root.after_cancel(self.bubble_timer)
            except Exception:
                pass
            self.bubble_timer = None
        self._speech_busy = False
        self.set_state("idle")
        if self.bubble_bg_item:
            self.canvas.delete(self.bubble_bg_item)
            self.bubble_bg_item = None
        if self.bubble_text_item:
            self.canvas.delete(self.bubble_text_item)
            self.bubble_text_item = None

    def _start_speech(self, text: str, emotion=None):
        if not text:
            return

        if emotion is None:
            emotion = detect_emotion(reply=text)
        self.set_emotion(emotion)
        self.voice.speak(text)  # озвучка, если voice_enabled: true

        if self.bubble_timer:
            self.root.after_cancel(self.bubble_timer)
            self.bubble_timer = None

        if self._typewriter_job:
            self.root.after_cancel(self._typewriter_job)
            self._typewriter_job = None

        self._typewriter_text = text
        self._typewriter_idx = 0
        self.set_state("talk")
        self._typewriter_step()

    def _render_dream_bubble(self, current_text: str, cursor: bool = True):
        bw, max_bh = 300, 180
        text_width = 270
        lines = []
        for size in (8, 7, 6):
            self._bubble_font.configure(size=size)
            lines = self._wrap_bubble_text(current_text, text_width)
            if len(lines) <= 13:
                break
        display_text = "\n".join(lines)
        if cursor:
            display_text += "▌"
        line_height = max(10, self._bubble_font.metrics("linespace"))
        bh = min(max_bh, max(66, len(lines) * line_height + 24))
        bubble_bottom = 182
        bubble_y = bubble_bottom - bh / 2

        img = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.rounded_rectangle(
            [4, 4, bw - 4, bh - 12],
            radius=22,
            fill=(24, 20, 34, 240),
            outline=(109, 89, 122, 255),
            width=2,
        )
        draw.polygon(
            [(bw // 2 - 10, bh - 13), (bw // 2 + 10, bh - 13), (bw // 2, bh - 2)],
            fill=(24, 20, 34, 240),
        )

        self._bubble_img_tk = ImageTk.PhotoImage(img)

        if self.bubble_bg_item is None:
            self.bubble_bg_item = self.canvas.create_image(
                self.w // 2, bubble_y, image=self._bubble_img_tk
            )
            self.bubble_text_item = self.canvas.create_text(
                self.w // 2, bubble_y - 6, text=display_text,
                fill=self.c_paper, font=self._bubble_font,
                width=text_width, justify=tk.CENTER,
            )
        else:
            self.canvas.itemconfig(self.bubble_bg_item, image=self._bubble_img_tk)
            self.canvas.coords(self.bubble_bg_item, self.w // 2, bubble_y)
            self.canvas.itemconfig(self.bubble_text_item, text=display_text)
            self.canvas.coords(self.bubble_text_item, self.w // 2, bubble_y - 6)

    def _wrap_bubble_text(self, text: str, width: int) -> list:
        lines = []
        for paragraph in (text or "").splitlines() or [""]:
            words = paragraph.split()
            line = ""
            for word in words:
                if self._bubble_font.measure(word) > width:
                    fragments = []
                    fragment = ""
                    for char in word:
                        if fragment and self._bubble_font.measure(fragment + char) > width:
                            fragments.append(fragment)
                            fragment = char
                        else:
                            fragment += char
                    if fragment:
                        fragments.append(fragment)
                    words_to_add = fragments
                else:
                    words_to_add = [word]

                for part in words_to_add:
                    candidate = f"{line} {part}".strip()
                    if line and self._bubble_font.measure(candidate) > width:
                        lines.append(line)
                        line = part
                    else:
                        line = candidate
            lines.append(line)
        return lines or [""]

    def _typewriter_step(self):
        if self._typewriter_idx <= len(self._typewriter_text):
            cur = self._typewriter_text[:self._typewriter_idx]
            self._render_dream_bubble(cur)

            if self._typewriter_idx > 0:
                char = self._typewriter_text[self._typewriter_idx - 1]
                if self.config.get("sound_enabled", True):
                    dream_say_char(char)

            self._typewriter_idx += 1
            delay = 32
            if self._typewriter_idx > 1:
                last_c = self._typewriter_text[self._typewriter_idx - 2]
                if last_c in [".", "!", "?", "\n"]:
                    delay = 180
                elif last_c in [",", ";", ":", "—", "-"]:
                    delay = 70

            self._typewriter_job = self.root.after(delay, self._typewriter_step)
        else:
            self._render_dream_bubble(self._typewriter_text, cursor=False)
            self._typewriter_job = None
            self.set_state("idle")
            dur = max(4000, min(14000, len(self._typewriter_text) * 75))
            self.bubble_timer = self.root.after(dur, self._hide_bubble)

    def _hide_bubble(self):
        if self.bubble_bg_item:
            self.canvas.delete(self.bubble_bg_item)
            self.bubble_bg_item = None
        if self.bubble_text_item:
            self.canvas.delete(self.bubble_text_item)
            self.bubble_text_item = None
        self.set_emotion("neutral")
        self.set_state("idle")
        # Текущая реплика доиграла — запускаем следующую из очереди
        self._speech_busy = False
        self._process_speech_queue()

    def on_symbol_click(self):
        self._open_settings_window()

    def _open_settings_window(self):
        if getattr(self, "_settings_win", None) is not None:
            try:
                self._settings_win.deiconify()
                self._settings_win.lift()
                self._settings_win.focus_force()
                return
            except Exception:
                self._settings_win = None

        win = tk.Toplevel(self.root)
        win.title("Настройки Гема")
        win.configure(bg="#1a1422")
        win_w = min(560, max(440, self.screen_w - 120))
        win_h = min(680, max(520, self.screen_h - 120))
        win.geometry(f"{win_w}x{win_h}+{(self.screen_w - win_w)//2}+{(self.screen_h - win_h)//2}")
        win.attributes("-topmost", True)

        def on_close():
            self._settings_win = None
            try:
                win.destroy()
            except Exception:
                pass
        win.protocol("WM_DELETE_WINDOW", on_close)

        try:
            style = ttk.Style(win)
            style.theme_use("clam")
            style.configure("TFrame", background="#1a1422")
            style.configure("TLabel", background="#1a1422", foreground=self.c_paper, font=("Segoe UI", 10))
            style.configure("TCheckbutton", background="#1a1422", foreground=self.c_paper, font=("Segoe UI", 10))
            style.map("TCheckbutton", background=[("active", "#1a1422")])
            style.configure("TNotebook", background="#1a1422", borderwidth=0)
            style.configure("TNotebook.Tab", background="#241830", foreground=self.c_paper, padding=[12, 4])
            style.map("TNotebook.Tab", background=[("selected", "#3b2a4d")])
            style.configure("TButton", font=("Segoe UI", 10), padding=[10, 4])
            style.configure("TEntry", fieldbackground="#0f0b16", foreground=self.c_paper, insertcolor=self.c_rose, padding=3)
            style.configure("TSpinbox", fieldbackground="#0f0b16", foreground=self.c_paper, insertcolor=self.c_rose, padding=3)
        except Exception:
            pass

        nb = ttk.Notebook(win)
        nb.pack(fill=tk.BOTH, expand=True, padx=10, pady=(10, 6))

        vars_ = {}

        def _entry(parent, label, key, show=None):
            row = ttk.Frame(parent)
            row.pack(fill=tk.X, padx=8, pady=4)
            ttk.Label(row, text=label, width=24, anchor="w").pack(side=tk.LEFT)
            raw = self.config.get(key)
            val = "" if raw is None else str(raw)
            var = tk.StringVar(value=val)
            ttk.Entry(row, textvariable=var, show=show or "").pack(side=tk.LEFT, fill=tk.X, expand=True)
            vars_[key] = ("str", var)

        def _spin(parent, label, key, min_, max_):
            row = ttk.Frame(parent)
            row.pack(fill=tk.X, padx=8, pady=4)
            ttk.Label(row, text=label, width=24, anchor="w").pack(side=tk.LEFT)
            try:
                v = int(self.config.get(key, min_) or min_)
            except Exception:
                v = min_
            var = tk.IntVar(value=v)
            ttk.Spinbox(row, from_=min_, to=max_, textvariable=var, width=10).pack(side=tk.LEFT)
            vars_[key] = ("int", var)

        def _bool(parent, label, key):
            var = tk.BooleanVar(value=bool(self.config.get(key, False)))
            ttk.Checkbutton(parent, text=label, variable=var).pack(anchor="w", padx=8, pady=2)
            vars_[key] = ("bool", var)

        t1 = ttk.Frame(nb)
        nb.add(t1, text="Основное")
        _entry(t1, "Имя пользователя", "user_name")
        _spin(t1, "Характер (1 добрый — 3 злой)", "cruelty_level", 1, 3)
        _bool(t1, "Безопасный режим", "safe_mode")
        _bool(t1, "Звуки дримкора", "sound_enabled")
        _bool(t1, "Учиться по активности", "learn_from_activity")

        t2 = ttk.Frame(nb)
        nb.add(t2, text="Голос")
        _bool(t2, "Озвучка (edge-tts)", "voice_enabled")
        _entry(t2, "Голос", "voice_name")
        _entry(t2, "Скорость", "voice_rate")
        _entry(t2, "Громкость", "voice_volume")
        
        # Микрофон
        row_mic = ttk.Frame(t2)
        row_mic.pack(fill=tk.X, padx=8, pady=4)
        ttk.Label(row_mic, text="Микрофон", width=24, anchor="w").pack(side=tk.LEFT)
        mic_names = ["Системный по умолчанию"]
        seen_names = set()
        try:
            import pyaudio
            import sounddevice as sd
            sd_devs = sd.query_devices()
            pa = pyaudio.PyAudio()
            count = pa.get_device_count()
            for i in range(count):
                try:
                    info = pa.get_device_info_by_index(i)
                    if info.get("maxInputChannels", 0) > 0:
                        name = info.get("name", f"Устройство {i}")
                        if i < len(sd_devs):
                            sd_name = sd_devs[i].get("name")
                            if sd_name and "?" not in sd_name:
                                name = sd_name
                        name = name.strip()
                        # Фильтруем динамики и выходы
                        nl = name.lower()
                        if any(bad in nl for bad in ("динамик", "speaker", "output", "headphone", "наушник")):
                            continue
                        # Убираем дубликаты по имени (первое совпадение оставляем)
                        if name not in seen_names:
                            seen_names.add(name)
                            mic_names.append(f"{i}: {name[:45]}")
                except Exception:
                    pass
            pa.terminate()
        except Exception as e:
            print(f"[UI] Ошибка загрузки микрофонов: {e}")
            for i in range(6):
                mic_names.append(f"{i}: Микрофон #{i}")

        current_mic = self.config.get("mic_index")
        current_name = mic_names[0]
        if current_mic is not None:
            try:
                cm = int(current_mic)
                for n in mic_names:
                    if n.startswith(f"{cm}:"):
                        current_name = n
                        break
            except Exception:
                pass
        mic_var = tk.StringVar(value=current_name)
        mic_combo = ttk.Combobox(row_mic, textvariable=mic_var, values=mic_names, state="readonly", width=30)
        mic_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)

        def _test_mic():
            v = mic_var.get()
            idx = None
            if v != mic_names[0]:
                try:
                    idx = int(v.split(":", 1)[0])
                except Exception:
                    pass
            print(f"[MIC TEST] Слушаю микрофон {idx if idx is not None else 'по умолчанию'} (3 сек)...")
            import threading
            import speech_recognition as sr
            def _run():
                try:
                    r = sr.Recognizer()
                    with sr.Microphone(device_index=idx) as source:
                        r.adjust_for_ambient_noise(source, duration=0.5)
                        audio = r.listen(source, timeout=3, phrase_time_limit=3)
                    text = r.recognize_google(audio, language="ru-RU")
                    print(f"[MIC TEST] Услышал: {text}")
                except Exception as e:
                    print(f"[MIC TEST] Ошибка: {e.__class__.__name__}: {e}")
            threading.Thread(target=_run, daemon=True).start()

        ttk.Button(row_mic, text="Тест", width=6, command=_test_mic).pack(side=tk.LEFT, padx=4)

        def _on_mic_change(event=None):
            v = mic_var.get()
            if v == mic_names[0]:
                vars_["mic_index"] = ("int", tk.IntVar(value=0))
            else:
                try:
                    idx = int(v.split(":", 1)[0])
                    vars_["mic_index"] = ("int", tk.IntVar(value=idx))
                except Exception:
                    vars_["mic_index"] = ("int", tk.IntVar(value=0))
        mic_combo.bind("<<ComboboxSelected>>", _on_mic_change)
        _on_mic_change()

        ttk.Label(
            t2,
            text="Доступные голоса: ru-RU-DmitryNeural (муж), ru-RU-SvetlanaNeural (жен)",
            foreground="#b5838d", font=("Segoe UI", 8), wraplength=500, justify=tk.LEFT,
        ).pack(anchor="w", padx=8, pady=(8, 2))

        t3 = ttk.Frame(nb)
        nb.add(t3, text="Поведение")
        _bool(t3, "Комментирует сам", "proactive_enabled")
        _spin(t3, "Пауза, сек", "proactive_cooldown", 30, 3600)
        _bool(t3, "Игровые подсказки", "game_coach")
        _spin(t3, "Пауза подсказок, сек", "game_coach_cooldown", 30, 3600)
        _bool(t3, "Ходит исследовать", "explore_enabled")
        _spin(t3, "Пауза исследований, сек", "explore_cooldown", 60, 7200)
        _bool(t3, "Случайные истории", "random_chat_enabled")
        _spin(t3, "Пауза историй, сек", "random_chat_cooldown", 60, 7200)
        _bool(t3, "Смотрит скриншоты (vision)", "vision_proactive")

        t4 = ttk.Frame(nb)
        nb.add(t4, text="Мозг")
        _entry(t4, "Gemini API-ключ", "api_key", show="*")
        _entry(t4, "Модель Gemini", "model_name")
        _entry(t4, "Модель Ollama", "ollama_model")
        ttk.Label(
            t4,
            text="Ключ Gemini: aistudio.google.com/apikey. Ollama — если ключа Gemini нет.",
            foreground="#b5838d", font=("Segoe UI", 8), wraplength=500, justify=tk.LEFT,
        ).pack(anchor="w", padx=8, pady=(8, 2))

        t5 = ttk.Frame(nb)
        nb.add(t5, text="Telegram")
        _entry(t5, "API ID", "telegram_api_id")
        _entry(t5, "API Hash", "telegram_api_hash", show="*")
        ttk.Label(
            t5,
            text="Ключи: my.telegram.org → API development tools.\nПосле сохранения запусти в терминале: python telegram_login.py",
            foreground="#b5838d", font=("Segoe UI", 8), wraplength=500, justify=tk.LEFT,
        ).pack(anchor="w", padx=8, pady=(8, 2))

        bottom = ttk.Frame(win)
        bottom.pack(fill=tk.X, padx=10, pady=(0, 10))

        def open_sprites():
            sprites_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "assets", "sprites",
            )
            os.makedirs(sprites_dir, exist_ok=True)
            try:
                subprocess.Popen(["explorer", os.path.normpath(sprites_dir)])
            except Exception:
                try:
                    os.startfile(sprites_dir)
                except Exception:
                    pass

        def reload_sprites():
            try:
                self.sprites = {}
                self.emotion_sprites = {}
                self._gaze_cache.clear()
                self.load_sprites()
                self._show_current_face()
            except Exception as e:
                self._log_error("reload_sprites", e)

        def on_save():
            new_vals = {}
            for key, (kind, var) in vars_.items():
                try:
                    if kind == "int":
                        new_vals[key] = int(var.get())
                    elif kind == "bool":
                        new_vals[key] = bool(var.get())
                    else:
                        new_vals[key] = str(var.get())
                except Exception:
                    pass
            for k, v in new_vals.items():
                self.config[k] = v
            try:
                self.config["cruelty_level"] = max(1, min(3, int(self.config.get("cruelty_level", 2))))
            except Exception:
                self.config["cruelty_level"] = 2
            tgid = self.config.get("telegram_api_id")
            if tgid in (None, "", "None"):
                self.config["telegram_api_id"] = None
            else:
                try:
                    self.config["telegram_api_id"] = int(tgid)
                except Exception:
                    self.config["telegram_api_id"] = None
            self.config["telegram_api_hash"] = (self.config.get("telegram_api_hash") or "").strip()
            self.config["api_key"] = (self.config.get("api_key") or "").strip()
            save_config(self.config)
            self._apply_config_runtime()
            on_close()
            self.say("настройки сохранены.")

        ttk.Button(bottom, text="Открыть папку спрайтов", command=open_sprites).pack(side=tk.LEFT, padx=2)
        ttk.Button(bottom, text="Перезагрузить спрайты", command=reload_sprites).pack(side=tk.LEFT, padx=2)
        ttk.Button(bottom, text="Сохранить", command=on_save).pack(side=tk.RIGHT, padx=2)
        ttk.Button(bottom, text="Отмена", command=on_close).pack(side=tk.RIGHT, padx=2)

        self._settings_win = win

    def _apply_config_runtime(self):
        try:
            self.voice.enabled = bool(self.config.get("voice_enabled", False))
            self.voice.voice_name = self.config.get("voice_name", "ru-RU-DmitryNeural")
            self.voice.rate = self.config.get("voice_rate", "+0%")
            self.voice.volume = self.config.get("voice_volume", "+0%")
        except Exception:
            pass
        try:
            brain = self.agent.brain
            old_key = brain.api_key
            new_key = (self.config.get("api_key") or "").strip()
            brain.api_key = new_key
            brain.cloud_model = self.config.get("model_name", "gemini-3.8-flash")
            brain.ollama_model = self.config.get("ollama_model", "qwen2.5:3b")
            brain.user_name = self.config.get("user_name", "Захар")
            if old_key != new_key:
                try:
                    brain.mode = brain._detect_mode()
                except Exception:
                    pass
        except Exception:
            pass
        try:
            from modules.telegram import TelegramSender
            self.agent.telegram = TelegramSender(self.config)
        except Exception:
            pass
        try:
            obs = getattr(self, "observer", None)
            if obs is not None:
                obs.cooldown = int(self.config.get("proactive_cooldown", 180) or 180)
                obs.game_cooldown = int(self.config.get("game_coach_cooldown", 90) or 90)
                obs.explore_cooldown = int(self.config.get("explore_cooldown", 600) or 600)
        except Exception:
            pass

    def load_sprites(self):
        names = ["idle", "blink_half", "blink_closed", "talk_1", "talk_2", "talk_3", "talk_4"]
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        mascot_dir = os.path.join(root_dir, "assets", "sprites")
        try:
            os.makedirs(mascot_dir, exist_ok=True)
            readme = os.path.join(mascot_dir, "README.txt")
            if not os.path.exists(readme):
                with open(readme, "w", encoding="utf-8") as f:
                    f.write(
                        "Спрайты Гема\n"
                        "============\n\n"
                        "Положи сюда PNG-файлы с прозрачным фоном (альфа-канал),\n"
                        "чтобы заменить модельку Гема на свою.\n\n"
                        "Размер: 220x240 пикселей (рекомендуется).\n"
                        "Формат: PNG с прозрачностью.\n\n"
                        "Имена файлов (все опциональны, но нужен хотя бы idle.png):\n"
                        "  idle.png         — основной спрайт\n"
                        "  talk_1.png       — анимация говорит (кадр 1)\n"
                        "  talk_2.png       — кадр 2\n"
                        "  talk_3.png       — кадр 3\n"
                        "  talk_4.png       — кадр 4\n"
                        "  blink_half.png   — прищур\n"
                        "  blink_closed.png — закрытые глаза\n\n"
                        "Если idle.png нет — Гем рисует свой дримкор-глаз.\n\n"
                        "После замены файлов: нажми шестерёнку в углу Гема → Перезагрузить спрайты.\n"
                        "Или перезапусти Гема.\n"
                    )
        except Exception:
            pass
        for n in names:
            p = os.path.join(mascot_dir, f"{n}.png")
            if os.path.exists(p):
                with Image.open(p) as img_raw:
                    img = img_raw.convert("RGBA").resize((220, 240))
                    self.sprites[n] = ImageTk.PhotoImage(img)

        if "idle" not in self.sprites:
            self._create_organic_dream_eye()

    def _create_organic_dream_eye(self):
        for expression in ("neutral", "happy", "angry", "sad", "surprised"):
            self.emotion_sprites[expression] = ImageTk.PhotoImage(
                self._draw_dream_eye(expression)
            )
        self.sprites["idle"] = self.emotion_sprites["neutral"]
        for i in range(1, 5):
            self.sprites[f"talk_{i}"] = self.sprites["idle"]

    @staticmethod
    def _draw_dream_eye(expression, look_x=0.0, look_y=0.0, blink=0.0):
        # Рисуем в 2x разрешении для идеального сглаживания (антиалиасинга)
        S = 2
        image = Image.new("RGBA", (220 * S, 240 * S), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)

        cx, cy = 110 * S, 115 * S
        star = [
            (110*S, 15*S), (140*S, 85*S), (205*S, 115*S), (140*S, 145*S),
            (110*S, 215*S), (80*S, 145*S), (15*S, 115*S), (80*S, 85*S),
        ]

        # Внешняя звезда (без ауры — она давала чёрный ореол на прозрачном окне)
        draw.polygon(star, fill=(30, 20, 42, 255), outline=(181, 131, 141, 255), width=2*S)

        # Внутренняя «двойная» звезда — тонкий контур, придаёт дримкор-глубину
        def _scale(p, s):
            return (cx + (p[0] - cx) * s, cy + (p[1] - cy) * s)
        inner = [_scale(p, 0.58) for p in star]
        draw.line(inner + [inner[0]], fill=(181, 131, 141, 160), width=2*S)

        # Форма глаза в зависимости от эмоции
        if expression == "surprised":
            eye_box = (62*S, 78*S, 158*S, 152*S)
            iris_r, pupil_r = 14*S, 7*S
        elif expression == "angry":
            eye_box = (68*S, 96*S, 152*S, 136*S)
            iris_r, pupil_r = 13*S, 7*S
        elif expression == "sad":
            eye_box = (68*S, 82*S, 152*S, 148*S)
            iris_r, pupil_r = 14*S, 8*S
        elif expression == "happy":
            eye_box = (64*S, 90*S, 156*S, 140*S)
            iris_r, pupil_r = 14*S, 8*S
        else:
            eye_box = (66*S, 84*S, 154*S, 146*S)
            iris_r, pupil_r = 15*S, 8*S

        ex_c = (eye_box[0] + eye_box[2]) / 2
        ey_c = (eye_box[1] + eye_box[3]) / 2
        eye_rx = (eye_box[2] - eye_box[0]) / 2
        eye_ry = (eye_box[3] - eye_box[1]) / 2

        # Смещение взгляда — ограничено, чтобы радужка не вылезла за белок
        max_dx = max(0, eye_rx - iris_r - 6*S)
        max_dy = max(0, eye_ry - iris_r - 6*S)
        dx = look_x * max_dx
        dy = look_y * max_dy

        iris_cx = ex_c + dx
        iris_cy = ey_c + dy
        iris_box = (iris_cx - iris_r, iris_cy - iris_r, iris_cx + iris_r, iris_cy + iris_r)
        pupil_box = (iris_cx - pupil_r, iris_cy - pupil_r, iris_cx + pupil_r, iris_cy + pupil_r)

        # Белок
        draw.ellipse(eye_box, fill=(244, 235, 208, 255), outline=(109, 89, 122, 255), width=2*S)
        # Радужка с кольцом
        draw.ellipse(iris_box, fill=(181, 131, 141, 255))
        draw.ellipse(iris_box, outline=(122, 90, 110, 255), width=2*S)
        # Зрачок
        draw.ellipse(pupil_box, fill=(20, 12, 24, 255))
        # Блики
        draw.ellipse(
            (iris_cx - 5*S, iris_cy - 6*S, iris_cx - 1*S, iris_cy - 2*S),
            fill=(255, 255, 255, 255),
        )
        draw.ellipse(
            (iris_cx + 2*S, iris_cy + 1*S, iris_cx + 5*S, iris_cy + 4*S),
            fill=(255, 255, 255, 170),
        )

        # Веки — эллиптические «створки», точно совпадающие с формой белка
        if blink > 0.01:
            ex0, ey0, ex1, ey1 = eye_box
            h_eye = ey1 - ey0
            lid_color = (30, 20, 42, 255)
            lid_outline = (181, 131, 141, 255)
            half = blink / 2.0

            top_center = ey0 + half * h_eye
            top_y2 = 2 * top_center - ey0
            if top_y2 > ey0 + 1:
                draw.pieslice((ex0, ey0, ex1, top_y2), 180, 360, fill=lid_color)
                draw.arc(eye_box, 180, 360, fill=lid_outline, width=2*S)

            bottom_center = ey1 - half * h_eye
            bottom_y0 = 2 * bottom_center - ey1
            if ey1 > bottom_y0 + 1:
                draw.pieslice((ex0, bottom_y0, ex1, ey1), 0, 180, fill=lid_color)
                draw.arc(eye_box, 0, 180, fill=lid_outline, width=2*S)

        # Эмоциональные акценты (тонкие, не перекрывают глаз)
        if expression == "angry":
            draw.line([(78*S, 74*S), (100*S, 84*S)], fill=(72, 39, 62, 255), width=3*S)
            draw.line([(142*S, 74*S), (120*S, 84*S)], fill=(72, 39, 62, 255), width=3*S)
            draw.line([(172*S, 42*S), (182*S, 52*S)], fill=(229, 152, 155, 255), width=2*S)
            draw.line([(172*S, 52*S), (182*S, 42*S)], fill=(229, 152, 155, 255), width=2*S)
        elif expression == "sad":
            draw.line([(78*S, 82*S), (100*S, 74*S)], fill=(109, 89, 122, 255), width=2*S)
            draw.line([(142*S, 82*S), (120*S, 74*S)], fill=(109, 89, 122, 255), width=2*S)
            # Слеза справа-снизу
            draw.ellipse((148*S, 142*S, 154*S, 152*S), fill=(150, 190, 220, 200))
        elif expression == "happy":
            draw.ellipse((72*S, 122*S, 82*S, 130*S), fill=(229, 152, 155, 150))
            draw.ellipse((138*S, 122*S, 148*S, 130*S), fill=(229, 152, 155, 150))
        elif expression == "surprised":
            draw.arc((72*S, 62*S, 148*S, 92*S), 200, 340, fill=(181, 131, 141, 220), width=2*S)

        return image.resize((220, 240), Image.LANCZOS)

    def _pick_glance_target(self):
        """Куда посмотреть в следующий раз: на мышь, на активное окно или в случайную сторону."""
        try:
            roll = random.random()
            if roll < 0.45:
                mx = self.root.winfo_pointerx()
                my = self.root.winfo_pointery()
            else:
                rect = None
                try:
                    from modules.tools import foreground_window_rect
                    rect = foreground_window_rect()
                except Exception:
                    rect = None
                if rect and roll < 0.85:
                    mx = (rect[0] + rect[2]) // 2
                    my = (rect[1] + rect[3]) // 2
                else:
                    mx = random.randint(0, self.screen_w)
                    my = random.randint(0, self.screen_h)
            ix, iy = self.canvas.coords(self.mascot_item)
            cx = self.root.winfo_x() + int(ix)
            cy = self.root.winfo_y() + int(iy)
            dx = mx - cx
            dy = my - cy
            return (
                max(-1.0, min(1.0, dx / 350.0)),
                max(-1.0, min(1.0, dy / 350.0)),
            )
        except Exception:
            return 0.0, 0.0

    def _gaze_loop(self):
        try:
            now = time.time()
            # Спланировать / завершить «взгляд»
            if not self._glancing and now >= self._next_glance_at:
                self._glance_target_x, self._glance_target_y = self._pick_glance_target()
                self._glance_until = now + random.uniform(1.4, 2.6)
                self._glancing = True
            elif self._glancing and now >= self._glance_until:
                self._glance_target_x = 0.0
                self._glance_target_y = 0.0
                self._glancing = False
                self._next_glance_at = now + random.uniform(3.5, 8.0)

            # Плавно вести зрачок к цели
            tx, ty = self._glance_target_x, self._glance_target_y
            nx = self.gaze_x + (tx - self.gaze_x) * 0.18
            ny = self.gaze_y + (ty - self.gaze_y) * 0.18
            if abs(nx - self.gaze_x) > 0.02 or abs(ny - self.gaze_y) > 0.02:
                self.gaze_x = nx
                self.gaze_y = ny
                self._show_current_face()
            else:
                self.gaze_x = tx
                self.gaze_y = ty
        except Exception as e:
            self._log_error("gaze_loop", e)
        try:
            self.root.after(60, self._gaze_loop)
        except Exception:
            pass

    def _spawn_particles(self, count: int = 7):
        colors = [self.c_paper, self.c_rose, self.c_dust]
        for _ in range(count):
            px = random.uniform(15, self.w - 15)
            py = random.uniform(15, self.h - 15)
            size = random.uniform(1.2, 2.6)
            item = self.canvas.create_oval(
                px - size, py - size, px + size, py + size,
                fill=random.choice(colors), outline=""
            )
            self._particles.append({
                "x": px, "y": py,
                "vx": random.uniform(-0.4, 0.4),
                "vy": random.uniform(-0.4, 0.4),
                "size": size,
                "tw_speed": random.uniform(0.6, 1.8),
                "phase": random.uniform(0, math.tau),
                "item": item,
            })

    def _sync_particles_to_window(self):
        wx = self.root.winfo_x()
        wy = self.root.winfo_y()
        dx = wx - self._last_win_x
        dy = wy - self._last_win_y
        if dx or dy:
            for p in self._particles:
                p["x"] -= dx
                p["y"] -= dy
            self._last_win_x, self._last_win_y = wx, wy

    def _particle_loop(self):
        try:
            self._sync_particles_to_window()
            t = time.time()
            alive = []
            for p in self._particles:
                if "life" in p:
                    p["life"] -= 0.02
                    if p["life"] <= 0:
                        try:
                            self.canvas.delete(p["item"])
                        except Exception:
                            pass
                        continue
                    s = max(0.3, p["size"] * p["life"])
                else:
                    tw = 0.55 + 0.45 * abs(math.sin(t * p["tw_speed"] + p["phase"]))
                    s = max(0.3, p["size"] * tw)

                p["x"] += p["vx"] * 0.3
                p["y"] += p["vy"] * 0.3
                if p["x"] < -10:
                    p["x"] = self.w + 10
                elif p["x"] > self.w + 10:
                    p["x"] = -10
                if p["y"] < -10:
                    p["y"] = self.h + 10
                elif p["y"] > self.h + 10:
                    p["y"] = -10
                try:
                    self.canvas.coords(p["item"], p["x"] - s, p["y"] - s, p["x"] + s, p["y"] + s)
                except Exception:
                    continue
                alive.append(p)
            self._particles = alive
        except Exception as e:
            self._log_error("particle_loop", e)
        try:
            self.root.after(33, self._particle_loop)
        except Exception:
            pass

    def _spawn_burst(self):
        for _ in range(20):
            px, py = self.w // 2, 305
            size = random.uniform(1.5, 3.5)
            item = self.canvas.create_oval(px, py, px, py, fill=random.choice([self.c_paper, self.c_rose, self.c_dust]), outline="")
            angle = random.uniform(0, math.pi * 2)
            speed = random.uniform(3, 8)
            self._particles.append({
                "x": px, "y": py,
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "size": size,
                "tw_speed": 0, "phase": 0,
                "item": item,
                "life": 1.0
            })

    def leave_for_exploration(self, task_name, task_func):
        """Потокобезопасный запуск ухода (Tkinter трогаем только в главном потоке)."""
        self.root.after(0, self._begin_exploration, task_name, task_func)

    def _begin_exploration(self, task_name, task_func):
        if getattr(self, "_exploring", False):
            return
        if self.is_talking or getattr(self, "_speech_busy", False):
            return
        if self.is_walking or getattr(self, "is_hiding", False):
            return
        if self.state in ("sleep", "talk"):
            return
        self._exploring = True
        # Часовой: через 5 минут принудительно возвращаемся, даже если explore висит
        try:
            if getattr(self, "_explore_watchdog", None):
                self.root.after_cancel(self._explore_watchdog)
        except Exception:
            pass
        self._explore_watchdog = self.root.after(300_000, self._explore_timeout)
        self.is_talking = False
        self.state = "sleep"
        self.set_emotion("sad")
        self._spawn_burst()

        if self.walk_job:
            try:
                self.root.after_cancel(self.walk_job)
            except Exception:
                pass
            self.walk_job = None
        self.is_walking = False

        def fade_out(a=1.0):
            if a <= 0.05:
                self.root.attributes("-alpha", 0.0)
                self.root.withdraw()
                threading.Thread(target=self._do_explore, args=(task_name, task_func), daemon=True).start()
                return
            self.root.attributes("-alpha", a)
            self.root.after(40, lambda: fade_out(a - 0.1))
        fade_out()

    def _do_explore(self, task_name, task_func):
        reply = ""
        try:
            reply = task_func() or ""
        except Exception as e:
            self._log_error("do_explore", e)
            reply = "Эфир подвёл. Ничего не нашёл."
        try:
            time.sleep(random.randint(60, 180))
        except Exception:
            pass
        try:
            self.root.after(0, self._return_from_explore, reply)
        except Exception:
            pass

    def _explore_timeout(self):
        self._explore_watchdog = None
        if getattr(self, "_exploring", False):
            try:
                self._return_from_explore("Задержался в эфире. Уже тут.")
            except Exception as e:
                self._log_error("explore_timeout", e)

    def _return_from_explore(self, reply):
        if not getattr(self, "_exploring", False):
            return
        self._exploring = False
        try:
            if getattr(self, "_explore_watchdog", None):
                self.root.after_cancel(self._explore_watchdog)
        except Exception:
            pass
        self._explore_watchdog = None
        try:
            self.root.deiconify()
        except Exception:
            pass
        self.root.attributes("-alpha", 0.0)
        self.set_emotion("neutral")
        self.blink = 0.0
        self._spawn_burst()

        def fade_in(a=0.0):
            if a >= 1.0:
                self.root.attributes("-alpha", 1.0)
                self.state = "idle"
                if reply:
                    self.say(reply)
                return
            self.root.attributes("-alpha", a)
            self.root.after(50, lambda: fade_in(a + 0.1))
        fade_in()

    def _float_loop(self):
        try:
            t = time.time()
            offset_x = math.sin(t * 0.7) * 3.0
            offset_y = math.sin(t * 1.15 + 0.6) * 6.0
            self.canvas.coords(self.mascot_item, self.w // 2 + offset_x, 305 + offset_y)
        except Exception as e:
            self._log_error("float_loop", e)
        try:
            self.root.after(33, self._float_loop)
        except Exception:
            pass

    def set_emotion(self, emotion):
        if emotion not in self.emotion_sprites:
            emotion = "neutral"
        self.emotion = emotion
        self._show_current_face()

    def _show_current_face(self):
        if self.state == "blink":
            return
        if not self.emotion_sprites:
            image = None
            if self.blink >= 0.95 and "blink_closed" in self.sprites:
                image = self.sprites["blink_closed"]
            elif self.blink >= 0.5 and "blink_half" in self.sprites:
                image = self.sprites["blink_half"]
            else:
                image = self.sprites.get(self.emotion, self.sprites.get("idle"))
            if image:
                self.canvas.itemconfig(self.mascot_item, image=image)
            return
        gx = round(self.gaze_x * 3) / 3
        gy = round(self.gaze_y * 3) / 3
        b = round(self.blink * 4) / 4
        key = (self.emotion, gx, gy, b)
        if key in self._gaze_cache:
            self._gaze_cache.move_to_end(key)
        else:
            img = self._draw_dream_eye(self.emotion, gx, gy, b)
            self._gaze_cache[key] = ImageTk.PhotoImage(img)
            if len(self._gaze_cache) > self._gaze_cache_max:
                self._gaze_cache.popitem(last=False)
        self.canvas.itemconfig(self.mascot_item, image=self._gaze_cache[key])

    def set_state(self, state):
        self.state = state
        if state == "talk":
            self.is_talking = True
            self.talk_phase = 0.0
            self._smooth_talk()
        else:
            self.is_talking = False
            if state in self.sprites:
                self._show_current_face()
                if not self.emotion_sprites:
                    self.canvas.itemconfig(self.mascot_item, image=self.sprites[state])

    def _smooth_talk(self):
        if not self.is_talking:
            self.set_state("idle")
            return
        frames = ["talk_1", "talk_2", "talk_3", "talk_4"]
        idx = int(self.talk_phase) % len(frames)
        fn = frames[idx]
        if self.emotion_sprites:
            self._show_current_face()
        elif fn in self.sprites:
            self.canvas.itemconfig(self.mascot_item, image=self.sprites[fn])
        self.talk_phase += 0.35
        if self.talk_phase < 24:
            self.root.after(30, self._smooth_talk)
        else:
            if self._typewriter_job is None:
                self.is_talking = False
                self.set_state("idle")

    def blink_loop(self):
        try:
            if self.state == "idle" and not self.is_talking:
                self._blink_sequence()
        except Exception as e:
            self._log_error("blink_loop", e)
        try:
            self.root.after(random.randint(3500, 7000), self.blink_loop)
        except Exception:
            pass

    def _blink_sequence(self, step=0):
        sequence = [0.0, 0.3, 0.7, 1.0, 0.7, 0.3, 0.0]
        if step >= len(sequence):
            return
        self.blink = sequence[step]
        self._show_current_face()
        self.root.after(35, lambda: self._blink_sequence(step + 1))

    def schedule_roam(self):
        if self.walk_job:
            try:
                self.root.after_cancel(self.walk_job)
            except Exception:
                pass
        self.walk_job = self.root.after(random.randint(22000, 48000), self.random_walk)

    def _is_moving(self) -> bool:
        return bool(
            self.is_walking
            or getattr(self, "is_hiding", False)
            or getattr(self, "_exploring", False)
        )

    def random_walk(self):
        if self._is_moving() or self.is_talking or getattr(self, "_speech_busy", False):
            self.schedule_roam()
            return
        if self.state == "idle":
            tx = random.randint(40, max(50, self.screen_w - self.w - 50))
            ty = random.randint(40, max(50, self.screen_h - self.h - 80))
            self.walk_to_point(tx, ty)
        else:
            self.schedule_roam()

    def walk_to_point(self, tx, ty, min_steps=25, step_ms=16):
        # Токен поколения: старые прерванные ходьбы замолкают и не конфликтуют с новой
        self._walk_token = getattr(self, "_walk_token", 0) + 1
        token = self._walk_token
        self.is_walking = True
        sx, sy = self.pos_x, self.pos_y
        dist = math.hypot(tx - sx, ty - sy)
        steps = max(min_steps, int(dist / 4.5))

        def _step(i):
            if token != getattr(self, "_walk_token", 0):
                return
            if not self.is_walking:
                self.schedule_roam()
                return
            if i <= steps:
                t = i / steps
                cx = sx + (tx - sx) * t
                cy = sy + (ty - sy) * t
                hop = math.sin(i * 0.25) * 3.0
                self.pos_x, self.pos_y = cx, cy
                self.root.geometry(f"+{int(cx)}+{int(cy + hop)}")
                self.root.after(step_ms, lambda: _step(i + 1))
            else:
                self.is_walking = False
                self._hide_pending = False
                self.pos_x = float(tx)
                self.pos_y = float(ty)
                self.root.geometry(f"+{int(tx)}+{int(ty)}")
                self.schedule_roam()
        _step(0)

    def _on_drag_start(self, event):
        self.is_walking = False
        self.drag_x = event.x_root
        self.drag_y = event.y_root

    def _on_drag_motion(self, event):
        dx = event.x_root - self.drag_x
        dy = event.y_root - self.drag_y
        if dx or dy:
            # Если пользователь тащит Гема, значит он его «достал» из укрытия
            self.is_hiding = False
        self.pos_x += dx
        self.pos_y += dy
        self.root.geometry(f"+{int(self.pos_x)}+{int(self.pos_y)}")
        self.drag_x = event.x_root
        self.drag_y = event.y_root
        self._sync_particles_to_window()

    def run(self):
        self.say("я открыл глаз. настройки — ⚙ в углу.")
        self.root.mainloop()