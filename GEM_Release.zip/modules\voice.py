"""
Озвучка Гема (TTS) — опционально, через edge-tts (естественные нейроголоса).

По умолчанию ВЫКЛЮЧЕНА: дримкор-звук и пузырь с текстом идут из коробки.
Чтобы включить голос — поставь в gem_config.json:  "voice_enabled": true
и выполни:  pip install edge-tts
"""
import os
import time
import asyncio
import ctypes
import threading
import http.server
import socketserver

try:
    import edge_tts
except ImportError:
    edge_tts = None

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_winmm = ctypes.windll.winmm


def _mci(cmd: str) -> str:
    buf = ctypes.create_unicode_buffer(512)
    _winmm.mciSendStringW(cmd, buf, 512, None)
    return buf.value


def play_audio_file(path: str, alias: str) -> bool:
    """Проигрывает mp3 через Windows MCI (только стандартная библиотека)."""
    try:
        _mci(f"close {alias}")
        _mci(f'open "{path}" type mpegvideo alias {alias}')
        _mci(f"play {alias}")
        for _ in range(900):  # до ~90 секунд
            time.sleep(0.1)
            mode = _mci(f"status {alias} mode").strip().lower()
            if mode != "playing":
                break
        _mci(f"close {alias}")
        return True
    except Exception as e:
        print(f"[VOICE] Ошибка воспроизведения: {e}")
        return False


async def _generate_stream(text: str, path: str, voice: str, rate: str, volume: str):
    communicate = edge_tts.Communicate(text, voice, rate=rate, volume=volume)
    with open(path, "wb") as f:
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])


def _generate_with_fallback(text, path, voice_name, rate, volume):
    try:
        asyncio.run(_generate_stream(text, path, voice_name, rate, volume))
    except Exception:
        fallback = "ru-RU-DmitryNeural"
        if voice_name != fallback:
            asyncio.run(_generate_stream(text, path, fallback, rate, volume))
        else:
            raise


def _clamp_percent(value, lo=-50, hi=50, default="+0%"):
    """Edge TTS падает и вешает соединение на экстремальных rate/volume.
    Ограничиваем в безопасные рамки [-50%; +50%]."""
    try:
        s = str(value or "").strip()
        if not s.endswith("%"):
            return default
        num = int(s[:-1].lstrip("+"))
        if s.startswith("-"):
            num = -abs(num)
        num = max(lo, min(hi, num))
        return f"{num:+d}%"
    except Exception:
        return default


class Voice:
    def __init__(self, config):
        self.enabled = bool(config.get("voice_enabled", False))
        self.voice_name = config.get("voice_name", "ru-RU-DmitryNeural")
        self.rate = _clamp_percent(config.get("voice_rate"), -50, 50, "+0%")
        self.volume = _clamp_percent(config.get("voice_volume"), -50, 50, "+0%")
        self._speaking = False
        self._current_alias = None

    def _available(self) -> bool:
        return self.enabled and edge_tts is not None

    def stop(self):
        """Прервать текущее воспроизведение TTS (если идёт)."""
        alias = self._current_alias
        self._speaking = False
        self._current_alias = None
        if alias:
            try:
                _mci(f"close {alias}")
            except Exception:
                pass

    def speak(self, text: str):
        """Озвучить текст в фоновом потоке (если голос включён и edge-tts установлен)."""
        if not self._available():
            return
        if getattr(self, "_speaking", False):
            return
        text = (text or "").strip()
        if not text:
            return

        self._speaking = True
        def _run():
            try:
                out_dir = os.path.join(BASE_DIR, "data", "voice")
                os.makedirs(out_dir, exist_ok=True)
                path = os.path.join(out_dir, f"gem_{int(time.time() * 1000)}.mp3")
                # Стриминг: пишем чанки по мере поступления и параллельно играем файл
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                comm = edge_tts.Communicate(text, self.voice_name, rate=self.rate, volume=self.volume)
                
                async def _stream_to_file():
                    with open(path, "wb") as f:
                        async for chunk in comm.stream():
                            if chunk["type"] == "audio":
                                f.write(chunk["data"])
                                f.flush()

                try:
                    loop.run_until_complete(_stream_to_file())
                except Exception:
                    fallback = "ru-RU-DmitryNeural"
                    if self.voice_name != fallback:
                        self.voice_name = fallback
                        comm = edge_tts.Communicate(text, fallback, rate=self.rate, volume=self.volume)
                        loop.run_until_complete(_stream_to_file())
                    else:
                        raise
                finally:
                    loop.close()

                alias = os.path.splitext(os.path.basename(path))[0]
                self._current_alias = alias
                play_audio_file(path, alias)
            except Exception as e:
                print(f"[VOICE] {e.__class__.__name__}: {e}")
            finally:
                self._speaking = False
                self._current_alias = None

        threading.Thread(target=_run, daemon=True).start()
