import time
import unittest

from modules.scheduler import parse_reminder


class ReminderParserTests(unittest.TestCase):
    def test_relative_minutes(self):
        parsed = parse_reminder("напомни через 20 минут купить хлеб")
        self.assertIsNotNone(parsed)
        due, payload = parsed
        delta = due - time.time()
        self.assertGreater(delta, 19 * 60)
        self.assertLess(delta, 21 * 60)
        self.assertEqual(payload, "купить хлеб")

    def test_relative_hours_without_payload(self):
        parsed = parse_reminder("напомни через 1 час")
        self.assertIsNotNone(parsed)
        due, payload = parsed
        delta = due - time.time()
        self.assertGreater(delta, 50 * 60)
        self.assertLess(delta, 70 * 60)
        self.assertEqual(payload, "время вышло")

    def test_absolute_time(self):
        parsed = parse_reminder("напомни в 23:59 чай")
        self.assertIsNotNone(parsed)
        _, payload = parsed
        self.assertEqual(payload, "чай")

    def test_not_a_reminder(self):
        self.assertIsNone(parse_reminder("напиши привет"))
        self.assertIsNone(parse_reminder("запомни что-то"))
        self.assertIsNone(parse_reminder("гем, как дела"))


if __name__ == "__main__":
    unittest.main()
