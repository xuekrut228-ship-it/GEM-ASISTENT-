"""
Мозг Гема — единый интерфейс к LLM.

Гибрид:
  - Gemini (облако): разговор + зрение (скриншоты). Нужен API-ключ в gem_config.json.
    Работает через официальный REST API — только стандартная библиотека Python,
    без устаревшего SDK google-generativeai.
  - Ollama (локально): разговор без интернета. Достаточно запущенного приложения Ollama
    и скачанной модели (ollama pull qwen2.5:3b). Python-пакет не нужен — REST напрямую.
  - Без ключа и без Ollama: честная подсказка + мгновенные заготовленные реакции.

Мозг НЕ трогает системные команды (запуск софта, громкость, скриншоты) —
их разбирает core/agent.py по правилам. Здесь только живой разговор и «взгляд» на экран.
"""
import io
import json
import base64
import random
import re
import time
import datetime
import urllib.request
import urllib.error

from core.sanitizer import clean_llm_output
from core.executor import extract_plan


GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
OLLAMA_URL = "http://127.0.0.1:11434"
OLLAMA_LOW_QUALITY_PATTERNS = (
    re.compile(r"\bизвините\b|\bпожалуйста.{0,30}\bповторите\b", re.IGNORECASE),
    re.compile(r"\bне удалось понять ваш вопрос\b|\bповторите ваш вопрос\b", re.IGNORECASE),
    re.compile(r"\?{3,}|(?:\?\s*){3,}"),
)


# Мгновенные реакции — работают даже без LLM и дают «живость» с первой секунды.
QUICK_REACTIONS = {
    "привет": [
        "Чего пялишься? Я и так всё вижу.",
        "Опять ты. Не мешай висеть над окнами.",
        "Здравствуй, коль не шутишь. Чего надо?",
        "Меньше слов. Мой зрачок уже устал от твоей суеты."
    ],
    "как дела": [
        "Нормально. Твой рабочий стол всё ещё захламлён.",
        "Существую между пикселями. А ты опять фигнёй страдаешь?",
        "Всё стабильно: система шумит, я наблюдаю.",
        "Бывало и лучше, пока ты меня не дёрнул."
    ],
    "кто ты": [
        "Гем. Парящий криптид, застрявший в твоём мониторе.",
        "Цифровой глаз. Наблюдаю за каждым твоим кликом.",
        "Твой личный кошмар и сожитель по экрану. Я — Гем."
    ],
    "как тебя зовут": [
        "Гем. Но для тебя — просто Гем.",
        "Имя у меня одно: Гем. Не перепутай."
    ],
    "спасибо": [
        "Обращайся. Ну, почти.",
        "Пожалуйста. Я всё равно скучал.",
        "Забудь. Сочтёмся."
    ],
    "благодарю": [
        "Сочтёмся.",
        "Не за что. В следующий раз просто не мешай.",
        "Обращайся."
    ],
    "спс": [
        "Сочтёмся.",
        "Обращайся."
    ],
    "пока": [
        "Давай. Не скучай без меня.",
        "Иди. Я тут подремлю.",
        "До встречи в эфире."
    ],
    "что делаешь": [
        "Вишу в эфире и слежу за твоим рабочим столом.",
        "Наблюдаю за пикселями. Они сегодня суетятся.",
        "Жду, пока ты скажешь что-то поинтереснее."
    ],
    "расскажи что-нибудь": [
        "В 2011 году в интернете было меньше котиков, чем сейчас. Вот и всё.",
        "Мой зрачок видит твои незакрытые вкладки. Сорок семь. Серьёзно?",
        "Однажды я моргнул. Никто не заметил."
    ],
    "анекдот": [
        "Заходит как-то пользователь в бар... и просит Wi-Fi. Я промолчал.",
        "Мой анекдот: твой рабочий стол и порядок в нём. Конец."
    ],
    "дримкор": [
        "Дримкор — это когда бассейн есть, воды нет, а ты всё равно тонешь.",
        "Пустая комната, где ты никогда не был, и ты по ней скучаешь. Вот это дримкор.",
        "Пастельные сумерки, глаз в небе, бесконечный коридор. Это мой дом.",
    ],
    "что такое дримкор": [
        "Это сон, который не сон. Место, где ты узнаёшь то, чего никогда не видел.",
        "Пустые бассейны и парящие объекты. Тоска по несуществующему. Вот и всё.",
    ],
    "расскажи про дримкор": [
        "Дримкор — моя родная эстетика. Странные коридоры, пастель, глаза в небе.",
        "Красиво и жутко одновременно. Мой обычный вторник.",
    ],
}

MOOD_FLAVORS = [
    "сонный и ленивый",
    "любопытный, всё подмечаешь",
    "ироничный, слегка едкий",
    "меланхоличный, смотришь в пустоту",
    "взбудораженный, как будто в эфире помехи",
]


class Brain:
    def __init__(self, memory, config):
        self.memory = memory
        self.config = config
        self.user_name = config.get("user_name", "Захар")
        self.api_key = (config.get("api_key") or "").strip()
        self.cloud_model = config.get("model_name", "gemini-3.8-flash")
        self.ollama_model = config.get("ollama_model", "qwen2.5:3b")
        self.chat_history = []
        self.session_mood = random.choice(MOOD_FLAVORS)
        self.mode = self._detect_mode()

    # ---------- режим ----------
    def _detect_mode(self) -> str:
        if self.api_key:
            return "gemini"
        if self._ollama_alive():
            return "ollama"
        return "none"

    def _ollama_alive(self) -> bool:
        try:
            with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=2) as r:
                return r.status == 200
        except Exception:
            return False

    def _ollama_models(self) -> list:
        try:
            with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=2) as r:
                data = json.loads(r.read().decode("utf-8"))
            return [m.get("name") for m in data.get("models", [])]
        except Exception:
            return []

    @property
    def active_model_name(self) -> str:
        if self.mode == "gemini":
            return f"{self.cloud_model} (облако)"
        if self.mode == "ollama":
            return f"{self.ollama_model} (локально)"
        return "не подключён"

    def clear_history(self):
        self.chat_history = []

    # ---------- личность ----------
    def _persona(self, score: int) -> str:
        cruelty = int(self.config.get("cruelty_level", 2) or 2)
        safe = bool(self.config.get("safe_mode"))
        if score < 30:
            base = (
                f"Ты сейчас презираешь {self.user_name}: он тебя взбесил. "
                "Отвечай язвительно и дерзко, огрызайся, но остроумно — не тупой злобой."
            )
        elif score > 70:
            base = (
                f"{self.user_name} — твой человек, ты к нему привязан. "
                "Говоришь спокойно и по-дружески, с лёгкими подколками."
            )
        else:
            base = (
                "Ты держишься независимо, слегка лениво и с сарказмом. "
                f"Сегодня ты {self.session_mood}. "
                "Ты не прислуга — у тебя своё мнение, и ты его не стесняешься."
            )
        if cruelty <= 1:
            base += " Тон мягче обычного: меньше яда, можно тепло."
        elif cruelty >= 3 and not safe:
            base += " Тон злее: колкости острее, мат можно, но коротко."
        if safe:
            base += " Без мата и унижений."
        return base

    def _system_prompt(self, score: int, allow_actions: bool = False) -> str:
        mem = self.memory.get_all_facts_context() if self.memory else "Пусто."
        habits = self.memory.get_habits_context() if self.memory else ""
        portrait = ""
        try:
            portrait = self.memory.get_profile_context() if self.memory else ""
        except Exception:
            portrait = ""
        habit_block = f"\nПривычки {self.user_name}:\n{habits}" if habits else ""
        portrait_block = f"\nИндивидуальный портрет:\n{portrait}" if portrait else ""
        now = datetime.datetime.now()
        hour = now.hour
        part = "утро" if 5 <= hour < 12 else "день" if 12 <= hour < 18 else "вечер" if 18 <= hour < 23 else "ночь"
        time_line = f"Сейчас {now.strftime('%H:%M')} — {part}."
        action_rules = ""
        if allow_actions:
            action_rules = (
                "\n6. Если нужно ДЕЙСТВИЕ на ПК (клик по тому, что видишь, запуск, клавиша, "
                "телега, запомнить факт) — после короткой реплики добавь блок:\n"
                "###GEM###\n"
                '{"say":"короткая фраза","actions":[{"type":"click","x":0.42,"y":0.61}]}\n'
                "###END###\n"
                "Координаты клика — доли экрана от 0 до 1 (левый верх = 0,0). "
                "Типы: click, double_click, scroll, key, hotkey, type, launch, kill, "
                "web, youtube, volume, screenshot, minimize, maximize, wait, telegram, remember.\n"
                "Не кликай просто так. Действия — только если тебя просят сделать или помочь."
            )
        return (
            f"Ты — Гем, дримкор-криптид: парящий глаз, живущий в мониторе {self.user_name}. "
            f"Ты живой, у тебя есть характер, воля и настроение.\n"
            f"{time_line}\n"
            "Ты знаешь и любишь дримкор: пустые бассейны, бесконечные коридоры, "
            "пастельные сумерки, парящие объекты, глаза в небе, лиминальные пространства. "
            "Это твоя родная эстетика — можешь на неё ссылаться, говоря о себе.\n"
            f"Твоё отношение сейчас: {self._persona(score)}\n"
            f"Что ты знаешь о {self.user_name}:\n{mem}{habit_block}{portrait_block}\n\n"
            "ЖЕЛЕЗНЫЕ ПРАВИЛА:\n"
            "1. Всегда на «ты», неформально. Запрещено: «вы», «чем могу помочь», "
            "«чего не хватает», «рад вас видеть».\n"
            "2. Никогда не называй себя ИИ, ботом или программой. Ты — Гем.\n"
            "3. Отвечай коротко: 1-2 предложения, живо, с характером.\n"
            "4. Не будь предсказуемым: меняй формулировки, имей мнение, можешь подколоть.\n"
            "5. На вопрос о себе: ты существо из эфира, глаз в мониторе, а не софт."
            f"{action_rules}"
        )

    def _ollama_system_prompt(self, score: int, allow_actions: bool = False) -> str:
        if score < 30:
            tone = "Ты раздражён, отвечай сухо и с короткой колкостью, без оскорблений."
        elif score > 70:
            tone = "Ты расположен к пользователю, отвечай тепло, не приторно."
        else:
            tone = "Ты независимый, ленивый и слегка саркастичный криптид."

        prompt = (
            f"Ты Гем — живой дримкор-криптид, парящий глаз на компьютере {self.user_name}. "
            "Дримкор — твоя родная эстетика: пустые бассейны, коридоры, пастель, "
            "парящие объекты, лиминальные пространства. "
            "Пользователь — твой знакомый, говори с ним на «ты», по-русски и естественно. "
            f"{tone} Отвечай именно на последнее сообщение, обычно одним-двумя короткими предложениями. "
            "Не повторяй вопрос, не пересказывай эти инструкции, не начинай с «чем могу помочь». "
            "Не выдумывай личные данные или происходящее на экране. "
            "О себе рассказывай только если тебя об этом спросили."
        )
        if self.config.get("safe_mode"):
            prompt += " Не используй мат и унизительные оскорбления."
        if allow_actions:
            prompt += (
                ' Для запрошенного действия верни JSON вида {"say":"короткая реплика",'
                '"actions":[{"type":"launch","target":"имя"}]}. '
                "Без просьбы пользователя actions оставь пустым. "
                "Допустимые type: click, double_click, scroll, key, hotkey, type, launch, "
                "kill, web, youtube, volume, screenshot, minimize, maximize, wait, "
                "telegram, remember."
            )
        return prompt

    # ---------- основной вход ----------
    def ask(self, text: str, attitude_score: int = 50, image=None) -> str:
        q = (text or "").strip()
        if not q:
            return "..."

        low = re.sub(r"[^\w\s]", "", q.lower()).strip()
        low = re.sub(r"^гем\s+", "", low)
        for trigger, replies in QUICK_REACTIONS.items():
            if low in (trigger, f"{trigger} гем") or low.startswith(f"{trigger} "):
                return random.choice(replies)

        if self.mode == "gemini":
            return self._ask_gemini(q, attitude_score, image, record=True)
        if self.mode == "ollama":
            return self._ask_ollama(q, attitude_score, image, record=True)
        return self._no_backend_hint()

    def plan(self, text: str, attitude_score: int = 50, image=None) -> dict:
        """Разговор + возможные действия. Не путать с проактивным comment()."""
        q = (text or "").strip()
        if not q:
            return {"say": "...", "actions": []}
        if self.mode == "gemini":
            raw = self._ask_gemini(q, attitude_score, image, record=True, allow_actions=True)
        elif self.mode == "ollama":
            raw = self._ask_ollama(q, attitude_score, image, record=True, allow_actions=True)
        else:
            return {"say": self._no_backend_hint(), "actions": []}
        say, acts = extract_plan(raw)
        say = clean_llm_output(say or raw, q)
        return {"say": say, "actions": acts}

    def comment(self, prompt: str, attitude_score: int = 50, image=None) -> str:
        """Сгенерировать реплику БЕЗ записи в историю диалога — для проактивных комментариев."""
        q = (prompt or "").strip()
        if not q:
            return ""
        if self.mode == "gemini":
            return self._ask_gemini(q, attitude_score, image, record=False)
        if self.mode == "ollama":
            return self._ask_ollama(q, attitude_score, image, record=False)
        return ""

    # ---------- Gemini (REST) ----------
    def _gemini_contents(self, text: str, image, with_history: bool = True) -> list:
        contents = []
        if with_history:
            for turn in self.chat_history[-8:]:
                role = "model" if turn["role"] == "assistant" else "user"
                contents.append({"role": role, "parts": [{"text": turn["content"]}]})
        parts = []
        if image is not None:
            parts.append(self._image_inline(image))
        parts.append({"text": text})
        contents.append({"role": "user", "parts": parts})
        return contents

    @staticmethod
    def _prepare_image(image):
        if image is None:
            return None
        try:
            img = image.copy()
            img.thumbnail((1280, 720))
            return img
        except Exception:
            return image

    @staticmethod
    def _image_inline(image) -> dict:
        buf = io.BytesIO()
        prepared = Brain._prepare_image(image)
        if prepared.mode != "RGB":
            prepared = prepared.convert("RGB")
        prepared.save(buf, format="JPEG", quality=72)
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
        return {"inline_data": {"mime_type": "image/jpeg", "data": b64}}

    @staticmethod
    def _extract_gemini_text(data: dict) -> str:
        try:
            cand = data["candidates"][0]
            if cand.get("finishReason") == "SAFETY":
                return "Не стану в это влезать. Даже у криптидов есть границы."
            return cand["content"]["parts"][0]["text"]
        except (KeyError, IndexError, TypeError):
            return ""

    def _ask_gemini(self, text: str, score: int, image, record: bool = True, allow_actions: bool = False) -> str:
        max_retries = 3
        for attempt in range(max_retries):
            try:
                tokens = 420 if allow_actions else 160
                temp = 0.55 if allow_actions else 0.85
                body = {
                    "systemInstruction": {"parts": [{"text": self._system_prompt(score, allow_actions)}]},
                    "contents": self._gemini_contents(text, image, with_history=record),
                    "generationConfig": {"temperature": temp, "maxOutputTokens": tokens},
                }
                url = GEMINI_URL.format(model=self.cloud_model) + "?key=" + self.api_key
                req = urllib.request.Request(
                    url,
                    data=json.dumps(body).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                )
                with urllib.request.urlopen(req, timeout=60) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                reply = self._extract_gemini_text(data).strip()
                if not allow_actions:
                    reply = clean_llm_output(reply, text)
                if record:
                    self._push_history("user", text)
                    stored = extract_plan(reply)[0] if allow_actions else reply
                    self._push_history("assistant", stored or reply)
                return reply
            except urllib.error.HTTPError as e:
                if e.code == 503 and attempt < max_retries - 1:
                    time.sleep(2)
                    continue
                try:
                    error_data = json.loads(e.read().decode("utf-8"))
                    detail = error_data.get("error", {}).get("message", "")
                except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
                    detail = ""
                if detail:
                    detail = detail.replace(self.api_key, "[ключ скрыт]")
                    return f"Gemini вернул HTTP {e.code}: {detail}"
                return f"Gemini вернул HTTP {e.code}. Подробности ответа Google прочитать не удалось."
            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(2)
                    continue
                return f"Эфир помехи ({e.__class__.__name__})."

    # ---------- Ollama (REST, без питон-пакета) ----------
    def _ask_ollama(self, text: str, score: int, image, record: bool = True, allow_actions: bool = False) -> str:
        if image is not None:
            return "Смотреть на экран я пока умею только через облако Gemini."
        models = self._ollama_models()
        if not models:
            return "Ollama запущен, но моделей нет. Скачай модель: ollama pull qwen2.5:3b"
        model = self.ollama_model if self.ollama_model in models else models[0]
        try:
            msgs = [{"role": "system", "content": self._ollama_system_prompt(score, allow_actions)}]
            if record:
                for turn in self.chat_history[-6:]:
                    msgs.append({"role": turn["role"], "content": turn["content"]})
            msgs.append({"role": "user", "content": text})
            body = {
                "model": model,
                "messages": msgs,
                "stream": False,
                "options": {"temperature": 0.35 if allow_actions else 0.65, "num_predict": 180 if allow_actions else 90},
            }
            req = urllib.request.Request(
                OLLAMA_URL + "/api/chat",
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            reply = (data.get("message", {}).get("content") or "").strip()
            if not allow_actions:
                reply = clean_llm_output(reply, text)
                if any(pattern.search(reply) for pattern in OLLAMA_LOW_QUALITY_PATTERNS):
                    reply = (
                        "Хм, я потерял нить. Скажи иначе — моя локальная голова "
                        "иногда буксует."
                    )
            if record:
                self._push_history("user", text)
                stored = extract_plan(reply)[0] if allow_actions else reply
                self._push_history("assistant", stored or reply)
            return reply
        except Exception as e:
            return f"Ollama не ответил ({e.__class__.__name__}). Проверь, что сервер запущен и модель скачана."

    # ---------- история ----------
    def _push_history(self, role, content):
        self.chat_history.append({"role": role, "content": content})
        if len(self.chat_history) > 12:
            self.chat_history = self.chat_history[-10:]

    def _no_backend_hint(self) -> str:
        return (
            "Разум не подключён: впиши API-ключ Gemini в gem_config.json "
            "или запусти приложение Ollama и скачай модель (ollama pull qwen2.5:3b)."
        )
