"""
Фильтры вывода: отсечение системного мусора, корпоративных клише и зеркального эха.
"""
import re
import difflib
import random

SERVICE_PATTERNS = re.compile(
    r"\b(чем (могу|тебе|вам) помочь|как я могу помочь( тебе| вам)?|"
    r"чего (тебе|вам) не хватает|я здесь для|готов помочь|"
    r"виртуальный помощник|рад вас видеть|обращайтесь|хорошего дня|извините за беспокойство|"
    r"добро пожаловать|что вас интересует|"
    r"к тебе тоже|взаимно|не за что|всегда пожалуйста|рад был помочь|"
    r"если что обращайтесь|если что-то еще нужно|рад знакомству|приятно познакомиться)\b",
    re.IGNORECASE
)

SELF_TALK = re.compile(
    r"\bя\s*[—–-]?\s*гем\b|меня зовут гем|\bгем (здесь|тут|на связи)|"
    r"^я\s+(?:глаз|парящий|криптид|существо из эфира)\b|^гем\b|"
    r"^привет,?\s*гем\b|^здравствуй,?\s*гем\b", 
    re.IGNORECASE
)

ASKED_SELF = re.compile(r"кто ты|как тебя зовут|тво[её] имя|ты кто", re.IGNORECASE)

def clean_llm_output(raw_text: str, user_query: str) -> str:
    text = raw_text.strip()

    # 1. Срезаем блоки рассуждений <think>
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    if "</think>" in text:
        text = text.rsplit("</think>", 1)[-1]
    text = re.sub(r"<think>.*", "", text, flags=re.DOTALL)

    # 2. Убираем markdown и служебные префиксы
    text = re.sub(r"[\*\_#`«»\"]", "", text)
    text = re.sub(r"^(гем|ассистент|ответ|бот):\s*", "", text, flags=re.IGNORECASE).strip()

    # 3. Фильтр корпоративной вежливости
    if SERVICE_PATTERNS.search(text):
        return random.choice([
            "Не начинай эту чушь. Говори нормально.",
            "Ты меня с кем-то перепутал. Чего надо?",
            "Хватит формальностей. Я не голосовой помощник."
        ])

    # 4. Дробим на предложения и убираем самоповторы
    sentences = [s.strip() for s in re.split(r"(?<=[.!?…])\s+", text) if s.strip()]
    if not ASKED_SELF.search(user_query.lower()):
        cleaned_sentences = [s for s in sentences if not SELF_TALK.search(s)]
        sentences = cleaned_sentences

    if len(sentences) > 2:
        sentences = sentences[:2]
    text = " ".join(sentences).strip()
    if not text:
        return "Эй, я сбился. Скажи ещё раз, только попроще."

    # 5. Проверка на эхо
    clean_u = re.sub(r"[^\w\s]", "", user_query.lower()).strip()
    clean_r = re.sub(r"[^\w\s]", "", text.lower()).strip()
    if clean_u and clean_r and difflib.SequenceMatcher(None, clean_u, clean_r).ratio() > 0.7:
        return "Не повторяй за мной. Скажи что-то осмысленное."

    if text and text[-1] not in ".!?…":
        text += "."

    return text or "..."